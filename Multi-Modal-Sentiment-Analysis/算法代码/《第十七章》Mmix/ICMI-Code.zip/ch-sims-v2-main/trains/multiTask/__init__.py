from trains.multiTask.V1 import V1
from trains.multiTask.V1_Semi import V1_Semi
from trains.multiTask.V2_Semi import V2_Semi

__all__ = ['V1', 'V1_Semi', 'V2_Semi']