window.base_url= 'http://166.111.138.108:4096/';
window.static_url="http://166.111.138.108:8192/";