## How To Start Using

```
$ npm install
$ npm run build     # build dist files
$ npm run serve     # run dev server
```
