<template>
  <router-view></router-view>
</template>
<style>
#app {
  padding: 20px;
}
</style>