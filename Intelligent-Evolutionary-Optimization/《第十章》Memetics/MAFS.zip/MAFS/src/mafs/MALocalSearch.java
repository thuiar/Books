package mafs;


import weka.core.Instances;
import weka.core.Utils;
import java.io.Serializable;
import weka.attributeSelection.SubsetEvaluator;
import weka.core.SerializedObject;
import weka.attributeSelection.GA.GA;
import weka.attributeSelection.GA.GABitSet;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public abstract class MALocalSearch implements Serializable,Cloneable{
    public int [] rankedAttributes = null;
    SubsetEvaluator eval;
    GA ga;
    public abstract GABitSet search(GABitSet gab);
    public abstract void buildLocalSearch(Instances data,int minNumBin, int maxNumBin,GA ga,SubsetEvaluator sbe);
    public static MALocalSearch forName(String evaluatorName, String [] options) throws Exception {
        return (MALocalSearch)Utils.forName(MALocalSearch.class, evaluatorName, options);
    }
    public MALocalSearch() {
    }
    public static MALocalSearch makeCopy(MALocalSearch model) throws Exception {

    return (MALocalSearch)new SerializedObject(model).getObject();
    }
    
    public static MALocalSearch [] makeCopies(MALocalSearch model, int num) throws Exception {

    	if (model == null) {
    		throw new Exception("No model set");
    	}
    	MALocalSearch [] galss = new MALocalSearch [num];
    	SerializedObject so = new SerializedObject(model);
    	for(int i = 0; i < galss.length; i++) {
    		galss[i] = (MALocalSearch) so.getObject();
    	}
    	return galss;
    }
    
    
}