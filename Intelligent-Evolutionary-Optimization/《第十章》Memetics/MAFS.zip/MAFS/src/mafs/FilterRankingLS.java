package mafs;


import weka.core.OptionHandler;
import weka.attributeSelection.ASEvaluation;
import weka.core.Utils;
import java.util.Enumeration;
import java.util.Vector;
import weka.core.Option;
import weka.core.Instances;
import weka.attributeSelection.Ranker;
import weka.attributeSelection.ReliefFAttributeEval;
import java.util.Random;
import weka.core.Tag;
import weka.core.SelectedTag;
import weka.attributeSelection.SubsetEvaluator;
import weka.attributeSelection.GA.GABitSet;
import weka.attributeSelection.GA.GA;
/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class FilterRankingLS extends MALocalSearch implements OptionHandler{
    private ASEvaluation m_filterRankingMethod=new ReliefFAttributeEval();

    private Instances data;
    private int m_localSearchLength=3;
    int maxSelectedAtt,minSelectedAtt;
    private double m_selectionPressure = 1.5;


    protected int m_selectionType = LRANK;
    public static final int LRANK = 1;
    public static final int ERANK = 2;
    public static final Tag [] TAGS_SELECTIONTYPE = {
            new Tag(LRANK, "Linear Rank Selection"),
            new Tag(ERANK, "Exponential Rank Selection")
    };

    protected int m_localSearchImprovementStrategy = IMPROVEMENTFIRST;
    public static final int IMPROVEMENTFIRST = 1;
    public static final int GREEDY = 2;
    public static final Tag [] TAGS_LSIMPROVEMENTSTRATEGY = {
            new Tag(IMPROVEMENTFIRST, "Improvement First"),
            new Tag(GREEDY, "Greedy")
    };


    public SelectedTag getLSImprovementStrategy() {

        return new SelectedTag(m_localSearchImprovementStrategy, TAGS_LSIMPROVEMENTSTRATEGY);
    }

    public void setLSImprovementStrategy(SelectedTag strategy) {

        if (strategy.getTags() == TAGS_LSIMPROVEMENTSTRATEGY) {
            m_localSearchImprovementStrategy = strategy.getSelectedTag().getID();
        }
    }




    public ASEvaluation getFilterRankingMethod(){
        return m_filterRankingMethod;
    }

    public void setFilterRankingMethod(ASEvaluation a){
        m_filterRankingMethod = a;
    }

    public int getLocalSearchLength(){
        return m_localSearchLength;
    }
    public void setLocalSearchLength(int s){
        m_localSearchLength = s;
    }

    public double getSelectionPressure(){
        return m_selectionPressure;
    }
    public void setSelectionPressure(double s){
        m_selectionPressure = s;
    }

    public SelectedTag getSelectionType() {

        return new SelectedTag(m_selectionType, TAGS_SELECTIONTYPE);
    }

    public void setSelectionType(SelectedTag type) {

        if (type.getTags() == TAGS_SELECTIONTYPE) {
            m_selectionType = type.getSelectedTag().getID();
        }
    }

    
    public String globalInfo() {
        return "Filter Ranking Local Search :\n\nPerforms a filter ranking based local search described in: \n Zexuan Zhu, Y. S. Ong and M. Dash, ��Wrapper-Filter Feature Selection Algorithm Using A Memetic Framework��, IEEE Transactions On Systems, Man and Cybernetics - Part B,  Vol. 37, No. 1, pp. 70-76, 2007.\n";
    }
    
    
    public String selectionTypeTipText() {
        return "Set the type of ranking selection.";
    }
    
    public String localSearchLengthTipText() {
        return "Set the local search length described in Zhu Zexuan et al. SMCB 2007.";
    }
    public String selectionPressureTipText() {
        return "Set the selection pressure for ranking selection. \n" +
        		"Linear ranking seletion: pressure [1.0 2.0], the larger the pressure the more likly the last element of rankedlist being selected" +
        		"\n Exponential Rank Selection: pressure [0 1.0] denotes the approximate possibility of the last element of rankedlist being selected, the larger pressure the more likly the last element is selected";
    }
    public String LSImprovementStrategyTipText() {
        return "Set local search improvement strategy described in Zhu Zexuan et al. SMCB 2007.";
    }
    
    public String filterRankingMethodTipText() {
        return "Set the filter ranking feature selection method.";
    }


    public String[] getOptions () {
        String[] localHeuristicOptions = new String[0];

        if (( m_filterRankingMethod!= null) &&
            (m_filterRankingMethod instanceof OptionHandler)) {
            localHeuristicOptions = ((OptionHandler)m_filterRankingMethod).getOptions();
        }

        String[] options = new String[20+localHeuristicOptions.length];
        int current = 0;
        if (getFilterRankingMethod() != null) {
            options[current++] = "-B";
            options[current++] = getFilterRankingMethod().getClass().getName();
        }
        options[current++] = "-l";
        options[current++] = "" + getLocalSearchLength();
        options[current++] = "-S";
        options[current++] = "" + getSelectionPressure();
        
        if (m_selectionType == LRANK) {
            options[current++] = "-s";
        }else if(m_selectionType == ERANK){
            options[current++] = "-e";
        }

        if (m_localSearchImprovementStrategy == IMPROVEMENTFIRST){
            options[current++] = "-m";
        }else if(m_localSearchImprovementStrategy == GREEDY){
            options[current++] = "-n";
        }


        options[current++] = "--";
        System.arraycopy(localHeuristicOptions, 0, options, current,localHeuristicOptions.length);
        current += localHeuristicOptions.length;
        while (current < options.length) {
            options[current++] = "";
        }
        return  options;
    }

    public void setOptions (String[] options) throws Exception {
        String optionString;

        optionString = Utils.getOption('B', options);
        setFilterRankingMethod(ASEvaluation.forName(optionString,Utils.partitionOptions(options)));
        optionString = Utils.getOption('l', options);
        if (optionString.length() != 0) {
            setLocalSearchLength(Integer.parseInt(optionString));
        }
        optionString = Utils.getOption('S', options);
        if (optionString.length() != 0) {
            setSelectionPressure(Double.parseDouble(optionString));
        }

        
        if (Utils.getFlag('s', options)) {
            setSelectionType(new SelectedTag(LRANK, TAGS_SELECTIONTYPE));
        } else{
            setSelectionType(new SelectedTag(ERANK, TAGS_SELECTIONTYPE));
        }

        if(Utils.getFlag('m', options)){
            setLSImprovementStrategy(new SelectedTag(IMPROVEMENTFIRST, TAGS_LSIMPROVEMENTSTRATEGY));
        }else {
            setLSImprovementStrategy(new SelectedTag(GREEDY, TAGS_LSIMPROVEMENTSTRATEGY));
        }



    }


    public Enumeration listOptions () {
        Vector newVector = new Vector(8);

        newVector.addElement(new Option("\tSet the heuristic for local search", "B", 1, "-B <instance evaluator>"));
        newVector.addElement(new Option("\tSet local search Length size", "l", 3, "-l <Length size>"));
        newVector.addElement(new Option("\tLinear Rank selection","s", 0, "-s"));
        newVector.addElement(new Option("\tExponential Rank selection","e", 0, "-e"));
        newVector.addElement(new Option("\tSet selection pressure","S", 0, "-S <pressure>"));
        newVector.addElement(new Option("\tImprovement Frist local search","m", 0, "-m"));
        newVector.addElement(new Option("\tGreedy local search","n", 0, "-n"));
        return  newVector.elements();
    }



    public GABitSet search(GABitSet gab){
        try{
            if (this.m_localSearchImprovementStrategy == IMPROVEMENTFIRST) {
                int a[] = new int[m_localSearchLength * m_localSearchLength - 1];
                int k = ga.getParallel() > 0 ? ga.getParallel() : 1;
                for (int j = 0; j < a.length; ) {
                    if (j + ga.getParallel() > a.length) {
                        k = a.length - j;
                    }
                    GABitSet tmpB[] = new GABitSet[k];
                    for (int jj = 0; jj < k; jj++, j++) {
                        int tmp = ga.m_random.nextInt(m_localSearchLength *
                                            m_localSearchLength - 1) + 1;
                        while (Utils.contain(a, j, tmp)) {
                            tmp = ga.m_random.nextInt(m_localSearchLength *
                                            m_localSearchLength - 1) + 1;
                        }
                        a[j] = tmp;
                        tmpB[jj] = (GABitSet) (gab.clone());
                        int addNum = a[j] / m_localSearchLength;
                        int delNum = a[j] % m_localSearchLength;
                        int currentNum = gab.getChromosome().cardinality();
                        if(currentNum+addNum>data.numAttributes()-1){
                            addNum -= currentNum+addNum+1-data.numAttributes();
                        }
                        if(currentNum-delNum<1){
                            delNum -= 1-currentNum+delNum;
                        }
                        int finalNum = currentNum+addNum-delNum;
                        if( finalNum > maxSelectedAtt){
                            addNum -= finalNum - maxSelectedAtt;
                        }else if(finalNum < minSelectedAtt){
                            delNum -= minSelectedAtt-finalNum;
                        }

                        addDel(addNum,delNum,tmpB[jj]);
                    }
                    ga.calculateFitness(eval, tmpB);
                    for (int jj = 0; jj < k; jj++) {
                        if (ga.compareGABitSet(tmpB[jj], gab) == 1) {
                            ga.numCallingEvaluator -= (k - 1 - jj);
                            return tmpB[jj];
                        }
                    }
                }
            } else {
                GABitSet tmpB[] = new GABitSet[m_localSearchLength * m_localSearchLength - 1];
                for (int j = 1; j < (m_localSearchLength * m_localSearchLength); j++) {
                    tmpB[j - 1] = (GABitSet) (gab.clone());
                    int addNum = j / m_localSearchLength;
                    int delNum = j % m_localSearchLength;
                    int currentNum = gab.getChromosome().cardinality();
                    if(currentNum+addNum>data.numAttributes()-1){
                        addNum -= currentNum+addNum+1-data.numAttributes();
                    }
                    if(currentNum-delNum<1){
                        delNum -= 1-currentNum+delNum;
                    }
                    int finalNum = currentNum+addNum-delNum;
                    if( finalNum > maxSelectedAtt){
                        addNum -= finalNum - maxSelectedAtt;
                    }else if(finalNum < minSelectedAtt){
                        delNum -= minSelectedAtt-finalNum;
                    }
                    addDel(addNum, delNum,tmpB[j - 1]);
                }
                ga.calculateFitness(eval, tmpB);
                for (int j = 0; j < tmpB.length; j++) {
                    if (ga.compareGABitSet(tmpB[j], gab) == 1) {
                        gab = tmpB[j];
                    }
                }
                return gab;

            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return gab;
    }

    public void buildLocalSearch(Instances d,int min,int max,GA g,SubsetEvaluator se){
        data = d;
        maxSelectedAtt = max;
        minSelectedAtt = min;
        ga = g;
        eval = se;
        try {
            m_filterRankingMethod.buildEvaluator(data);
            Ranker rk = new Ranker();
            rankedAttributes = rk.search(m_filterRankingMethod,data);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void addDel(int addNo,int delNo,GABitSet gbs){
        Random r = ga.m_random;

        for (int i = 0; i < addNo; i++) {
            addOne(gbs,r);
        }
        for (int i = 0; i < delNo; i++) {
            delOne(gbs,r);
        }
    }

    private int lookUpRank(int attributeNum){
        for (int i = 0; i < rankedAttributes.length; i++) {
            if(rankedAttributes[i] == attributeNum){
                return i;
            }
        }
        return -1;
    }


    ////add num feature to the GABitSet gbs
    private void addOne(GABitSet gbs,Random r){
        int n = rankedAttributes.length - gbs.getChromosome().cardinality();
        int [] addList = new int[n];
        for (int i = 0,j=0; i < rankedAttributes.length; i++) {
            if(!gbs.get(rankedAttributes[i])){
                addList[n-1-j] = rankedAttributes[i];
                j++;
            }
        }

            if(m_selectionType == ERANK){
                gbs.set(Utils.exponentialRankingSelection(addList, m_selectionPressure, r));
            }else{
                gbs.set(Utils.linearRankingSelection(addList, m_selectionPressure, r));
            }
        
    }

    private void delOne(GABitSet gbs,Random r){
        int n = gbs.getChromosome().cardinality();
        int [] delList = new int[n];
        for (int i = 0,j=0; i < rankedAttributes.length; i++) {
            if(gbs.get(rankedAttributes[i])){
                delList[j] = rankedAttributes[i];
                j++;
            }
        }
        
            if(m_selectionType == ERANK){
                gbs.clear(Utils.exponentialRankingSelection(delList, m_selectionPressure, r));
            }else{
                gbs.clear(Utils.linearRankingSelection(delList, m_selectionPressure, r));
            }
        
    }

    public String toString(){
        return "\n\tLocal Search Method: FilterRanking"+
                "\n\tLocal Search Strategy: "+getLSImprovementStrategy().getSelectedTag().getReadable()+
                "\n\tLocal Search Length: "+getLocalSearchLength()+
                "\n\tLocal Search Selection Type: "+getSelectionType().getSelectedTag().getReadable()+
                "\n\tLocal Search Selection Pressure: "+getSelectionPressure();

    }

    public FilterRankingLS() {
    }
}
