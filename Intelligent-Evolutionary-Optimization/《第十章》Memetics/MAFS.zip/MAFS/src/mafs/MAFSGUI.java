package mafs;

import weka.gui.LogPanel;
import weka.gui.WekaTaskMonitor;
import weka.gui.visualize.MatrixPanel;
import java.io.File;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import weka.gui.explorer.*;

/**
 * The main class for the Memetic Feature Selection explorer. Lets the user create,
 * open, save, configure, datasets, and perform Memetic feature selection.
 *
 * @author zexuan zhu (developed based weka environment)
 */
public class MAFSGUI extends JPanel {

  /** The panel for preprocessing instances */
  protected PreprocessPanel m_PreprocessPanel = new PreprocessPanel();

  /** Label for a panel that still need to be implemented */
  protected MAFSPanel m_MAFSPanel =
    new MAFSPanel();

  /** The tabbed pane that controls which sub-pane we are working with */
  protected JTabbedPane m_TabbedPane = new JTabbedPane();

  /** The panel for log and status messages */
  protected LogPanel m_LogPanel = new LogPanel(new WekaTaskMonitor());


  /**
   * Creates the experiment environment gui with no initial experiment
   */
  public MAFSGUI() {

    String date = (new SimpleDateFormat("EEEE, d MMMM yyyy"))
      .format(new Date());
    m_LogPanel.logMessage("Memetic Algorithm Feature Selection");
    m_LogPanel.logMessage("Author: Zexuan Zhu");
    m_LogPanel.logMessage("(developed based on Weka environment web: http://www.cs.waikato.ac.nz/~ml/)");
    m_LogPanel.logMessage("Started on " + date);
    m_LogPanel.statusMessage("Welcome to the Memetic Algorithm Feature Selection Panel");
    m_PreprocessPanel.setLog(m_LogPanel);
    m_MAFSPanel.setLog(m_LogPanel);
    m_MAFSPanel.setPreprocessPanel(m_PreprocessPanel);
    m_TabbedPane.addTab("Preprocess", null, m_PreprocessPanel,
			"Open/Edit/Save instances");
    m_TabbedPane.addTab("Memetic Feature Selection", null, m_MAFSPanel,
		      "Determine relevance of attributes");
    m_TabbedPane.setSelectedIndex(0);
    m_TabbedPane.setEnabledAt(1, false);
    m_PreprocessPanel.addPropertyChangeListener(new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent e) {
	m_MAFSPanel.setInstances(m_PreprocessPanel
					       .getInstances());
	m_TabbedPane.setEnabledAt(1, true);
      }
    });

    setLayout(new BorderLayout());
    add(m_TabbedPane, BorderLayout.CENTER);

    add(m_LogPanel, BorderLayout.SOUTH);
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

  /**
   * Tests out the explorer environment.
   *
   * @param args ignored.
   */
  public static void main(String [] args) {

    try { // use system look & feel
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception e) {}
    try {
      MAFSGUI explorer = new MAFSGUI();
      final JFrame jf = new JFrame("Memetic Feature Selection");
      jf.getContentPane().setLayout(new BorderLayout());
      jf.getContentPane().add(explorer, BorderLayout.CENTER);
      jf.addWindowListener(new WindowAdapter() {
	public void windowClosing(WindowEvent e) {
	  jf.dispose();
	  System.exit(0);
	}
      });
      jf.pack();
      jf.setSize(800, 600);
      jf.setVisible(true);


    } catch (Exception ex) {
      ex.printStackTrace();
      System.err.println(ex.getMessage());
    }
  }

    private void jbInit() throws Exception {
    }

}
