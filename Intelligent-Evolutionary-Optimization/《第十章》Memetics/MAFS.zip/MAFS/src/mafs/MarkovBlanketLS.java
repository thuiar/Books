package mafs;

import weka.core.Instances;
import weka.core.OptionHandler;
import weka.core.Utils;
import java.util.Enumeration;
import java.util.Vector;
import weka.core.Option;
import weka.core.Tag;
import weka.core.SelectedTag;
import java.util.Random;
import weka.filters.Filter;
import weka.filters.supervised.attribute.Discretize;
import weka.core.FastVector;
import weka.attributeSelection.SubsetEvaluator;
import weka.attributeSelection.GA.GA;
import weka.attributeSelection.GA.GABitSet;
/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class MarkovBlanketLS extends MALocalSearch implements OptionHandler{


    private Instances data;
    private int m_localSearchLength=3;
    int maxSelectedAtt;
    int minSelectedAtt;
    int classAtt;
    //Hashtable suTable;
    //LinkedHashMap lhm;
    private double m_selectionPressure = 1.5;
    private double [][] suMatrix;
    Random r;


    protected int m_selectionType = LRANK;
    public static final int LRANK = 1;
    public static final int ERANK = 2;
    public static final Tag [] TAGS_SELECTIONTYPE = {
            new Tag(LRANK, "Linear Rank Selection"),
            new Tag(ERANK, "Exponential Rank Selection")
    };


    protected int m_localSearchImprovementStrategy = IMPROVEMENTFIRST;
    public static final int IMPROVEMENTFIRST = 1;
    public static final int GREEDY = 2;
    public static final Tag [] TAGS_LSIMPROVEMENTSTRATEGY = {
            new Tag(IMPROVEMENTFIRST, "Improvement First"),
            new Tag(GREEDY, "Greedy")
    };


    public SelectedTag getLSImprovementStrategy() {

        return new SelectedTag(m_localSearchImprovementStrategy, TAGS_LSIMPROVEMENTSTRATEGY);
    }

    public void setLSImprovementStrategy(SelectedTag strategy) {

        if (strategy.getTags() == TAGS_LSIMPROVEMENTSTRATEGY) {
            m_localSearchImprovementStrategy = strategy.getSelectedTag().getID();
        }
    }


    public int getLocalSearchLength(){
        return m_localSearchLength;
    }
    public void setLocalSearchLength(int s){
        m_localSearchLength = s;
    }

    public double getSelectionPressure(){
        return m_selectionPressure;
    }
    public void setSelectionPressure(double s){
        m_selectionPressure = s;
    }

    public SelectedTag getSelectionType() {
        return new SelectedTag(m_selectionType, TAGS_SELECTIONTYPE);
    }

    public void setSelectionType(SelectedTag type) {

        if (type.getTags() == TAGS_SELECTIONTYPE) {
            m_selectionType = type.getSelectedTag().getID();
        }
    }

    
    public String globalInfo() {
        return "Markov Blanket Local Search :\n\nPerforms a Markov blanket based local search described in: \n Zexuan Zhu, Y. S. Ong and M. Dash, ��Markov Blanket-Embedded Genetic Algorithm for Gene Selection��, Pattern Recognition, Vol. 49, No. 11, 3236-3248, 2007.\n";
    }
    
    
    
    
    public String selectionTypeTipText() {
        return "Set the type of ranking selection.";
    }
    
    public String localSearchLengthTipText() {
        return "Set the local search length described in Zhu Zexuan et al. SMCB 2007.";
    }
    public String selectionPressureTipText() {
        return "Set the selection pressure for ranking selection. \n" +
        		"Linear ranking seletion: pressure [1.0 2.0], the larger the pressure the more likly the last element of rankedlist being selected" +
        		"\n Exponential Rank Selection: pressure [0 1.0] denotes the approximate possibility of the last element of rankedlist being selected, the larger pressure the more likly the last element is selected";
    }
    public String LSImprovementStrategyTipText() {
        return "Set local search improvement strategy described in Zhu Zexuan et al. SMCB 2007.";
    }
    
    
    
    public String[] getOptions () {


        String[] options = new String[7];
        int current = 0;
        options[current++] = "-l";
        options[current++] = "" + getLocalSearchLength();
        options[current++] = "-S";
        options[current++] = "" + getSelectionPressure();

        if (m_selectionType == LRANK) {
            options[current++] = "-s";
        }else if(m_selectionType == ERANK){
            options[current++] = "-e";
        }

        if (m_localSearchImprovementStrategy == IMPROVEMENTFIRST){
            options[current++] = "-m";
        }else if(m_localSearchImprovementStrategy == GREEDY){
            options[current++] = "-n";
        }
        while (current < options.length) {
           options[current++] = "";
       }


        return  options;
    }



    public void setOptions (String[] options) throws Exception {
         String optionString;
         optionString = Utils.getOption('l', options);
         if (optionString.length() != 0) {
             setLocalSearchLength(Integer.parseInt(optionString));
         }
         optionString = Utils.getOption('S', options);
         if (optionString.length() != 0) {
             setSelectionPressure(Double.parseDouble(optionString));
         }

         if (Utils.getFlag('s', options)) {
             setSelectionType(new SelectedTag(LRANK, TAGS_SELECTIONTYPE));
         } else{
             setSelectionType(new SelectedTag(ERANK, TAGS_SELECTIONTYPE));
         }

         if(Utils.getFlag('m', options)){
             setLSImprovementStrategy(new SelectedTag(IMPROVEMENTFIRST, TAGS_LSIMPROVEMENTSTRATEGY));
         }else {
             setLSImprovementStrategy(new SelectedTag(GREEDY, TAGS_LSIMPROVEMENTSTRATEGY));
         }
     }


    public Enumeration listOptions () {
        Vector newVector = new Vector(7);
        newVector.addElement(new Option("\tSet local search step size", "l", 3, "-l <step size>"));
        newVector.addElement(new Option("\tSet local search step size", "P", 0, "-P"));
        newVector.addElement(new Option("\tLinear Rank selection","s", 0, "-s"));
        newVector.addElement(new Option("\tExponential Rank selection","e", 0, "-e"));
        newVector.addElement(new Option("\tSet selection pressure","S", 0, "-S <pressure>"));
        newVector.addElement(new Option("\tImprovement Frist local search","m", 0, "-m"));
        newVector.addElement(new Option("\tGreedy local search","n", 0, "-n"));
        return  newVector.elements();
    }



    public MarkovBlanketLS() {
    }

    /**
     * buildLocalSearch
     *
     * @param data Instances
     * @param maxSelectedAtt int
     * @param gs GeneticSearch
     * @todo Implement this weka.attributeSelection.GA.GALocalSearch method
     */
    public void buildLocalSearch(Instances d,int min, int max,GA g,SubsetEvaluator se) {
        data = d;
        maxSelectedAtt = max;
        minSelectedAtt = min;
        ga = g;
        eval = se;
        classAtt = data.classIndex();
        //suTable = new Hashtable(1000);
        //lhm = new LinkedHashMap(data.numAttributes());
        r = g.m_random;

        try{
            Discretize disTransform = new Discretize();
            disTransform.setUseBetterEncoding(true);
            disTransform.setInputFormat(data);
            data = Filter.useFilter(data, disTransform);
            if(data.numAttributes()<1500){
                suMatrix = new double[data.numAttributes()][];
                for (int i = 0; i < data.numAttributes(); i++) {
                    suMatrix[i] = new double[i];
                    for (int j = 0; j < i; j++) {
                        suMatrix[i][j] = symmetricalUncertainty(i, j);
                    }
                }
            }
            double suic[] = new double[data.numAttributes()-1];
            for (int i = 0,j=0; i < data.numAttributes(); i++) {
                if(i!=classAtt){
                    suic[j] = -su(i,classAtt);
                    j++;
                }
            }
            rankedAttributes = Utils.sort(suic);

        }catch(Exception e){
            e.printStackTrace();
        }


    }

    /**
     * search
     *
     * @param gab GABitSet
     * @return GABitSet
     * @todo Implement this weka.attributeSelection.GA.GALocalSearch method
     */
    public GABitSet search(GABitSet gab) {
        try {
           if (m_localSearchImprovementStrategy == IMPROVEMENTFIRST) {
               int a[] = new int[m_localSearchLength * m_localSearchLength - 1];
               int k = ga.getParallel() > 0 ? ga.getParallel() : 1;
               for (int j = 0; j < a.length; ) {
                   if (j + ga.getParallel() > a.length) {
                       k = a.length - j;
                   }
                   GABitSet tmpB[] = new GABitSet[k];
                   for (int jj = 0; jj < k; jj++, j++) {
                       int tmp = r.nextInt(m_localSearchLength *
                    		   m_localSearchLength - 1) + 1;
                       while (Utils.contain(a, j, tmp)) {
                           tmp = r.nextInt(m_localSearchLength *
                        		   m_localSearchLength - 1) + 1;
                       }
                       a[j] = tmp;
                       tmpB[jj] = (GABitSet) (gab.clone());
                       int addNum = a[j] / m_localSearchLength;
                       int delNum = a[j] % m_localSearchLength;
                       int currentNum = gab.getChromosome().cardinality();
                       if(currentNum+addNum>data.numAttributes()-1){
                           addNum -= currentNum+addNum+1-data.numAttributes();
                       }
                       if(currentNum-delNum<1){
                           delNum -= 1-currentNum+delNum;
                       }
                       int finalNum = currentNum+addNum-delNum;
                       if( finalNum > maxSelectedAtt){
                           addNum -= finalNum - maxSelectedAtt;
                       }else if(finalNum < minSelectedAtt){
                           delNum -= minSelectedAtt-finalNum;
                       }
                       addDel(addNum,delNum,tmpB[jj]);

                   }
                   ga.calculateFitness(eval, tmpB);
                   for (int jj = 0; jj < k; jj++) {
                       if (ga.compareGABitSet(tmpB[jj], gab) == 1) {
                           ga.numCallingEvaluator -= (k - 1 - jj);
                           return tmpB[jj];
                       }
                   }
               }
           }else{
               GABitSet tmpB[] = new GABitSet[m_localSearchLength * m_localSearchLength - 1];
                for (int j = 1; j < (m_localSearchLength * m_localSearchLength); j++) {
                    tmpB[j - 1] = (GABitSet) (gab.clone());
                    int addNum = j / m_localSearchLength;
                    int delNum = j % m_localSearchLength;
                    int currentNum = gab.getChromosome().cardinality();
                    if(currentNum+addNum>data.numAttributes()-1){
                        addNum -= currentNum+addNum+1-data.numAttributes();
                    }
                    if(currentNum-delNum<1){
                        delNum -= 1-currentNum+delNum;
                    }
                    int finalNum = currentNum+addNum-delNum;
                    if( finalNum > maxSelectedAtt){
                        addNum -= finalNum - maxSelectedAtt;
                    }else if(finalNum < minSelectedAtt){
                        delNum -= minSelectedAtt-finalNum;
                    }
                    addDel(addNum, delNum,tmpB[j - 1]);

                }
               ga.calculateFitness(eval, tmpB);
               for (int j = 0; j < tmpB.length; j++) {
                   if (ga.compareGABitSet(tmpB[j], gab) == 1) {
                       gab = tmpB[j];
                   }
               }
               return gab;

           }

       } catch (Exception ex) {
           ex.printStackTrace();
       }


        return gab;
    }

    private void addDel(int addNo,int delNo,GABitSet gbs){
        for (int i = 0; i < addNo; i++) {
            addOne(gbs);
        }
        for (int i = 0; i < delNo; i++) {
            delOne(gbs);
        }
    }
    private void addOne(GABitSet gbs){
        int numAttribs = data.numAttributes();
        double suic [] = new double[numAttribs];
        int nNotSelected = numAttribs-gbs.getChromosome().cardinality();
        int rankedList[] = new int[nNotSelected];
        //calcualte the systemetrical uncertainty of the selected features with respect to the class label
        for (int i = 0,j=nNotSelected-1; i < rankedAttributes.length; i++) {
            if (!gbs.get(rankedAttributes[i])) {
                rankedList[j] = rankedAttributes[i];
                j--;
            }
        }
        int candi = m_selectionType==LRANK ? Utils.linearRankingSelection(rankedList,m_selectionPressure,r):Utils.exponentialRankingSelection(rankedList,m_selectionPressure,r);
//        while(hasMarkovBlanket(gbs,candi)){
//           candi = m_selectionType==LRANK ? gs.linearRankingSelection(rankedList,m_selectionPressure,r):gs.exponentialRankingSelection(rankedList,m_selectionPressure,r);
//        }
        gbs.set(candi);

        //add features without markov blanket and return
//        int maxi = Utils.maxIndex(suic);
//        for(int i=nNotSelected,maxindex = maxi; i>0; i--){
//            if(!hasMarkovBlanket(gbs,maxindex)){
//                gbs.set(maxindex);
//                return;
//            }else{
//                suic[maxindex] = -Double.MAX_VALUE;
//            }
//            maxindex = Utils.maxIndex(suic);
//        }
//        //otherwise add the feature with maximum suic
//        gbs.set(maxi);
    }

    private void delOne(GABitSet gbs){
        int numAttribs = data.numAttributes();
        //double suic [] = new double[numAttribs];
        int nSelected = gbs.getChromosome().cardinality();
        int rankedList[] = new int[nSelected];
        boolean redundancy = false;
        for (int i = 0,j=0; i < rankedAttributes.length; i++) {
            if (gbs.get(rankedAttributes[i]) && rankedAttributes[i]!=classAtt) {
                rankedList[nSelected-1-j] = rankedAttributes[i];
                j++;
//                rankedList[j] = sortedList[i];
//                j++;
//                Enumeration e = markovBlanketCover(gbs,sortedList[i]).elements();
//                if(e.hasMoreElements()){
//                    while(e.hasMoreElements()){
//                        int t = ((Integer)e.nextElement()).intValue();
//                        gbs.clear(t);
//                    }
//                    redundancy = true;
//                }
            }
        }
//        if(!redundancy){
//            int candi = m_selectionType==LRANK ? gs.linearRankingSelection(rankedList,m_selectionPressure,r):gs.exponentialRankingSelection(rankedList,m_selectionPressure,r);
//            gbs.clear(candi);
//        }


        int candi = m_selectionType==LRANK ? Utils.linearRankingSelection(rankedList,m_selectionPressure,r):Utils.exponentialRankingSelection(rankedList,m_selectionPressure,r);
        Enumeration e = markovBlanketCover(gbs,candi).elements();
        if(e.hasMoreElements()){
            while(e.hasMoreElements()){
                if(gbs.m_chromosome.cardinality()==minSelectedAtt){
                    return;
                }
                gbs.clear(((Integer)e.nextElement()).intValue());
            }
        }else{
            if(gbs.m_chromosome.cardinality()==minSelectedAtt){
                    return;
            }
            gbs.clear(candi);
        }
    }


    //check weather attribute att has Markov Blanket in the selected subset
    private boolean hasMarkovBlanket(GABitSet gbs,int att){
        for (int i = 0; i < data.numAttributes(); i++) {
            if (gbs.get(i) && i!=classAtt && i!=att && su(i,classAtt)>=su(att,classAtt) && su(att,i)>=su(att,classAtt)) {
                return true;
            }
        }
        return false;
    }

    private FastVector markovBlanketCover(GABitSet gbs,int att){
        FastVector fv = new FastVector();
        for (int i = 0; i < data.numAttributes(); i++) {
            if (gbs.get(i) && i!=classAtt && i!=att && su(att,classAtt)>=su(i,classAtt) && su(i,att)>=su(i,classAtt)) {
                fv.addElement(new Integer(i));
            }
        }
        return fv;
    }


    private double su(int i,int j){
        if(data.numAttributes()<1500){
            return i>j ? suMatrix[i][j] : suMatrix[j][i];
        }else{
            double r = 0;
            //        if(suTable.containsKey(new Pair(i,j))){
            //            r = ((Double) suTable.get(new Pair(i, j))).doubleValue();
            //        }else{
            r = symmetricalUncertainty(i, j);
            //            suTable.put(new Pair(i,j),new Double(r));
            //        }
            return r;
        }
    }

    public String toString(){
        return "\n\tLocal Search Method: FilterRanking"+
                "\n\tLocal Search Strategy: "+getLSImprovementStrategy().getSelectedTag().getReadable()+
                "\n\tLocal Search Length: "+getLocalSearchLength();

    }


    double entropy(int attrIndex){
        double ans=0,temp;
        double curIndex [] = new double[data.numInstances()];
        for (int i = 0; i < curIndex.length; i++) {
            curIndex[i] = data.instance(i).value(attrIndex);
        }

        for(int i=0; i< data.attribute(attrIndex).numValues();i++){
            temp=partialProb(attrIndex,i);
            if(temp!=(double)0)
                ans+= temp *(Math.log(temp)/Math.log((double)2.0));
        }
        return -ans;
    }


    double partialProb(int attrIndex,int attrValue){
        int count=0;
        for(int i=0;i<data.numInstances();i++)
            if(data.instance(i).value(attrIndex) == (double)attrValue)
                count++;
        if(count!=0)
            return ((double)count/(double)data.numInstances());
        else
            return (double)0;
    }

    double condEntropy(int indexOne,int indexTwo){
        double ans=0,temp,temp_ans,cond_temp;
        double oneMS [] = new double[data.numInstances()];
        double twoMS [] = new double[data.numInstances()];
        for (int i = 0; i < oneMS.length; i++) {
            oneMS[i] = data.instance(i).value(indexOne);
            twoMS[i] = data.instance(i).value(indexTwo);
        }
        for(int j=0;j<data.attribute(indexTwo).numValues();j++){
            temp=partialProb(indexTwo,j);
            temp_ans=0;

            for(int i=0;i<data.attribute(indexOne).numValues();i++){
                cond_temp=partialCondProb(indexOne,i,indexTwo,j);
                if(cond_temp != (double)0)
                    temp_ans += cond_temp *(Math.log(cond_temp)/Math.log((double)2.0));
            }
            ans+=temp*temp_ans;
        }
        return -ans;
    }

    double partialCondProb(int indexOne,int valueOne,int indexTwo,int valueTwo){
        int num=0,den=0;

        for(int i=0;i<data.numInstances();i++){
            if(data.instance(i).value(indexTwo) == (double)valueTwo){
                den++;
                if(data.instance(i).value(indexOne) == (double)valueOne)
                    num++;
            }
        }

        if(den!=0)
            return (double)num/(double)den;
        else
            return (double)0;
    }

    double informationGain(int indexOne,int indexTwo){
        return entropy(indexOne) - condEntropy(indexOne,indexTwo);
    }

    double symmetricalUncertainty(int indexOne,int indexTwo){
        double ig,e1,e2;

        ig=informationGain(indexOne,indexTwo);
        e1=entropy(indexOne);
        e2=entropy(indexTwo);

        if((e1+e2) !=(double)0)
            return((double)2 * (ig/(e1+e2)));
        else
            return (double)1;
    }


    protected class Pair{
        int x,y;
        protected Pair(int a, int b){
            x=a;
            y=b;
        }
        public int hashcode(){
            return x+y;
        }
        public boolean equals(Object o){
            return (o instanceof Pair) && ((((Pair)o).x == x && ((Pair)o).y == y) || (((Pair)o).x == y && ((Pair)o).y == x));
        }
        public String toString(){
            return "x="+x+",y="+y;
        }
    }

}
