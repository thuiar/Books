package weka.clusterers;


import weka.core.*;
import java.math.*;
import java.lang.*;
import java.util.Vector;
import java.util.Enumeration;
/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class HierarchicalClusterer extends Clusterer implements OptionHandler {

    Instances dataset;

    private boolean m_transpose = false;
    private int m_numClusters = 1;
    private int [] clusterid;
    private int [][] results;
    private double [] linkdist;

    private int m_distanceType = ED;
    public static final int ED = 1, CB=2, CC=3, ACC=4, UCC=5, AUCC=6, SP=7, KT=8;
    public static final Tag [] TAGS_DISTANCETYPE = {
           new Tag(ED, "Euclidean Distance"),
           new Tag(CB, "City-Block Distance"),
           new Tag(CC, "Correlation"),
           new Tag(ACC, "Absolute Correlation"),
           new Tag(UCC, "Uncentered Correlation"),
           new Tag(AUCC, "Absolute Uncentered correlation"),
           new Tag(SP, "Spearman's Rank Correlation"),
           new Tag(KT, "Kendall's Tau")
    };
    private int m_linkageType = SL;
    public static final int SL=1,ML=2,AL=3,CL=4;
    public static final Tag [] TAGS_LINKAGETYPE = {
           new Tag(SL,"Pairwise Single-Linkage"),
           new Tag(ML,"Pairwise Maximum-(Complete) Linkage"),
           new Tag(AL,"Pairwise Average-Linkage"),
           new Tag(CL,"Pairwise Centroid-Linkage")

    };


    public SelectedTag getDistanceType() {

        return new SelectedTag(m_distanceType, TAGS_DISTANCETYPE);
    }
    public SelectedTag getLinkageType() {

        return new SelectedTag(m_linkageType, TAGS_LINKAGETYPE);
    }

    public void setDistanceType(SelectedTag type) {

        if (type.getTags() == TAGS_DISTANCETYPE) {
          m_distanceType = type.getSelectedTag().getID();
        }
    }
    public void setLinkageType(SelectedTag type) {

        if (type.getTags() == TAGS_LINKAGETYPE) {
            m_linkageType = type.getSelectedTag().getID();
        }
    }
    public void setTranspose(boolean b){
        m_transpose = b;
    }
    public boolean getTranspose(){
        return m_transpose;
    }

    public int getNumClusters(){
        return m_numClusters;
    }
    public void setNumClusters(int c){
        m_numClusters = c;
    }

    public String [] getOptions() {

        String[] options = new String[7];
        int current = 0;
        if (m_distanceType == CB) {
            options[current++] = "-B";
        }else if(m_distanceType == CC){
            options[current++] = "-C";
        }else if(m_distanceType == ACC){
            options[current++] = "-A";
        }else if(m_distanceType == UCC){
            options[current++] = "-U";
        }else if(m_distanceType == AUCC){
            options[current++] = "-D";
        }else if(m_distanceType == SP){
            options[current++] = "-S";
        }else if(m_distanceType == KT){
            options[current++] = "-K";
        }

        if (m_linkageType == ML) {
            options[current++] = "-M";
        }else if(m_linkageType == AL){
            options[current++] = "-V";
        }else if(m_linkageType == CL){
            options[current++] = "-E";
        }

        if(m_transpose){
            options[current++] = "-T";
        }
        options[current++] = "-N";
        options[current++] = "" + getNumClusters();

        while (current < options.length) {
            options[current++] = "";
        }

        return options;
    }

    public void setOptions(String[] options) throws Exception {
        if (Utils.getFlag('B', options)) {
            setDistanceType(new SelectedTag(CB, TAGS_DISTANCETYPE));
        }
        if (Utils.getFlag('C', options)) {
            setDistanceType(new SelectedTag(CC, TAGS_DISTANCETYPE));
        }
        if (Utils.getFlag('A', options)) {
            setDistanceType(new SelectedTag(ACC, TAGS_DISTANCETYPE));
        }
        if (Utils.getFlag('U', options)) {
            setDistanceType(new SelectedTag(UCC, TAGS_DISTANCETYPE));
        }
        if (Utils.getFlag('D', options)) {
            setDistanceType(new SelectedTag(AUCC, TAGS_DISTANCETYPE));
        }
        if (Utils.getFlag('S', options)) {
            setDistanceType(new SelectedTag(SP, TAGS_DISTANCETYPE));
        }
        if (Utils.getFlag('K', options)) {
            setDistanceType(new SelectedTag(KT, TAGS_DISTANCETYPE));
        }
        if (Utils.getFlag('M', options)) {
            setLinkageType(new SelectedTag(ML, TAGS_LINKAGETYPE));
        }
        if (Utils.getFlag('V', options)) {
            setLinkageType(new SelectedTag(AL, TAGS_LINKAGETYPE));
        }
        if (Utils.getFlag('E', options)) {
            setLinkageType(new SelectedTag(CL, TAGS_LINKAGETYPE));
        }
        setTranspose(Utils.getFlag('T',options));

        String optionString = Utils.getOption('N', options);
        if (optionString.length() != 0) {
            setNumClusters(Integer.parseInt(optionString));
        }

        Utils.checkForRemainingOptions(options);
    }
    public Enumeration listOptions() {

    Vector newVector = new Vector(12);
    newVector.addElement(new Option("\tSet distance type to be City-block distance.\n","B", 0, "-B"));
    newVector.addElement(new Option("\tSet distance type to be Correlation distance.\n","C", 0, "-C"));
    newVector.addElement(new Option("\tSet distance type to be Absolute Correlation.\n","A", 0, "-A"));
    newVector.addElement(new Option("\tSet distance type to be Uncentered Correlation.\n","U", 0, "-U"));
    newVector.addElement(new Option("\tSet distance type to be Absolute Uncentered Correlation.\n","D", 0, "-D"));
    newVector.addElement(new Option("\tSet distance type to be Spearman's Rank Correlation.\n","S", 0, "-S"));
    newVector.addElement(new Option("\tSet distance type to be Kendall's Tau.\n","K", 0, "-K"));
    newVector.addElement(new Option("\tSet linkage type to be Maximum(complete) Linkage.\n","M", 0, "-M"));
    newVector.addElement(new Option("\tSet linkage type to be Average Linkage.\n","V", 0, "-V"));
    newVector.addElement(new Option("\tSet linkage type to be Centriod Linkage.\n","E", 0, "-E"));
    newVector.addElement(new Option("\tSet transpose, if true, cluster the columns rather than rows.\n","T", 0, "-T"));
    newVector.addElement(new Option("\tSet the number of clusters.\n","N", 0, "-N"));
    return newVector.elements();
  }


    public void buildClusterer(Instances d) throws Exception{
        dataset = d;
        if (dataset.checkForStringAttributes()) {
            throw  new Exception("Can't handle string attributes!");
        }
        double data[][] = dataset.instancesToMatrix(m_transpose);
        results = new int[data.length-1][2];
        linkdist = new double[data.length-1];
        treecluster(data,null,null,results,linkdist);
        /* Scale all distances such that they are between 0 and 1 */
        if (m_distanceType==ED || m_distanceType==CB)
        {
            double scale = 0.0;
            for (int i = 0; i < linkdist.length; i++)
                if (linkdist[i] > scale) scale = linkdist[i];
            if (scale!=0){
                for (int i = 0; i < linkdist.length; i++) linkdist[i] /= scale;
            }
        }
        /* Now we join nodes */

        double [] nodeorder = new double[data.length-1];
        int [] nodecounts = new int[data.length-1];
        String [] nodeID = new String[data.length-1];
        double [] order = new double[data.length];

        for (int i = 0; i < nodeorder.length; i++)
        {
            int min1 = results[i][0];
            int min2 = results[i][1];
            /* min1 and min2 are the elements that are to be joined */
            double order1;
            double order2;
            int counts1;
            int counts2;
            String ID1;
            String ID2;
            nodeID[i] = MakeID ("NODE",i+1);
            if (min1 < 0)
            {
                int index1 = -min1-1;
                order1 = nodeorder[index1];
                counts1 = nodecounts[index1];
                ID1 = nodeID[index1];
                linkdist[i] = Math.max(linkdist[i],linkdist[index1]);
            }
            else
            {
                order1 = order[min1];
                counts1 = 1;
                ID1 = MakeID ("Sample", min1);
            }
            if (min2 < 0)
            {
                int index2 = -min2-1;
                order2 = nodeorder[index2];
                counts2 = nodecounts[index2];
                ID2 = nodeID[index2];
                linkdist[i] = Math.max(linkdist[i],linkdist[index2]);
            }
            else
            {
                order2 = order[min2];
                counts2 = 1;
                ID2 = MakeID ("Sample", min2);
            }

            //fprintf (file, "%s\t%s\t%s\t", nodeID[i], ID1, ID2);
            //fprintf (file, "%f\n", 1.0-NodeDistance[i]);
            System.out.print(nodeID[i]+"\t"+ID1+"\t"+ID2+"\t");
            System.out.print((1.0-linkdist[i])+"\n");
            nodecounts[i] = counts1 + counts2;
            nodeorder[i] = (counts1*order1 + counts2*order2)/(counts1 + counts2);
        }
        /* Now set up order based on the tree structure */
        treeSort ( data.length-1, order, nodeorder, nodecounts, results);
        for (int i = 0; i < results.length; i++) {
            System.out.println(results[i][0]+"\t"+results[i][1]);
        }

        //clusterid = new int[data.length];
        //cuttree(data.length,results,m_numClusters,clusterid);

    }
    public int clusterInstance(Instance instance) throws Exception {

        double [] dist = distributionForInstance(instance);

        if (dist == null) {
            throw new Exception("Null distribution predicted");
        }

        if (Utils.sum(dist) <= 0) {
            throw new Exception("Unable to cluster instance");
        }
        return Utils.maxIndex(dist);
  }
  public int numberOfClusters() throws Exception{
      return m_numClusters;
  }
  public double[] distributionForInstance(Instance instance)
    throws Exception {

    double[] d = new double[numberOfClusters()];

    d[clusterInstance(instance)] = 1.0;

    return d;
  }


    public HierarchicalClusterer()throws Exception {
    }

    /* ******************************************************************* */
    /*
             Purpose
             =======

             The treecluster routine performs hierarchical clustering using pairwise
             single-, maximum-, centroid-, or average-linkage, as defined by method, on a
             given set of gene expression data, using the distance metric given by dist.
             The function return 0 if a memory error occurs, and 1 otherwise.

             Arguments
             =========

             nrows     (input) int
             The number of rows in the data matrix, equal to the number of genes.

             ncolumns  (input) int
             The number of columns in the data matrix, equal to the number of microarrays.

             data       (input) double[nrows][ncolumns]
             The array containing the data of the vectors to be clustered.

             mask       (input) int[nrows][ncolumns]
             This array shows which data values are missing. If mask[i][j]==0, then
             data[i][j] is missing.

             weight (input) double array[n]
             The weights that are used to calculate the distance.

             transpose  (input) int
             If transpose==0, the rows of the matrix are clustered. Otherwise, columns
             of the matrix are clustered.

             dist       (input) char
             Defines which distance measure is used, as given by the table:
             dist=='e': Euclidean distance
             dist=='b': City-block distance
             dist=='c': correlation
             dist=='a': absolute value of the correlation
             dist=='u': uncentered correlation
             dist=='x': absolute uncentered correlation
             dist=='s': Spearman's rank correlation
             dist=='k': Kendall's tau
             For other values of dist, the default (Euclidean distance) is used.

             method     (input) char
             Defines which hierarchical clustering method is used:
             method=='s': pairwise single-linkage clustering
             method=='m': pairwise maximum- (or complete-) linkage clustering
             method=='a': pairwise average-linkage clustering
             method=='c': pairwise centroid-linkage clustering
             For the first three, either the distance matrix or the gene expression data is
             sufficient to perform the clustering algorithm. For pairwise centroid-linkage
             clustering, however, the gene expression data are always needed, even if the
             distance matrix itself is available.

             result  (output) int[nelements-1][2]
             The clustering solution. Each row in the matrix describes one linking event,
             with the two columns containing the name of the nodes that were joined.
             The original elements are numbered 0..nelements-1, nodes are numbered
             -1..-(nelements-1), where nelements is nrows or ncolumns depending on whether
             genes (rows) or microarrays (columns) are being clustered.
             If the treecluster routine fails due to lack of memory, the two columns of the
             first row of result are set to (0,0) before returning.

             linkdist (output) double[nelements-1]
             For each node, the distance between the two subnodes that were joined. The
             number of nodes (nnodes) is equal to the number of genes minus one if genes are
             clustered, or the number of microarrays minus one if microarrays are clustered.

             distmatrix (input) double**
             The distance matrix. If the distance matrix is zero initially, the distance
             matrix will be allocated and calculated from the data by treecluster, and
             deallocated before treecluster returns. If the distance matrix is passed by the
             calling routine, treecluster will modify the contents of the distance matrix as
             part of the clustering algorithm, but will not deallocate it. The calling
             routine should deallocate the distance matrix after the return from treecluster.

             ========================================================================
             */

    int treecluster (double [][] data,int [][] mask, double weight[], int result[][], double linkdist[]/*,double [][] distmatrix*/)
    {

        if(weight==null){
            weight = new double[data[0].length];
            for (int i = 0; i < weight.length; i++) {
                weight[i] = 1.;
            }
        }
        if(mask==null){
            mask = new int[data.length][data[0].length];
            for (int i = 0; i < mask.length; i++) {
                for (int j = 0; j < mask[0].length; j++) {
                    mask[i][j]=1;
                }
            }
        }
        //final int ldistmatrix = (distmatrix==null && method!='s') ? 1 : 0;
        int i;
        //if (nelements < 2) return 1;
        /* Calculate the distance matrix if the user didn't give it */
        //if(ldistmatrix){
        double distmatrix [][] = null;
        distmatrix = distancematrix(data, mask, weight);
        if (distmatrix==null) return 0; /* Insufficient memory */
        //}
        switch(m_linkageType){
            case SL:
              singleLinkageCluster(data,distmatrix,result, linkdist);
              break;
          case ML:
              maximumLinkageCluster(data.length,distmatrix,result,linkdist);
              break;
          case AL:
              averageLinkageCluster(data.length,distmatrix, result, linkdist);
              break;
          case CL:
              centriodLinkageCluster(data, mask, weight, distmatrix, result, linkdist);
              break;
          }
          for ( i = 0; i < result.length; i++) {
              System.out.println(result[i][0]+"\t"+result[i][1]);
          }
          return 1;
      }



      /*

      Purpose
      =======

      The pslcluster routine performs single-linkage hierarchical clustering, using
      either the distance matrix directly, if available, or by calculating the
      distances from the data array. This implementation is based on the SLINK
      algorithm, described in:
      Sibson, R. (1973). SLINK: An optimally efficient algorithm for the single-link
      cluster method. The Computer Journal, 16(1): 30-34.
      The output of this algorithm is identical to conventional single-linkage
      hierarchical clustering, but is much more memory-efficient and faster. Hence,
      it can be applied to large data sets, for which the conventional single-linkage algorithm fails due to lack of memory.
      */


      void singleLinkageCluster (double [][] data, double [][] distmatrix, int result[][], double linkdist[])
      {
          int i, j, k;
          int nelements = data.length;
          int nrows=data.length;
          int nnodes = nelements - 1;
          int [] vector = new int[nnodes];
          double [] temp = new double[nnodes];
          int [] index;

          for (i = 0; i < nnodes; i++){
              vector[i] = i;
              linkdist[i] = Double.MAX_VALUE;
          }
          for (i = 0; i < nrows; i++)
          { for (j = 0; j < i; j++) temp[j] = distmatrix[i][j];
              for (j = 0; j < i; j++)
              { k = vector[j];
                  if (linkdist[j] >= temp[j])
                  { if (linkdist[j] < temp[k]) temp[k] = linkdist[j];
                      linkdist[j] = temp[j];
                      vector[j] = i;
                  }
                  else if (temp[j] < temp[k]) temp[k] = temp[j];
              }
              for (j = 0; j < i; j++)
                  if (linkdist[j] >= linkdist[vector[j]]) vector[j] = i;
          }


          /* One of these days, I should write my own quicksort routine that takes
           * care of this reordering more efficiently. */
          index = new int[nelements-1];
          for (i = 0; i < index.length; i++) {
              index[i] = i;
          }
          weka.core.Utils.quickSort(linkdist,index,0,index.length-1);
          //sort(nnodes, linkdist, index);
          for (i = 0; i < nnodes; i++) temp[i] = linkdist[i];
          for (i = 0; i < nnodes; i++)
          { j = index[i];
              result[i][0] = j;
              linkdist[i] = temp[j];
          }
          for (i = 0; i < nelements; i++) index[i] = i;
          for (i = 0; i < nnodes; i++)
          { j = result[i][0];
              k = vector[j];
              result[i][0] = index[j];
              result[i][1] = index[k];
              index[k] = -i-1;
          }
          return;
      }



      /*

      Purpose
      =======

      The pmlcluster routine performs clustering using pairwise maximum- (complete-)
      linking on the given distance matrix.
*/
      void maximumLinkageCluster (int nelements, double [][] distmatrix, int result[][], double linkdist[])
      {
          int j;
          int nNodes;
          /* Setup a list specifying to which cluster a gene belongs */
          int[] clusterid = new int[nelements];
          for (j = 0; j < nelements; j++) clusterid[j] = j;

          for (nNodes = nelements; nNodes > 1; nNodes--)
          {
              int isaved[] = {1};
              int jsaved[] = {0};
              linkdist[nelements-nNodes] = find_closest_pair(nNodes, distmatrix, isaved, jsaved);

              /* Fix the distances */
              for (j = 0; j < jsaved[0]; j++)
                  distmatrix[jsaved[0]][j] = Math.max(distmatrix[isaved[0]][j],distmatrix[jsaved[0]][j]);
              for (j = jsaved[0]+1; j < isaved[0]; j++)
                  distmatrix[j][jsaved[0]] = Math.max(distmatrix[isaved[0]][j],distmatrix[j][jsaved[0]]);
              for (j = isaved[0]+1; j < nNodes; j++)
                  distmatrix[j][jsaved[0]] = Math.max(distmatrix[j][isaved[0]],distmatrix[j][jsaved[0]]);

              for (j = 0; j < isaved[0]; j++)
                  distmatrix[isaved[0]][j] = distmatrix[nNodes-1][j];
              for (j = isaved[0]+1; j < nNodes-1; j++)
                  distmatrix[j][isaved[0]] = distmatrix[nNodes-1][j];

              /* Update clusterids */
              result[nelements-nNodes][0] = clusterid[isaved[0]];
              result[nelements-nNodes][1] = clusterid[jsaved[0]];
              clusterid[jsaved[0]] = nNodes-nelements-1;
              clusterid[isaved[0]] = clusterid[nNodes-1];
          }
          return;
      }


      /*
      This function searches the distance matrix to find the pair with the shortest
      distance between them. The indeces of the pair are returned in ip and jp; the
      distance itself is returned by the function.

      n          (input) int
      The number of elements in the distance matrix.

      distmatrix (input) double**
      A ragged array containing the distance matrix. The number of columns in each
      row is one less than the row index.

      ip         (output) int*
      A pointer to the integer that is to receive the first index of the pair with
      the shortest distance.

      jp         (output) int*
      A pointer to the integer that is to receive the second index of the pair with
      the shortest distance.
      */
      double find_closest_pair(int n, double [][] distmatrix, int [] ip, int [] jp)
      { int i, j;
        double distance = distmatrix[1][0];
        for (i = 0; i < n; i++)
        { for (j = 0; j < i; j++)
          { if (distmatrix[i][j]<distance)
            { distance = distmatrix[i][j];
              ip[0] = i;
              jp[0] = j;
            }
          }
        }
        return distance;
    }

    /*
        Purpose
        =======

        The palcluster routine performs clustering using pairwise average
    linking on the given distance matrix.*/

    void averageLinkageCluster (int nelements, double[][] distmatrix, int result[][], double linkdist[])
    {
        int j;
        int nNodes;

        /* Keep track of the number of elements in each cluster
         * (needed to calculate the average) */
        int [] number = new int[nelements];
      /* Setup a list specifying to which cluster a gene belongs */
      int [] clusterid = new int[nelements];
      for (j = 0; j < nelements; j++)
      { number[j] = 1;
        clusterid[j] = j;
      }

      for (nNodes = nelements; nNodes > 1; nNodes--)
      { int sum;
        int isaved[] = {1};
        int jsaved[] = {0};
        linkdist[nelements-nNodes] = find_closest_pair(nNodes, distmatrix, isaved, jsaved);

        /* Save result */
        result[nelements-nNodes][0] = clusterid[isaved[0]];
        result[nelements-nNodes][1] = clusterid[jsaved[0]];

        /* Fix the distances */
        sum = number[isaved[0]] + number[jsaved[0]];
        for (j = 0; j < jsaved[0]; j++)
        { distmatrix[jsaved[0]][j] = distmatrix[isaved[0]][j]*number[isaved[0]]
                                + distmatrix[jsaved[0]][j]*number[jsaved[0]];
          distmatrix[jsaved[0]][j] /= sum;
        }
        for (j = jsaved[0]+1; j < isaved[0]; j++)
        { distmatrix[j][jsaved[0]] = distmatrix[isaved[0]][j]*number[isaved[0]]
                                + distmatrix[j][jsaved[0]]*number[jsaved[0]];
          distmatrix[j][jsaved[0]] /= sum;
        }
        for (j = isaved[0]+1; j < nNodes; j++)
        { distmatrix[j][jsaved[0]] = distmatrix[j][isaved[0]]*number[isaved[0]]
                                + distmatrix[j][jsaved[0]]*number[jsaved[0]];
          distmatrix[j][jsaved[0]] /= sum;
        }

        for (j = 0; j < isaved[0]; j++)
          distmatrix[isaved[0]][j] = distmatrix[nNodes-1][j];
        for (j = isaved[0]+1; j < nNodes-1; j++)
          distmatrix[j][isaved[0]] = distmatrix[nNodes-1][j];

        /* Update number of elements in the clusters */
        number[jsaved[0]] = sum;
        number[isaved[0]] = number[nNodes-1];

        /* Update clusterids */
        clusterid[jsaved[0]] = nNodes-nelements-1;
        clusterid[isaved[0]] = clusterid[nNodes-1];
      }
      return;
  }



  /*

 Purpose
 =======

 The pclcluster routine performs clustering using pairwise centroid-linking
 on a given set of gene expression data, using the distance metric given by dist.
 */
  void centriodLinkageCluster (double [][] data, int [][] mask, double weight[], double [][] distmatrix, int result[][], double linkdist[])
  {
      int i, j;
      int nelements = data.length;
      int [] distid = new int[nelements];
      int inode;
      int ndata = data[0].length;
      int nnodes = nelements - 1;

      /* Set the metric function as indicated by dist */
      //setmetric (dist, &metric);

      for (i = 0; i < nelements; i++) distid[i] = i;
      /* To remember which row/column in the distance matrix contains what */

      /* Storage for node data */
      double [][] newdata = new double[nelements][];
      int [][] newmask = new int[nelements][];
      for (i = 0; i < nelements; i++)
      {
          newdata[i] = new double[ndata];
          newmask[i] = new int[ndata];
          for (j = 0; j < ndata; j++)
          {
              newdata[i][j] = data[j][i];
              newmask[i][j] = mask[j][i];
          }
      }
      data = newdata;
      mask = newmask;
      for (inode = 0; inode < nnodes; inode++)
      { /* Find the pair with the shortest distance */
          int isaved[] = {1};
          int jsaved[] = {0};
          linkdist[inode] = find_closest_pair(nelements-inode, distmatrix, isaved, jsaved);
          result[inode][0] = distid[jsaved[0]];
          result[inode][1] = distid[isaved[0]];

          /* Make node jsaved the new node */
          for (i = 0; i < ndata; i++)
          { data[jsaved[0]][i] = data[jsaved[0]][i]*mask[jsaved[0]][i]
                                + data[isaved[0]][i]*mask[isaved[0]][i];
              mask[jsaved[0]][i] += mask[isaved[0]][i];
              if (mask[jsaved[0]][i]!=0) data[jsaved[0]][i] /= mask[jsaved[0]][i];
          }
          data[isaved[0]] = data[nnodes-inode];
          mask[isaved[0]] = mask[nnodes-inode];

          /* Fix the distances */
          distid[isaved[0]] = distid[nnodes-inode];
          for (i = 0; i < isaved[0]; i++)
              distmatrix[isaved[0]][i] = distmatrix[nnodes-inode][i];
          for (i = isaved[0] + 1; i < nnodes-inode; i++)
              distmatrix[i][isaved[0]] = distmatrix[nnodes-inode][i];

          distid[jsaved[0]] = -inode-1;
          for (i = 0; i < jsaved[0]; i++)
          { distmatrix[jsaved[0]][i] =
                        distance(ndata,data,data,mask,mask,weight,jsaved[0],i);
          }
          for (i = jsaved[0] + 1; i < nnodes-inode; i++)
          { distmatrix[i][jsaved[0]] =
                        distance(ndata,data,data,mask,mask,weight,jsaved[0],i);
          }
      }
      return;
  }


      /*
  Purpose
  =======

  The distancematrix routine calculates the distance matrix between genes or
  microarrays using their measured gene expression data. Several distance measures
  can be used. The routine returns a pointer to a ragged array containing the
  distances between the genes. As the distance matrix is symmetric, with zeros on
  the diagonal, only the lower triangular half of the distance matrix is saved.
  The distancematrix routine allocates space for the distance matrix. If the
  parameter transpose is set to a nonzero value, the distances between the columns
  (microarrays) are calculated, otherwise distances between the rows (genes) are
  calculated.
  If sufficient space in memory cannot be allocated to store the distance matrix,
  the routine returns a NULL pointer, and all memory allocated so far for the
  distance matrix is freed.


  Arguments
  =========

  nrows      (input) int
  The number of rows in the gene expression data matrix (i.e., the number of
  genes)

  ncolumns   (input) int
  The number of columns in the gene expression data matrix (i.e., the number of
  microarrays)

  data       (input) double[nrows][ncolumns]
  The array containing the gene expression data.

  mask       (input) int[nrows][ncolumns]
  This array shows which data values are missing. If
  mask(i,j) == 0, then data(i,j) is missing.

  weight (input) double[n]
  The weights that are used to calculate the distance. The length of this vector
  is equal to the number of columns if the distances between genes are calculated,
  or the number of rows if the distances between microarrays are calculated.

  dist       (input) char
  Defines which distance measure is used, as given by the table:
  dist=='e': Euclidean distance
  dist=='b': City-block distance
  dist=='c': correlation
  dist=='a': absolute value of the correlation
  dist=='u': uncentered correlation
  dist=='x': absolute uncentered correlation
  dist=='s': Spearman's rank correlation
  dist=='k': Kendall's tau
  For other values of dist, the default (Euclidean distance) is used.

  transpose  (input) int
  If transpose is equal to zero, the distances between the rows is
  calculated. Otherwise, the distances between the columns is calculated.
  The former is needed when genes are being clustered; the latter is used
  when microarrays are being clustered.

  ========================================================================
  */

   public double[][] distancematrix (double [][]data, int[][] mask,
                               double weights[])
    { /* First determine the size of the distance matrix */
        int n=data.length, ndata=data[0].length;
        int i,j;
        double [][] matrix = new double[n][];
        if (n < 2) return null;
        /* Calculate the distances and save them in the ragged array */
        for (i = 0; i < n; i++)
        {
            matrix[i] = new double[i];
            for (j = 0; j < i; j++)
                matrix[i][j]=distance(ndata,data,data,mask,mask,weights,i,j);
        }
        return matrix;
    }




    double distance(int ndata,double [][] data1,double [][] data2,int [][] mask1,int [][] mask2,
                  double[] weights,int i,int j)
    {
        switch(m_distanceType)
       {
        case ED: return euclid(ndata,data1,data2,mask1,mask2,weights,i,j);
        case CB: return cityblock(ndata,data1,data2,mask1,mask2,weights,i,j);
        case CC: return correlation(ndata,data1,data2,mask1,mask2,weights,i,j);
        case ACC: return acorrelation(ndata,data1,data2,mask1,mask2,weights,i,j);
        case UCC: return ucorrelation(ndata,data1,data2,mask1,mask2,weights,i,j);
        case AUCC: return uacorrelation(ndata,data1,data2,mask1,mask2,weights,i,j);
        case SP: return spearman(ndata,data1,data2,mask1,mask2,weights,i,j);
        case KT: return kendall(ndata,data1,data2,mask1,mask2,weights,i,j);
        default:  return euclid(ndata,data1,data2,mask1,mask2,weights,i,j);
      }
  }



  /*
Purpose
=======

The euclid routine calculates the weighted Euclidean distance between two
rows or columns in a matrix.

Arguments
=========

n      (input) int
The number of elements in a row or column. If transpose==0, then n is the number
of columns; otherwise, n is the number of rows.

data1  (input) double array
The data array containing the first vector.

data2  (input) double array
The data array containing the second vector.

mask1  (input) int array
This array which elements in data1 are missing. If mask1[i][j]==0, then
data1[i][j] is missing.

mask2  (input) int array
This array which elements in data2 are missing. If mask2[i][j]==0, then
data2[i][j] is missing.

weight (input) double[n]
The weights that are used to calculate the distance.

index1     (input) int
Index of the first row or column.

index2     (input) int
Index of the second row or column.

transpose (input) int
If transpose==0, the distance between two rows in the matrix is calculated.
Otherwise, the distance between two columns in the matrix is calculated.

============================================================================
*/

  double euclid (int n, double [][] data1, double [][] data2, int [][] mask1, int [][] mask2,
                 double weight[], int index1, int index2)
  {
      double result = 0.;
      double tweight = 0;
      int i;
      for (i = 0; i < n; i++){
          if (mask1[index1][i]!=0 && mask2[index2][i]!=0){
              double term = data1[index1][i] - data2[index2][i];
              result += weight[i]*term*term;
              tweight += weight[i];
          }
      }
      if (tweight==0) return 0; /* usually due to empty clusters */
      result /= tweight;
      return result;
  }


/*
Purpose
=======

The cityblock routine calculates the weighted "City Block" distance between
two rows or columns in a matrix. City Block distance is defined as the
absolute value of X1-X2 plus the absolute value of Y1-Y2 plus..., which is
equivalent to taking an "up and over" path.
*/

  double cityblock (int n, double [][] data1, double [][] data2, int [][] mask1,
                    int[][] mask2, double weight[], int index1, int index2)
  {
      double result = 0.;
      double tweight = 0;
      int i;
      /* Calculate the distance between two rows */
      for (i = 0; i < n; i++){
          if (mask1[index1][i]!=0 && mask2[index2][i]!=0){
              double term = data1[index1][i] - data2[index2][i];
              result = result + weight[i]*Math.abs(term);
              tweight += weight[i];
          }
      }
      if (tweight==0) return 0; /* usually due to empty clusters */
      result /= tweight;
      return result;
  }

/* ********************************************************************* */
  /*
             Purpose
             =======

             The correlation routine calculates the weighted Pearson distance between two
             rows or columns in a matrix. We define the Pearson distance as one minus the
             Pearson correlation.
             This definition yields a semi-metric: d(a,b) >= 0, and d(a,b) = 0 iff a = b.
             but the triangular inequality d(a,b) + d(b,c) >= d(a,c) does not hold
             (e.g., choose b = a + c).
             ============================================================================
           */
  double correlation (int n, double [][] data1, double [][] data2, int [][] mask1,
                      int [][] mask2, double weight[], int index1, int index2)

  {
      double result = 0.;
      double sum1 = 0.;
      double sum2 = 0.;
      double denom1 = 0.;
      double denom2 = 0.;
      double tweight = 0.;
      /* Calculate the distance between two rows */
      int i;
      for (i = 0; i < n; i++)
      { if (mask1[index1][i]!=0 && mask2[index2][i]!=0)
          { double term1 = data1[index1][i];
              double term2 = data2[index2][i];
              double w = weight[i];
              sum1 += w*term1;
              sum2 += w*term2;
              result += w*term1*term2;
              denom1 += w*term1*term1;
              denom2 += w*term2*term2;
              tweight += w;
          }
      }
      if (tweight == 0) return 0; /* usually due to empty clusters */
      result -= sum1 * sum2 / tweight;
      denom1 -= sum1 * sum1 / tweight;
      denom2 -= sum2 * sum2 / tweight;
      if (denom1 <= 0) return 1; /* include '<' to deal with roundoff errors */
      if (denom2 <= 0) return 1; /* include '<' to deal with roundoff errors */
      result = result / Math.sqrt(denom1*denom2);
      result = 1. - result;
      return result;
  }

/* ********************************************************************* */
  /*
  Purpose
  =======

  The acorrelation routine calculates the weighted Pearson distance between two
  rows or columns, using the absolute value of the correlation.
  This definition yields a semi-metric: d(a,b) >= 0, and d(a,b) = 0 iff a = b.
  but the triangular inequality d(a,b) + d(b,c) >= d(a,c) does not hold
(e.g., choose b = a + c).
*/

double acorrelation (int n, double[][] data1, double[][] data2, int[][] mask1,
                    int[][] mask2, double weight[], int index1, int index2)
    {
        double result = 0.;
        double sum1 = 0.;
        double sum2 = 0.;
        double denom1 = 0.;
        double denom2 = 0.;
        double tweight = 0.;
        /* Calculate the distance between two rows */
        int i;
        for (i = 0; i < n; i++)
        { if (mask1[index1][i]!=0 && mask2[index2][i]!=0)
            { double term1 = data1[index1][i];
                double term2 = data2[index2][i];
                double w = weight[i];
                sum1 += w*term1;
                sum2 += w*term2;
                result += w*term1*term2;
                denom1 += w*term1*term1;
                denom2 += w*term2*term2;
                tweight += w;
            }
        }
        if (tweight==0) return 0; /* usually due to empty clusters */
        result -= sum1 * sum2 / tweight;
        denom1 -= sum1 * sum1 / tweight;
        denom2 -= sum2 * sum2 / tweight;
        if (denom1 <= 0) return 1; /* include '<' to deal with roundoff errors */
        if (denom2 <= 0) return 1; /* include '<' to deal with roundoff errors */
        result = Math.abs(result) / Math.sqrt(denom1*denom2);
        result = 1. - result;
        return result;
    }

/* ********************************************************************* */
    /*
    Purpose
    =======

    The ucorrelation routine calculates the weighted Pearson distance between two
    rows or columns, using the uncentered version of the Pearson correlation. In the
    uncentered Pearson correlation, a zero mean is used for both vectors even if
    the actual mean is nonzero.
    This definition yields a semi-metric: d(a,b) >= 0, and d(a,b) = 0 iff a = b.
    but the triangular inequality d(a,b) + d(b,c) >= d(a,c) does not hold
(e.g., choose b = a + c).
*/
double ucorrelation (int n, double[][] data1, double[][] data2, int[][] mask1,
                    int[][] mask2, double weight[], int index1, int index2)
    {
        double result = 0.;
        double denom1 = 0.;
        double denom2 = 0.;
        int flag = 0;
        /* flag will remain zero if no nonzero combinations of mask1 and mask2 are
         * found.
         */
        // Calculate the distance between two rows */
       int i;
        for (i = 0; i < n; i++)
        { if (mask1[index1][i]!=0 && mask2[index2][i]!=0)
            { double term1 = data1[index1][i];
                double term2 = data2[index2][i];
                double w = weight[i];
                result += w*term1*term2;
                denom1 += w*term1*term1;
                denom2 += w*term2*term2;
                flag = 1;
            }
        }
        if (flag==0) return 0.;
        if (denom1==0.) return 1.;
        if (denom2==0.) return 1.;
        result = result / Math.sqrt(denom1*denom2);
        result = 1. - result;
        return result;
    }

/* ********************************************************************* */
    /*
    Purpose
    =======

    The uacorrelation routine calculates the weighted Pearson distance between two
    rows or columns, using the absolute value of the uncentered version of the
    Pearson correlation. In the uncentered Pearson correlation, a zero mean is used
    for both vectors even if the actual mean is nonzero.
    This definition yields a semi-metric: d(a,b) >= 0, and d(a,b) = 0 iff a = b.
    but the triangular inequality d(a,b) + d(b,c) >= d(a,c) does not hold
(e.g., choose b = a + c).
*/

double uacorrelation (int n, double[][] data1, double[][] data2, int[][] mask1,
                     int[][] mask2, double weight[], int index1, int index2)
    {
        double result = 0.;
        double denom1 = 0.;
        double denom2 = 0.;
        int flag = 0;
        /* flag will remain zero if no nonzero combinations of mask1 and mask2 are
         * found.
         */
        /* Calculate the distance between two rows */
        int i;
        for (i = 0; i < n; i++)
        { if (mask1[index1][i]!=0 && mask2[index2][i]!=0)
            { double term1 = data1[index1][i];
                double term2 = data2[index2][i];
                double w = weight[i];
                result += w*term1*term2;
                denom1 += w*term1*term1;
                denom2 += w*term2*term2;
                flag = 1;
            }
        }
        if (flag==0) return 0.;
        if (denom1==0.) return 1.;
        if (denom2==0.) return 1.;
        result = Math.abs(result) / Math.sqrt(denom1*denom2);
        result = 1. - result;
        return result;
    }

/* *********************************************************************  */
    /*
    Purpose
    =======

    The spearman routine calculates the Spearman distance between two rows or
    columns. The Spearman distance is defined as one minus the Spearman rank
correlation.
*/

double spearman (int n, double[][] data1, double[][] data2, int[][] mask1,
                int[][] mask2, double weight[], int index1, int index2)
    {
        double[] rank1;
        double[] rank2;
        double result = 0.;
        double denom1 = 0.;
        double denom2 = 0.;
        double avgrank;
        double[] tdata1 = new double[n];
        double[] tdata2 = new double[n];
        int i;
        int m = 0;
        for (i = 0; i < n; i++)
        { if (mask1[index1][i]!=0 && mask2[index2][i]!=0)
            { tdata1[m] = data1[index1][i];
                tdata2[m] = data2[index2][i];
                m++;
            }
        }
        if (m==0) return 0;
        rank1 = new double[m];
        rank2 = new double[m];
        getrank(m, tdata1, rank1);
        getrank(m, tdata2, rank2);
        avgrank = 0.5*(m-1); /* Average rank */
        for (i = 0; i < m; i++)
        { double value1 = rank1[i];
            double value2 = rank2[i];
            result += value1 * value2;
            denom1 += value1 * value1;
            denom2 += value2 * value2;
        }
  /* Note: denom1 and denom2 cannot be calculated directly from the number
   * of elements. If two elements have the same rank, the squared sum of
   * their ranks will change.
   */
  result /= m;
  denom1 /= m;
  denom2 /= m;
  result -= avgrank * avgrank;
  denom1 -= avgrank * avgrank;
  denom2 -= avgrank * avgrank;
  result = result / Math.sqrt(denom1*denom2);
  result = 1. - result;
  return result;
}


  void getrank (int n, double data[], double rank[])
  /* Calculates the ranks of the elements in the array data. Two elements with the
   * same value get the same rank, equal to the average of the ranks had the
   * elements different values.
   */
  { int i;
    int [] index = new int[n];
    for ( i = 0; i < index.length; i++) {
        index[i] = i;
    }
    /* Call sort to get an index table */
    //Utilis.qiuckSort(n, data, index);
    weka.core.Utils.quickSort(data,index,0,data.length-1);
    /* Build a rank table */
    for (i = 0; i < n; i++) rank[index[i]] = i;
    /* Fix for equal ranks */
    i = 0;
    while (i < n)
    { int m;
      double value = data[index[i]];
      int j = i + 1;
      while (j < n && data[index[j]] == value) j++;
      m = j - i; /* number of equal ranks found */
      value = rank[index[i]] + (m-1)/2.;
      for (j = i; j < i + m; j++) rank[index[j]] = value;
      i += m;
    }
    return;
  }

  /*
  Purpose
  =======

  The kendall routine calculates the Kendall distance between two
  rows or columns. The Kendall distance is defined as one minus Kendall's tau.
*/

  double kendall (int n, double [][] data1, double[][] data2, int[][] mask1, int[][] mask2,
                  double weight[], int index1, int index2)
  {
      int con = 0;
      int dis = 0;
      int exx = 0;
      int exy = 0;
      int flag = 0;
      /* flag will remain zero if no nonzero combinations of mask1 and mask2 are
       * found.
       */
      double denomx;
      double denomy;
      double tau;
      int i, j;
      for (i = 0; i < n; i++)
      { if (mask1[index1][i]!=0 && mask2[index2][i]!=0)
          { for (j = 0; j < i; j++)
              { if (mask1[index1][j]!=0 && mask2[index2][j]!=0)
                  { double x1 = data1[index1][i];
                      double x2 = data1[index1][j];
                      double y1 = data2[index2][i];
                      double y2 = data2[index2][j];
                      if (x1 < x2 && y1 < y2) con++;
                      if (x1 > x2 && y1 > y2) con++;
                      if (x1 < x2 && y1 > y2) dis++;
                      if (x1 > x2 && y1 < y2) dis++;
                      if (x1 == x2 && y1 != y2) exx++;
                      if (x1 != x2 && y1 == y2) exy++;
                      flag = 1;
                  }
              }
          }
      }
      if (flag==0) return 0.;
      denomx = con + dis + exx;
      denomy = con + dis + exy;
      if (denomx==0) return 1;
      if (denomy==0) return 1;
      tau = (con-dis)/Math.sqrt(denomx*denomy);
      return 1.-tau;
  }



    /*
    Purpose
    =======
    The cuttree routine takes the output of a hierarchical clustering routine, and
    divides the elements in the tree structure into clusters based on the
    hierarchical clustering result. The number of clusters is specified by the user.

nelements      (input) int
The number of elements that were clustered.

tree           (input) int[nelements-1][2]
The clustering solution. Each row in the matrix describes one linking event,
with the two columns containing the name of the nodes that were joined.
The original elements are numbered 0..nelements-1, nodes are numbered
-1..-(nelements-1). The cuttree routine checks the tree array for errors to
avoid segmentation faults. Errors in the tree array that would not cause
segmentation faults may pass undetected. If an error is found, all elements
are assigned to cluster -1, and the routine returns.

nclusters      (input) int
The number of clusters to be formed.

clusterid      (output) int[nelements]
The number of the cluster to which each element was assigned. Space for this
array should be allocated before calling the cuttree routine.

    */
    void cuttree (int nelements, int tree[][], int nclusters, int clusterid[])
    {
        int i, j, k;
        int icluster = 0;
        final int n = nelements-nclusters; /* number of nodes to join */
        int [] nodeid;
        /* Check the tree */
        int flag = 0;
        if (nclusters > nelements || nclusters < 1) flag = 1;
        for (i = 0; i < nelements-1; i++)
        { if (tree[i][0] >= nelements || tree[i][0] < -i ||
                tree[i][1] >= nelements || tree[i][1] < -i)
            { flag = 1;
                break;
            }
        }
        /* Assign all elements to cluster -1 and return if an error is found. */
        if (flag!=0)
        { for (i = 0; i < nelements; i++) clusterid[i] = -1;
            return;
        }
        /* The tree array is safe to use. */
        for (i = nelements-2; i >= n; i--)
        { k = tree[i][0];
            if (k>=0)
            { clusterid[k] = icluster;
                icluster++;
            }
            k = tree[i][1];
            if (k>=0)
            { clusterid[k] = icluster;
                icluster++;
            }
        }
        nodeid = new int[n];
        for (i = 0; i < n; i++) nodeid[i] = -1;
        for (i = n-1; i >= 0; i--)
        { if(nodeid[i]<0)
            { j = icluster;
                nodeid[i] = j;
                icluster++;
            }
            else j = nodeid[i];
            k = tree[i][0];
            if (k<0) nodeid[-k-1] = j; else clusterid[k] = j;
            k = tree[i][1];
            if (k<0) nodeid[-k-1] = j; else clusterid[k] = j;
        }
        return;
    }


    int [] treeSort(int nNodes,double [] order,
             double [] nodeorder, int [] nodecounts, int NodeElement[][])
    { int nElements = nNodes + 1;
      int i;
      double [] neworder = new double[nElements]; /* initialized to 0.0 */
      int [] clusterids = new int[nElements];
      for (i = 0; i < nElements; i++) clusterids[i] = i;
      for (i = 0; i < nNodes; i++)
      {
          int i1 = NodeElement[i][0];
          int i2 = NodeElement[i][1];
          double order1 = (i1<0) ? nodeorder[-i1-1] : order[i1];
          double order2 = (i2<0) ? nodeorder[-i2-1] : order[i2];
          int count1 = (i1<0) ? nodecounts[-i1-1] : 1;
          int count2 = (i2<0) ? nodecounts[-i2-1] : 1;
          /* If order1 and order2 are equal, their order is determined by
           * the order in which they were clustered */
          if (i1<i2)
          {
              double increase = (order1<order2) ? count1 : count2;
              int j;
              for (j = 0; j < nElements; j++)
              {
                  int clusterid = clusterids[j];
                  if (clusterid==i1 && order1>=order2) neworder[j] += increase;
                  if (clusterid==i2 && order1<order2) neworder[j] += increase;
                  if (clusterid==i1 || clusterid==i2) clusterids[j] = -i-1;
              }
          }
          else
          {
              double increase = (order1<=order2) ? count1 : count2;
              int j;
              for (j = 0; j < nElements; j++)
              {
                  int clusterid = clusterids[j];
                  if (clusterid==i1 && order1>order2) neworder[j] += increase;
                  if (clusterid==i2 && order1<=order2) neworder[j] += increase;
                  if (clusterid==i1 || clusterid==i2) clusterids[j] = -i-1;
              }
          }
      }
      int [] rindex = new int[nElements];
      for (i=0; i<rindex.length; i++) rindex[i] = i;
        weka.core.Utils.quickSort(neworder, rindex,0,rindex.length-1);
      return rindex;
    }


    String MakeID (String name, int i)
    {
        int n;
        String ID = new String(name+i+"X");
        return ID;
    }





}
