/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 *    Vote.java
 *    Copyright (C) 2000 Alexander K. Seewald
 *
 */

package weka.classifiers.meta;

import java.io.*;
import java.util.*;
import weka.core.*;
import weka.classifiers.*;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.Filter;

/**
 * Class for combining classifiers using unweighted average of
 * probability estimates (classification) or numeric predictions
 * (regression).
 *
 * Valid options from the command line are:<p>
 *
 * -B classifierstring <br>
 * Classifierstring should contain the full class name of a scheme
 * included for selection followed by options to the classifier
 * (required, option should be used once for each classifier).<p>
 *
 * @author Alexander K. Seewald (alex@seewald.at)
 * @author Eibe Frank (eibe@cs.waikato.ac.nz)
 * @version $Revision: 1.7 $
 */

public class Vote extends MultipleClassifiersCombiner {

  /**
   * Returns a string describing classifier
   * @return a description suitable for
   * displaying in the explorer/experimenter gui
   */
  //======================added by zexuan========================================
  public boolean m_metaFeature = false;
  public Remove[] featRemove;
  public int [][] bestAtts;
  public Instances traindata;
  protected File m_metaFeatureFile = new File(System.getProperty("user.dir"));

  public File getMetaFeatureFile() {
      return m_metaFeatureFile;
  }
  public void setMetaFeatureFile(File newDir) {
      m_metaFeatureFile = newDir;
      try {
          BufferedReader in = new BufferedReader(new FileReader(m_metaFeatureFile));
          String line;
          FastVector fv = new FastVector();
          while((line = in.readLine())!=null){
              fv.addElement(line);
          }
          bestAtts = new int[fv.size()][];
          for (int i = 0; i < bestAtts.length; i++) {
              String [] s = ((String)fv.elementAt(i)).split(",");
              int tmp [] = new int[s.length];
              for (int j = 0; j < tmp.length; j++) {
                  tmp[j] = Integer.parseInt(s[j]);
              }
              bestAtts[i] = tmp;
          }
      } catch (Exception ex) {
          ex.printStackTrace();
      }
  }


  public void setMetaFeature(boolean p){
      m_metaFeature = p;
  }
  public boolean getMetaFeature(){
      return m_metaFeature;
  }
  public void setBestAtts(int [][] a){
      bestAtts = a;
  }

  public void setFeatRemove()throws Exception{
      Remove delTransform[] = new Remove[bestAtts.length];
      for (int i = 0; i < bestAtts.length; i++) {
          delTransform[i] = new Remove();
          delTransform[i].setInvertSelection(true);
          int[] featArray = new int[bestAtts[i].length + 1];
          System.arraycopy(bestAtts[i], 0, featArray, 0, bestAtts[i].length);
          featArray[bestAtts[i].length] = traindata.classIndex();
          delTransform[i].setAttributeIndicesArray(featArray);
          delTransform[i].setInputFormat(traindata);
      }
      featRemove = delTransform;
  }



//  public String [] getOptions() {
//
//    String [] superOptions = super.getOptions();
//    int current = 0;
//    String[] options = new String [superOptions.length + 3];
////    if(m_metaFeature){
////        options[current++] = "-F";
////    }
////    options[current++] = "-N";
////    options[current++] = "" + getMetaFeatureFile();
//
//    System.arraycopy(superOptions, 0, options, current,
//                     superOptions.length);
//    return options;
//  }

//  public void setOptions(String[] options) throws Exception {
//
////    m_metaFeature = Utils.getFlag('F', options);
////    String f = Utils.getOption('N', options);
////    if (f.length() != 0) {
////      setMetaFeatureFile(new File(f));
////    }
//
//    super.setOptions(options);
//  }

//  public Enumeration listOptions()  {
//
//    Vector vec = new Vector(2);
//    Object c;
//
//    vec.addElement(new Option(
//           "\tSets the multiplier using meta feature. (default false)",
//       "F", 0, "-F"));
//    vec.addElement(new Option(
//              "\t File containing meta feature for each class, comma prelimited",
//              "N", 1, "-N <file>"));
//
//    Enumeration enu = super.listOptions();
//    while (enu.hasMoreElements()) {
//      vec.addElement(enu.nextElement());
//    }
//    return vec.elements();
//  }

  //=============================================================================

  public String globalInfo() {

    return "Class for combining classifiers using unweighted average of "
      + "probability estimates (classification) or numeric predictions "
      + "(regression).";
  }

  /**
   * Buildclassifier selects a classifier from the set of classifiers
   * by minimising error on the training data.
   *
   * @param data the training data to be used for generating the
   * boosted classifier.
   * @exception Exception if the classifier could not be built successfully
   */
  public void buildClassifier(Instances data) throws Exception {

    //Instances newData = new Instances(data);
    //newData.deleteWithMissingClass();
    //=============added by zexuan=======================
    traindata = data;
    if(m_metaFeature && bestAtts != null){
        setFeatRemove();
    }
    //===================================================
    for (int i = 0; i < m_Classifiers.length; i++) {
        //=================================added by zexuan========================
        Instances newInsts = new Instances(data);
        if(m_metaFeature){
            newInsts = Filter.useFilter(newInsts,featRemove[i]);
        }
        //========================================================================
        getClassifier(i).buildClassifier(newInsts);
    }
  }

  /**
   * Classifies a given instance using the selected classifier.
   *
   * @param instance the instance to be classified
   * @exception Exception if instance could not be classified
   * successfully
   */
  public double[] distributionForInstance(Instance instance) throws Exception {

      //=======modified by zexuan===========================
      Instance tempInst = (Instance)instance.copy();
      if(m_metaFeature){
          featRemove[0].input(tempInst);
          featRemove[0].batchFinished();
          tempInst = featRemove[0].output();
      }
      //===================================================

      double[] probs = getClassifier(0).distributionForInstance(tempInst);
    for (int i = 1; i < m_Classifiers.length; i++) {
      //=======modified by zexuan===========================
      tempInst = (Instance)instance.copy();
      if(m_metaFeature){
          featRemove[i].input(tempInst);
          featRemove[i].batchFinished();
          tempInst = featRemove[i].output();
      }
      //===================================================

      double[] dist = getClassifier(i).distributionForInstance(tempInst);
      for (int j = 0; j < dist.length; j++) {
	probs[j] += dist[j];
      }
    }
    for (int j = 0; j < probs.length; j++) {
      probs[j] /= (double)m_Classifiers.length;
    }
    return probs;
  }

  /**
   * Output a representation of this classifier
   */
  public String toString() {

    if (m_Classifiers == null) {
      return "Vote: No model built yet.";
    }

    String result = "Vote combines";
    result += " the probability distributions of these base learners:\n";
    for (int i = 0; i < m_Classifiers.length; i++) {
      result += '\t' + getClassifierSpec(i) + '\n';
    }

    return result;
  }

  /**
   * Main method for testing this class.
   *
   * @param argv should contain the following arguments:
   * -t training file [-T test file] [-c class index]
   */
  public static void main(String [] argv) {

    try {
      System.out.println(Evaluation.evaluateModel(new Vote(), argv));
    } catch (Exception e) {
      System.err.println(e.getMessage());
    }
  }

}
