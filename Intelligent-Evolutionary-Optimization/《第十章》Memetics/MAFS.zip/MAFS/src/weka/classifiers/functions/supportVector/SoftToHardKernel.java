package weka.classifiers.functions.supportVector;

import weka.core.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class SoftToHardKernel extends Kernel {
  Kernel softKernel;
  double C;
  public SoftToHardKernel(Kernel sk, double mc) {
     softKernel = sk;
     C = mc;
     m_data = sk.m_data;
     //softKernel.resetData(sk.m_data);
  }
  public int numEvals() {
    return softKernel.numEvals();
  }
  public void clean() {
    softKernel.clean();
  }
  public double eval(int id1, int id2, Instance inst1) throws java.lang.Exception {
    double e = softKernel.eval(id1,id2,inst1);
    if( id1==id2 ){
      e += 1.0/C;
    }
    return e;
  }
  public double gradientScale(int indexFeature,double scaleValue,int id1,int id2,Instance oinst1, Instance oinst2)throws Exception {
        return softKernel.gradientScale(indexFeature,scaleValue,id1,id2,oinst1,oinst2);
  }
  public double hessianScale(int d1,int d2, double sd1, double sd2, int id1,int id2, Instance oinst1, Instance oinst2)throws Exception{
      return softKernel.hessianScale(d1,d2,sd1,sd2,id1,id2,oinst1,oinst2);
  }

  public int numCacheHits(){
      return softKernel.numCacheHits();
  }
  public void resetData(Instances d){
     softKernel.resetData(d);
  }

  public double eval2i(Instance i1, Instance i2) throws Exception{

      return softKernel.eval2i(i1,i2);
  }


}
