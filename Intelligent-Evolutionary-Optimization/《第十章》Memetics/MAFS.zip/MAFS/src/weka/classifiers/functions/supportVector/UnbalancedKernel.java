package weka.classifiers.functions.supportVector;

import weka.core.Instance;
import weka.core.Instances;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class UnbalancedKernel extends Kernel{
    Kernel unbalancedKernel;
    double lamda;
    int c1=0,c2=0;
    public UnbalancedKernel(Kernel sk, double ld) {
        unbalancedKernel = sk;
        lamda = ld;
        m_data = sk.m_data;
        for (int i = 0; i < m_data.numInstances(); i++) {
            if((int)m_data.instance(i).classValue()==0){
                c1++;
            }else{
                c2++;
            }
        }
        //unbalancedKernel.resetData(sk.m_data);
    }
    public int numEvals() {
        return unbalancedKernel.numEvals();
    }
    public void clean() {
        unbalancedKernel.clean();
    }
    public double eval(int id1, int id2, Instance inst1) throws java.lang.Exception {
        double e = unbalancedKernel.eval(id1,id2,inst1);
        if( id1==id2 ){
            e += lamda*((int)m_data.instance(id1).classValue()==0 ? c1 : c2)/(c1+c2);
        }
        return e;
    }
    public double gradientScale(int indexFeature,double scaleValue,int id1,int id2,Instance oinst1, Instance oinst2)throws Exception {
        return unbalancedKernel.gradientScale(indexFeature,scaleValue,id1,id2,oinst1,oinst2);
    }
    public double hessianScale(int d1,int d2, double sd1, double sd2, int id1,int id2, Instance oinst1, Instance oinst2)throws Exception{
        return unbalancedKernel.hessianScale(d1,d2,sd1,sd2,id1,id2,oinst1,oinst2);
    }

    public int numCacheHits(){
        return unbalancedKernel.numCacheHits();
    }
    public void resetData(Instances d){
        unbalancedKernel.resetData(d);
    }

    public double eval2i(Instance i1, Instance i2) throws Exception{

        return unbalancedKernel.eval2i(i1,i2);
    }

}
