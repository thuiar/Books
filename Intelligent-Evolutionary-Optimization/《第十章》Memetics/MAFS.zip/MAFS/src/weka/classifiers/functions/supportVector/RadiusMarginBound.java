package weka.classifiers.functions.supportVector;

import com.imsl.math.QuadraticProgramming;
import java.io.Serializable;
import weka.core.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class RadiusMarginBound implements Serializable {
    public RadiusMarginBound() {
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    double [] alpha;
    SMOset m_supportVectors;
    Kernel m_kernel;
    Instances m_data;
    double W2;
    double R2;
    public double [] beta;
    double bound;
    double [] m_class;
    public double[] getBeta(){
        return beta;
    }
    public void setKernel(Kernel kk){
        m_kernel = kk;
    }
    public Kernel getKernel(){
        return m_kernel;
    }
    public void setData(Instances d){
        m_data = d;
    }
    public Instances getData(){
        return m_data;
    }
    public RadiusMarginBound(double [] a, Kernel kk, SMOset smos,Instances d,double [] cl) {
        alpha = a;

        m_kernel = kk;
        m_supportVectors = smos;
        m_data = d;
        W2 = 0;
        m_class = cl;
        //Utils.printArray("a",alpha);
    }

    public double getBound()throws Exception{
        //double R = 0.0;
        //double S = 0.0;
        int m_numInstances = m_data.numInstances();
        double k2[][] = new double[m_numInstances][m_numInstances];
        double g[] = new double[m_numInstances], bEquality[] = {1}, bInequality[] =new double[m_numInstances];
        double aEquality[][] = new double[1][m_numInstances],aInequality[][] = new double[m_numInstances][m_numInstances];
        for(int i = 0; i < m_numInstances; i++){
            bInequality[i] = 0;
            aEquality[0][i] = 1;
            aInequality[i][i] = 1;
            double kii = m_kernel.eval(i, i, m_data.instance(i));
            k2[i][i] = 2*kii;
            //System.out.print("v="+(m_data.instance(i).value(0))+"\tk="+kii+"\t");
            g[i] = -kii;
            //R += kii;
            //S += kii;
            for(int j = 0; j < i; j++){
                double kij = m_kernel.eval(i, j, m_data.instance(i));
                k2[i][j]=k2[j][i]=2*kij;
                aInequality[i][j] = aInequality[j][i] = 0;
                //S += kij + kij;
            }
          }
          //R = (R - S/m_numInstances)/m_numInstances;
          ///////////////////////////////////////////////////////////
          //System.out.println("\n");
          QuadraticProgramming qp = new QuadraticProgramming(k2, g, aEquality, bEquality, aInequality, bInequality);
          beta = qp.getSolution();
          //beta = new double[m_numInstances];
          //java.util.Arrays.fill(beta,1.0/beta.length);

          R2 = 0;
          for (int i = 0; i < m_numInstances; i++) {
              R2 += beta[i]*(-g[i]);
              R2 -= beta[i]*beta[i]*(-g[i]);
              for (int j = 0; j < i; j++) {
                  R2 -= beta[i]*beta[j]*k2[i][j];
              }
          }


          //////////////////////////////////////////////////////////////
          //double sumalpha = 0;
          //for(int i = m_supportVectors.getNext(-1); i != -1; i = m_supportVectors.getNext(i)){
            //sumalpha += alpha[i];
          //}

          W2 = 0;
          //System.out.print("alpha=");
          for (int i = 0; i < alpha.length; i++) {
              //System.out.print(alpha[i]+"\t");
              //W2 += alpha[i];
              W2 += alpha[i]*alpha[i]*k2[i][i]/2;
              for (int j = 0; j < i; j++) {
                  W2 += alpha[i]*alpha[j]*m_class[i]*m_class[j]*k2[i][j];
              }
          }
//          System.out.println("approximate:"+R);
//          System.out.println("optimized:"+R2);
//          System.out.println("W2: "+W2+"\tsumalpha: "+sumalpha);
//          System.out.println("astimate: "+(R * 0.5 * sumalpha)/m_numInstances);
//          System.out.println("op: "+(R2 * W2)/m_numInstances);
          //bound = (R * 0.5 * sumalpha)/m_numInstances;
          //System.out.println("instantRMB50v1="+m_data.instance(50).value(1));
          bound = (R2 * W2)/m_numInstances;
          //System.out.println("\nR2="+R2+"\tW2="+W2);
          //System.out.println("bount="+bound);
          return bound;

    }



    public double r2w2GradientScale(int attindex,double scale,Instances oriData)throws Exception{
        double gR2 = 0;
        double gW2 = 0;
        double kernelGradient = 0;
        for (int i = 0; i < m_data.numInstances(); i++) {
            kernelGradient = m_kernel.gradientScale(attindex,scale,i,i,oriData.instance(i),oriData.instance(i));
            gR2 += beta[i]*kernelGradient;
            gR2 -= beta[i]*beta[i]*kernelGradient;
            gW2 -= alpha[i]*alpha[i]*kernelGradient;
            for (int j = 0; j < i; j++) {
                kernelGradient = m_kernel.gradientScale(attindex,scale,i,j,oriData.instance(i),oriData.instance(j));
                gR2 -= 2*beta[i]*beta[j]*kernelGradient;
                gW2 -= 2*alpha[i]*alpha[j]*m_class[i]*m_class[j]*kernelGradient;
            }
            //System.out.println("");
        }
        //System.out.println(" gR2="+gR2+" gR3="+gR3+" g2="+(R2*gW2+W2*gR2)+" g3="+(R2*gW2+W2*gR3));
        return R2*gW2+W2*gR2;
    }


    public double r2w2HessianScale(int d1,int d2, double sd1, double sd2, Instances oriData)throws Exception{
        double gr2d1 = 0, gr2d2 = 0, gw2d1 = 0, gw2d2 = 0, gr2d1d2 = 0, gw2d1d2 = 0;
        double gkd1 = 0, gkd2 = 0, gkd1d2 = 0;
        for (int i = 0; i < m_data.numInstances(); i++) {
            gkd1 = m_kernel.gradientScale(d1,sd1,i,i,oriData.instance(i),oriData.instance(i));
            gkd2 = m_kernel.gradientScale(d2,sd2,i,i,oriData.instance(i),oriData.instance(i));
            gkd1d2 = m_kernel.hessianScale(d1,d2,sd1,sd2,i,i,oriData.instance(i),oriData.instance(i));
            gr2d1 += beta[i]*gkd1;
            gr2d2 += beta[i]*gkd2;
            gr2d1 -= beta[i]*beta[i]*gkd1;
            gr2d2 -= beta[i]*beta[i]*gkd2;
            gw2d1 -= alpha[i]*alpha[i]*gkd1;
            gw2d2 -= alpha[i]*alpha[i]*gkd2;
            gr2d1d2 += beta[i]*gkd1d2;
            gr2d1d2 -= beta[i]*beta[i]*gkd1d2;
            gw2d1d2 -= alpha[i]*alpha[i]*gkd1d2;
            for (int j = 0; j < i; j++) {
                gkd1 = m_kernel.gradientScale(d1,sd1,i,j,oriData.instance(i),oriData.instance(j));
                gkd2 = m_kernel.gradientScale(d2,sd2,i,j,oriData.instance(i),oriData.instance(j));
                gkd1d2 = m_kernel.hessianScale(d1,d2,sd1,sd2,i,j,oriData.instance(i),oriData.instance(j));
                gr2d1 -= 2*beta[i]*beta[j]*gkd1;
                gr2d2 -= 2*beta[i]*beta[j]*gkd2;
                gw2d1 -= 2*alpha[i]*alpha[j]*m_class[i]*m_class[j]*gkd1;
                gw2d2 -= 2*alpha[i]*alpha[j]*m_class[i]*m_class[j]*gkd2;
                gr2d1d2 -= 2*beta[i]*beta[j]*gkd1d2;
                gw2d1d2 -= 2*alpha[i]*alpha[j]*m_class[i]*m_class[j]*gkd1d2;
            }
            //System.out.println("");
        }

        return gr2d2*gw2d1+R2*gw2d1d2+gw2d2*gr2d1+W2*gr2d1d2;
    }





    private void jbInit() throws Exception {
    }
}
