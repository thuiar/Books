package weka.classifiers.functions.libsvm;

import com.imsl.math.QuadraticProgramming;
import weka.core.Utils;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class svm_rmb {
    SVC_Q s;
    double []alpha;
    double []beta;
    double W2;
    double R2;
    double bound;
    double m_class[];
    public svm_rmb(SVC_Q svcq, double a[]){
        s = svcq;
        alpha = a;
        //Utils.printArray("a",alpha);
    }
    public double getBound()throws Exception{
        //double R = 0.0;
        //double S = 0.0;
        int m_numInstances = alpha.length;
        double k2[][] = new double[m_numInstances][m_numInstances];
        double g[] = new double[m_numInstances], bEquality[] = {1}, bInequality[] =new double[m_numInstances];
        double aEquality[][] = new double[1][m_numInstances],aInequality[][] = new double[m_numInstances][m_numInstances];
        for(int i = 0; i < m_numInstances; i++){
            bInequality[i] = 0;
            aEquality[0][i] = 1;
            aInequality[i][i] = 1;
            double kii = s.kernel_function(i,i);
            k2[i][i] = 2*kii;
            //System.out.print("v="+s.x[i][0]+"\tk="+kii+"\t");
            g[i] = -kii;
            //R += kii;
            //S += kii;
            for(int j = 0; j < i; j++){
                double kij = s.kernel_function(i,j);
                k2[i][j]=k2[j][i]=2*kij;
                aInequality[i][j] = aInequality[j][i] = 0;
                //S += kij + kij;
            }
          }
          //R = (R - S/m_numInstances)/m_numInstances;
          ///////////////////////////////////////////////////////////
          //System.out.println("\n");
          QuadraticProgramming qp = new QuadraticProgramming(k2, g, aEquality, bEquality, aInequality, bInequality);
          beta = qp.getSolution();
          //beta = new double[m_numInstances];
          //java.util.Arrays.fill(beta,1.0/beta.length);

          R2 = 0;
          for (int i = 0; i < m_numInstances; i++) {
              R2 += beta[i]*(-g[i]);
              R2 -= beta[i]*beta[i]*(-g[i]);
              for (int j = 0; j < i; j++) {
                  R2 -= beta[i]*beta[j]*k2[i][j];
              }
          }


          //////////////////////////////////////////////////////////////
          //double sumalpha = 0;
          //for(int i = m_supportVectors.getNext(-1); i != -1; i = m_supportVectors.getNext(i)){
            //sumalpha += alpha[i];
          //}

          W2 = 0;
          //System.out.print("alpha=");
          for (int i = 0; i < alpha.length; i++) {
              //System.out.print(alpha[i]+"\t");
              //W2 += alpha[i];
              W2 += alpha[i]*alpha[i]*k2[i][i]/2;
              for (int j = 0; j < i; j++) {
                  W2 += alpha[i]*alpha[j]*k2[i][j];
              }
          }
//          System.out.println("approximate:"+R);
//          System.out.println("optimized:"+R2);
//          System.out.println("W2: "+W2+"\tsumalpha: "+sumalpha);
//          System.out.println("astimate: "+(R * 0.5 * sumalpha)/m_numInstances);
//          System.out.println("op: "+(R2 * W2)/m_numInstances);
          //bound = (R * 0.5 * sumalpha)/m_numInstances;
          //System.out.println("instantRMB50v1="+m_data.instance(50).value(1));
          bound = R2 * W2/m_numInstances;
          //System.out.println("\nR2="+R2+"\tW2="+W2);
          //System.out.println("bount="+bound);
          return bound;

    }

}
