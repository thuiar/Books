package weka.classifiers.functions.supportVector;

import weka.core.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class NoThresholdKernel extends Kernel {
  Kernel ok;
  double kernel[][];
  double s;
  public NoThresholdKernel(Kernel k) throws Exception{
    m_data = k.m_data;
    ok = k;
    s = 0;
    kernel = new double[k.m_data.numInstances()][k.m_data.numInstances()];
    for (int i = 0; i < k.m_data.numInstances(); i++) {
      kernel[i][i] = k.eval(i,i,k.m_data.instance(i));
      s += kernel[i][i];
      for (int j = 0; j < i; j++) {
        kernel[i][j] = k.eval(i,j,k.m_data.instance(i));
        kernel[j][i] = kernel[i][j];
        s += kernel[j][i] + kernel[i][j];
      }
    }
    s /= (k.m_data.numInstances()*k.m_data.numInstances());
  }
  public int numEvals() {
    return ok.numEvals();
  }
  public void clean() {
    kernel = null;
    ok.clean();
  }
  public double eval(int id1, int id2, Instance inst1) throws java.lang.Exception {
    double t1 = 0, t2 = 0;
    for (int i = 0; i < ok.m_data.numInstances(); i++) {
      t1 += kernel[id1][i];
      t2 += kernel[id2][i];
    }
    return kernel[id1][id2]-t1/ok.m_data.numInstances()-t2/ok.m_data.numInstances()+s;
  }
  public double gradientScale(int indexFeature,double scaleValue,int id1,int id2,Instance oinst1, Instance oinst2)throws Exception {
      return ok.gradientScale(indexFeature,scaleValue,id1,id2,oinst1,oinst2);
  }
  public double hessianScale(int d1,int d2, double sd1, double sd2, int id1, int id2, Instance oinst1, Instance oinst2)throws Exception{
      return ok.hessianScale(d1,d2,sd1,sd2,id1,id2,oinst1,oinst2);
  }


  public int numCacheHits(){
      return ok.numCacheHits();
  }
  public void resetData(Instances d){
      ok.resetData(d);
  }
  public double eval2i(Instance i1, Instance i2) throws Exception{

        return ok.eval2i(i1,i2);
  }

}
