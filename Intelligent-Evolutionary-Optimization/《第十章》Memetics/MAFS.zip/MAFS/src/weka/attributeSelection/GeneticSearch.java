/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 *    GeneticSearch.java
 *    Copyright (C) 1999 Mark Hall
 *
 */

package  weka.attributeSelection;


import  java.util.*;
import  weka.core.*;
import weka.gui.explorer.AttributeSelectionPanel;
import weka.attributeSelection.GA.*;
import java.io.*;

//import com.imsl.math.*;
/**
 * Class for performing a genetic based search. <p>
 *
 * For more information see: <p>
 * David E. Goldberg (1989). Genetic algorithms in search, optimization and
 * machine learning. Addison-Wesley. <p>
 *
 * Valid options are: <p>
 *
 * -Z <size of the population> <br>
 * Sets the size of the population. (default = 20). <p>
 *
 * -G <number of generations> <br>
 * Sets the number of generations to perform.
 * (default = 5). <p>
 *
 * -C <probability of crossover> <br>
 * Sets the probability that crossover will occur.
 * (default = .6). <p>
 *
 * -M <probability of mutation> <br>
 * Sets the probability that a feature will be toggled on/off. <p>
 *
 * -R <report frequency> <br>
 * Sets how frequently reports will be generated. Eg, setting the value
 * to 5 will generate a report every 5th generation. <p>
 * (default = number of generations). <p>
 *
 * -S <seed> <br>
 * Sets the seed for random number generation. <p>
 *
 * @author Mark Hall (mhall@cs.waikato.ac.nz)
 * @version $Revision: 1.14 $
 */
public class GeneticSearch extends GA implements
  StartSetHandler, OptionHandler {

  /**
   * holds a starting set as an array of attributes. Becomes one member of the
   * initial random population
   */
  private int[] m_starting;

  /** holds the start set for the search as a Range */
  private Range m_startRange;

 /** does the data have a class */
  private boolean m_hasClass;

  /** holds the class index */
  private int m_classIndex;

  /** number of attributes in the data */
  private int m_numAttribs;

  /** the current population */
  GABitSet [] m_population;

  /** the number of individual solutions */
  int m_popSize;

  /** the best population member found during the search */
  public GABitSet m_best;

  /** the number of features in the best population member */
  private int m_bestFeatureCount;

  /** the number of entries to cache for lookup */
  private int m_lookupTableSize;

  /** the lookup table */
  Hashtable m_lookupTable;

  /** random number generation */
  private Random m_random;

  /** seed for random number generation */
  private int m_seed;

  /** the probability of crossover occuring */
  private double m_pCrossover;

  /** the probability of mutation occuring */
  private double m_pMutation;

  /** sum of the current population fitness */
  private double m_sumFitness;

  private double m_maxFitness;
  private double m_minFitness;
  private double m_avgFitness;

  /** the maximum number of generations to evaluate */
  private int m_maxGenerations;

  /** how often reports are generated */
  private int m_reportFrequency;

  /** holds the generation reports */
  private StringBuffer m_generationReports;

  //===============added by zexuan=====================================
  protected int m_parallel = 0;
  protected boolean m_localSearch = false;
  protected GALocalSearch m_localSearchMethod = new FilterRanking();
  protected int m_finishGeneration;
  protected int m_crossoverType;
  public GABitSet topSolutions[] = new GABitSet[50];
  //defined crossover type
  public static final int ONE_POINT = 1;
  public static final int MULTI_POINT = 2;
  public static final int UNIFORM = 4;
  public static final Tag [] TAGS_CROSSOVERTYPE = {
    new Tag(ONE_POINT, "One Point Crossover"),
    new Tag(MULTI_POINT, "Multipoint Crossover"),
    new Tag(UNIFORM, "Uniform Crossover")
  };
  protected int m_mutationType;
  public static final int NM = 1;
  public static final int RM = 2;
  public static final Tag [] TAGS_MUTATIONTYPE = {
    new Tag(NM, "Normal Mutation"),
    new Tag(RM, "Ranking Mutation")
  };
  private ASEvaluation m_mutationRankingMethod;
  private int m_mutationPrivilegeRange;
  protected int [] attributesRank;

  protected int m_localSearchScope = 1;



  private double bestFitnessOnCalls;
  private StringBuffer m_fintnessCallsResults;
  private StringBuffer m_generationResults;
  private double m_optimum;
  protected long m_maxEvaluation = Long.MAX_VALUE;
  public long m_runningTime;
  protected int m_maxNumBin;
  protected int m_minNumBin;
  private double m_selectionPressure;
  protected int m_selectionType;
  public boolean m_startPoputlation = false;
    //defined crossover type
    public static final int FITNESS = 1;
    public static final int LRANK = 2;
    public static final int ERANK = 4;
    public static final Tag [] TAGS_SELECTIONTYPE = {
      new Tag(FITNESS, "Fittness Based Selection"),
      new Tag(LRANK, "Linear Rank Selection"),
      new Tag(ERANK, "Exponential Rank Selection")
  };

  private String m_evReport;
  public SubsetEvaluator ASEvaluator;
  //===================================================================

  /**
   * Returns an enumeration describing the available options.
   * @return an enumeration of all the available options.
   **/
  public Enumeration listOptions () {
    Vector newVector = new Vector(21);

    newVector.addElement(new Option("\tSpecify a starting set of attributes."
				    + "\n\tEg. 1,3,5-7."
				    +"If supplied, the starting set becomes"
				    +"\n\tone member of the initial random"
				    +"\n\tpopulation."
				    ,"P",1
				    , "-P <start set>"));
    newVector.addElement(new Option("\tSet the size of the population."
				    +"\n\t(default = 10)."
				    , "Z", 1
				    , "-Z <population size>"));
    newVector.addElement(new Option("\tSet the number of generations."
				    +"\n\t(default = 20)"
				    , "G", 1, "-G <number of generations>"));
    newVector.addElement(new Option("\tSet the probability of crossover."
				    +"\n\t(default = 0.6)"
				    , "C", 1, "-C <probability of"
				    +" crossover>"));
    newVector.addElement(new Option("\tSet the probability of mutation."
				    +"\n\t(default = 0.033)"
				    , "M", 1, "-M <probability of mutation>"));

    newVector.addElement(new Option("\tSet frequency of generation reports."
				    +"\n\te.g, setting the value to 5 will "
				    +"\n\t report every 5th generation"
				    +"\n\t(default = number of generations)"
				    , "R", 1, "-R <report frequency>"));
    newVector.addElement(new Option("\tSet the random number seed."
				    +"\n\t(default = 1)"
				    , "S", 1, "-S <seed>"));
    //==================added by zexuan========================================================
    newVector.addElement(new Option("\tSet number of parallel."
                                    +"\n\t(default = 0)"
                                    , "L",0, "-L <number of parallel>"));
    newVector.addElement(new Option("\tSet Local Search."
                                    +"\n\t(default = false)"
                                    , "H",0, "-H"));
    newVector.addElement(new Option("\tSet the heuristic for local search", "B", 1, "-B <instance evaluator>"));
    newVector.addElement(new Option("\tMulti points crossover","A", 0, "-A"));
    newVector.addElement(new Option("\tUniform crossover","U", 0, "-U"));
    //newVector.addElement(new Option("\tRanking Mutation","r", 0, "-r"));
    newVector.addElement(new Option("\tLinear Rank selection","s", 0, "-s"));
    newVector.addElement(new Option("\tExponential Rank selection","e", 0, "-e"));
    newVector.addElement(new Option("\tSet the local search scope","W",0,"-W <number>"));
    //newVector.addElement(new Option("\tSet the range of mutation privilege","w",0,"-w <number>"));
    newVector.addElement(new Option("\tSet the optimum objective."
                                    +"\n\t(default = 0)"
                                    , "O", 1, "-O <optimum>"));
    newVector.addElement(new Option("\tSet the maximum evaluation."
                                        +"\n\t(default ="+Long.MAX_VALUE+" )"
                                        , "J", 1, "-J <max evaluation>"));
    newVector.addElement(new Option("\tSet local search step size"
                                    , "l", 3, "-l <step size>"));

    newVector.addElement(new Option("\tSet chromosome size"
                                    , "c", -1, "-c <chromosome size>"));
    newVector.addElement(new Option("\tSet selection pressure","p", 0, "-p <pressure>"));
    newVector.addElement(new Option("\tSet the ranking method", "a", 1, "-a <instance evaluator>"));
    //========================================================================================================

    return  newVector.elements();
  }

  /**
   * Parses a given list of options.
   *
   * Valid options are: <p>
   *
   * -Z <size of the population> <br>
   * Sets the size of the population. (default = 20). <p>
   *
   * -G <number of generations> <br>
   * Sets the number of generations to perform.
   * (default = 5). <p>
   *
   * -C <probability of crossover> <br>
   * Sets the probability that crossover will occur.
   * (default = .6). <p>
   *
   * -M <probability of mutation> <br>
   * Sets the probability that a feature will be toggled on/off. <p>
   *
   * -R <report frequency> <br>
   * Sets how frequently reports will be generated. Eg, setting the value
   * to 5 will generate a report every 5th generation. <p>
   * (default = number of generations). <p>
   *
   * -S <seed> <br>
   * Sets the seed for random number generation. <p>
   *
   * @param options the list of options as an array of strings
   * @exception Exception if an option is not supported
   *
   **/
  public void setOptions (String[] options)
    throws Exception {
    String optionString;
    resetOptions();

    optionString = Utils.getOption('B', options);

    setLocalSearchMethod(GALocalSearch.forName(optionString,
				     Utils.partitionOptions(options)));

//    optionString = Utils.getOption('a', options);
//    setMutationRankingMethod(ASEvaluation.forName(optionString,Utils.partitionOptions(options)));

    optionString = Utils.getOption('P', options);
    if (optionString.length() != 0) {
      setStartSet(optionString);
    }

    optionString = Utils.getOption('p', options);
    if (optionString.length() != 0) {
        setSelectionPressure(Double.parseDouble(optionString));
    }

    optionString = Utils.getOption('J', options);
    if (optionString.length() != 0) {
      setMaxEvaluation(Long.parseLong(optionString));
    }

    optionString = Utils.getOption('Z', options);
    if (optionString.length() != 0) {
      setPopulationSize(Integer.parseInt(optionString));
    }

    optionString = Utils.getOption('G', options);
    if (optionString.length() != 0) {
      setMaxGenerations(Integer.parseInt(optionString));
      setReportFrequency(Integer.parseInt(optionString));
    }

    optionString = Utils.getOption('C', options);
    if (optionString.length() != 0) {
      setCrossoverProb((new Double(optionString)).doubleValue());
    }

    optionString = Utils.getOption('O', options);
    if (optionString.length() != 0) {
      setOptimum((new Double(optionString)).doubleValue());
    }


    optionString = Utils.getOption('M', options);
    if (optionString.length() != 0) {
      setMutationProb((new Double(optionString)).doubleValue());
    }

    optionString = Utils.getOption('R', options);
    if (optionString.length() != 0) {
      setReportFrequency(Integer.parseInt(optionString));
    }

    optionString = Utils.getOption('S', options);
    if (optionString.length() != 0) {
      setSeed(Integer.parseInt(optionString));
    }

    optionString = Utils.getOption('c', options);
    if (optionString.length() != 0) {
      setMaxNumBin(Integer.parseInt(optionString));
    }

    optionString = Utils.getOption('L', options);
    if (optionString.length() != 0) {
      setParallel(Integer.parseInt(optionString));
    }

    setLocalSearch(Utils.getFlag('H',options));

    if (Utils.getFlag('A', options)) {
      setCrossoverType(new SelectedTag(MULTI_POINT, TAGS_CROSSOVERTYPE));
    } else if (Utils.getFlag('U', options)) {
      setCrossoverType(new SelectedTag(UNIFORM, TAGS_CROSSOVERTYPE));
    } else {
      setCrossoverType(new SelectedTag(ONE_POINT, TAGS_CROSSOVERTYPE));
    }

    if (Utils.getFlag('s', options)) {
      setSelectionType(new SelectedTag(LRANK, TAGS_SELECTIONTYPE));
    } else if(Utils.getFlag('e', options)){
        setSelectionType(new SelectedTag(ERANK, TAGS_SELECTIONTYPE));
    }else{
      setSelectionType(new SelectedTag(FITNESS, TAGS_SELECTIONTYPE));
    }

//    if(Utils.getFlag('r',options)){
//        setMutationType(new SelectedTag(RM, TAGS_MUTATIONTYPE));
//    }else{
//        setMutationType(new SelectedTag(NM, TAGS_MUTATIONTYPE));
//    }

    optionString = Utils.getOption('W', options);
    if (optionString.length() != 0) {
      setLocalSearchScope((new Integer(optionString)).intValue());
    }

//    optionString = Utils.getOption('w', options);
//    if (optionString.length()!=0) {
//      setMutationPrivilegeRange((new Integer(optionString)).intValue());
//    }



  }

  /**
   * Gets the current settings of ReliefFAttributeEval.
   *
   * @return an array of strings suitable for passing to setOptions()
   */
  public String[] getOptions () {
    String[] localHeuristicOptions = new String[0];

    if ((m_localSearchMethod != null) &&
        (m_localSearchMethod instanceof OptionHandler)) {
      localHeuristicOptions = ((OptionHandler)m_localSearchMethod).getOptions();
    }

    String[] rankingOptions = new String[0];

    if (( m_mutationRankingMethod!= null) &&
        (m_mutationRankingMethod instanceof OptionHandler)) {
        rankingOptions = ((OptionHandler)m_mutationRankingMethod).getOptions();
    }

    String[] options = new String[49+localHeuristicOptions.length+rankingOptions.length];
    int current = 0;

    if (getLocalSearchMethod() != null) {
      options[current++] = "-B";
      options[current++] = getLocalSearchMethod().getClass().getName();
    }

//    if (getMutationRankingMethod() != null) {
//            options[current++] = "-a";
//            options[current++] = getMutationRankingMethod().getClass().getName();
//    }


    if (!(getStartSet().equals(""))) {
      options[current++] = "-P";
      options[current++] = ""+startSetToString();
    }
    if (m_crossoverType == MULTI_POINT) {
      options[current++] = "-A";
    } else if (m_crossoverType == UNIFORM) {
      options[current++] = "-U";
    }

    if (m_selectionType == LRANK) {
        options[current++] = "-s";
    }else if(m_selectionType == ERANK){
        options[current++] = "-e";
    }

    if(m_mutationType == RM){
        options[current++] = "-r";
    }

    options[current++] = "-W";
    options[current++] = "" + getLocalSearchScope();
    options[current++] = "-w";
//    options[current++] = "" + getMutationPrivilegeRange();
//    options[current++] = "-p";
    options[current++] = "" + getSelectionPressure();
    options[current++] = "-Z";
    options[current++] = "" + getPopulationSize();
    options[current++] = "-G";
    options[current++] = "" + getMaxGenerations();
    options[current++] = "-C";
    options[current++] = "" + getCrossoverProb();
    options[current++] = "-M";
    options[current++] = "" + getMutationProb();
    options[current++] = "-R";
    options[current++] = "" + getReportFrequency();
    options[current++] = "-S";
    options[current++] = "" + getSeed();
    options[current++] = "-c";
    options[current++] = "" + getMaxNumBin();
    options[current++] = "-O";
    options[current++] = "" + getOptimum();
    options[current++] = "-J";
    options[current++] = "" + getMaxEvaluation();
    options[current++] = "-L";
    options[current++] = "" + getParallel();

    if(m_localSearch){
      options[current++] = "-H";
    }
    options[current++] = "--";
    System.arraycopy(localHeuristicOptions, 0, options, current,
		     localHeuristicOptions.length);
    current += localHeuristicOptions.length;
    options[current++] = "--";
    System.arraycopy(rankingOptions, 0, options, current,
                     rankingOptions.length);
    current += rankingOptions.length;

    while (current < options.length) {
      options[current++] = "";
    }
    return  options;
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String startSetTipText() {
    return "Set a start point for the search. This is specified as a comma "
      +"seperated list off attribute indexes starting at 1. It can include "
      +"ranges. Eg. 1,2,5-9,17. The start set becomes one of the population "
      +"members of the initial population.";
  }

  /**
   * Sets a starting set of attributes for the search. It is the
   * search method's responsibility to report this start set (if any)
   * in its toString() method.
   * @param startSet a string containing a list of attributes (and or ranges),
   * eg. 1,2,6,10-15.
   * @exception Exception if start set can't be set.
   */
  public void setStartSet (String startSet) throws Exception {
    m_startRange.setRanges(startSet);
  }

  /**
   * Returns a list of attributes (and or attribute ranges) as a String
   * @return a list of attributes (and or attribute ranges)
   */
  public String getStartSet () {
    return m_startRange.getRanges();
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String seedTipText() {
    return "Set the random seed.";
  }

  /**
   * set the seed for random number generation
   * @param s seed value
   */
  public void setSeed(int s) {
    m_seed = s;
  }

  /**
   * get the value of the random number generator's seed
   * @return the seed for random number generation
   */
  public int getSeed() {
    return m_seed;
  }


  //======================added by zexuan======================
  public int getMaxNumBin(){
    return m_maxNumBin;
  }


  public void setMaxNumBin(int c){
    m_maxNumBin = c;
  }

  public int getMinNumBin(){
    return m_minNumBin;
  }


  public void setMinNumBin(int c){
    m_minNumBin = c;
  }


  public int getParallel(){
    return m_parallel;
  }
  public void setParallel(int p){
    m_parallel = p;
  }

  public boolean getLocalSearch(){
    return m_localSearch;
  }
  public void setLocalSearch(boolean p){
    m_localSearch = p;
  }


  public GALocalSearch getLocalSearchMethod(){
    return m_localSearchMethod;
  }



  public void setLocalSearchMethod(GALocalSearch a){
    m_localSearchMethod = a;
  }


  public SelectedTag getCrossoverType() {

    return new SelectedTag(m_crossoverType, TAGS_CROSSOVERTYPE);
  }

  public void setCrossoverType(SelectedTag type) {

    if (type.getTags() == TAGS_CROSSOVERTYPE) {
      m_crossoverType = type.getSelectedTag().getID();
    }
  }


//  public SelectedTag getMutationType() {
//
//    return new SelectedTag(m_mutationType, TAGS_MUTATIONTYPE);
//  }
//
//  public void setMutationType(SelectedTag type) {
//
//    if (type.getTags() == TAGS_MUTATIONTYPE) {
//      m_mutationType = type.getSelectedTag().getID();
//    }
//  }


  public SelectedTag getSelectionType() {

    return new SelectedTag(m_selectionType, TAGS_SELECTIONTYPE);
  }

  public void setSelectionType(SelectedTag type) {

    if (type.getTags() == TAGS_SELECTIONTYPE) {
      m_selectionType = type.getSelectedTag().getID();
    }
  }

//  public ASEvaluation getMutationRankingMethod(){
//      return m_mutationRankingMethod;
//  }
//
//  public void setMutationRankingMethod(ASEvaluation a){
//      m_mutationRankingMethod = a;
//  }

//  public int getMutationPrivilegeRange() {
//
//    return m_mutationPrivilegeRange;
//  }
//
//  public void setMutationPrivilegeRange(int scope) {
//      m_mutationPrivilegeRange = scope;
//  }



  public int getLocalSearchScope() {

    return m_localSearchScope;
  }

  public void setLocalSearchScope(int scope) {
      m_localSearchScope = scope;
  }


  public double getOptimum(){
    return m_optimum;
  }
  public void setOptimum(double o){
    m_optimum = o;
  }

  public long getMaxEvaluation(){
    return m_maxEvaluation;
  }
  public void setMaxEvaluation(long m){
    m_maxEvaluation = m;
  }

  public double getSelectionPressure(){
      return m_selectionPressure;
  }
  public void setSelectionPressure(double s){
      m_selectionPressure = s;
  }

  ////////////////////////////////////////////////////////

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String reportFrequencyTipText() {
    return "Set how frequently reports are generated. Default is equal to "
      +"the number of generations meaning that a report will be printed for "
      +"initial and final generations. Setting the value to 5 will result in "
      +"a report being printed every 5 generations.";
  }

  /**
   * set how often reports are generated
   * @param f generate reports every f generations
   */
  public void setReportFrequency(int f) {
    m_reportFrequency = f;
  }

  /**
   * get how often repports are generated
   * @return how often reports are generated
   */
  public int getReportFrequency() {
    return m_reportFrequency;
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String mutationProbTipText() {
    return "Set the probability of mutation occuring.";
  }

  /**
   * set the probability of mutation
   * @param m the probability for mutation occuring
   */
  public void setMutationProb(double m) {
    m_pMutation = m;
  }

  /**
   * get the probability of mutation
   * @return the probability of mutation occuring
   */
  public double getMutationProb() {
    return m_pMutation;
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String crossoverProbTipText() {
    return "Set the probability of crossover. This is the probability that "
      +"two population members will exchange genetic material.";
  }

  /**
   * set the probability of crossover
   * @param c the probability that two population members will exchange
   * genetic material
   */
  public void setCrossoverProb(double c) {
    m_pCrossover = c;
  }

  /**
   * get the probability of crossover
   * @return the probability of crossover
   */
  public double getCrossoverProb() {
    return m_pCrossover;
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String maxGenerationsTipText() {
    return "Set the number of generations to evaluate.";
  }

  /**
   * set the number of generations to evaluate
   * @param m the number of generations
   */
  public void setMaxGenerations(int m) {
    m_maxGenerations = m;
  }

  /**
   * get the number of generations
   * @return the maximum number of generations
   */
  public int getMaxGenerations() {
    return m_maxGenerations;
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String populationSizeTipText() {
    return "Set the population size. This is the number of individuals "
      +"(attribute sets) in the population.";
  }

  /**
   * set the population size
   * @param p the size of the population
   */
  public void setPopulationSize(int p) {
    m_popSize = p;
  }

  /**
   * get the size of the population
   * @return the population size
   */
  public int getPopulationSize() {
    return m_popSize;
  }

  /**
   * Returns a string describing this search method
   * @return a description of the search suitable for
   * displaying in the explorer/experimenter gui
   */
  public String globalInfo() {
    return "GeneticSearch :\n\nPerforms a search using the simple genetic "
      +"algorithm described in Goldberg (1989).\n";
  }

  /**
   * Constructor. Make a new GeneticSearch object
   */
  public GeneticSearch() {
    resetOptions();
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

  /**
   * converts the array of starting attributes to a string. This is
   * used by getOptions to return the actual attributes specified
   * as the starting set. This is better than using m_startRanges.getRanges()
   * as the same start set can be specified in different ways from the
   * command line---eg 1,2,3 == 1-3. This is to ensure that stuff that
   * is stored in a database is comparable.
   * @return a comma seperated list of individual attribute numbers as a String
   */
  private String startSetToString() {
    StringBuffer FString = new StringBuffer();
    boolean didPrint;

    if (m_starting == null) {
      return getStartSet();
    }

    for (int i = 0; i < m_starting.length; i++) {
      didPrint = false;

      if ((m_hasClass == false) ||
	  (m_hasClass == true && i != m_classIndex)) {
	FString.append((m_starting[i] + 1));
	didPrint = true;
      }

      if (i == (m_starting.length - 1)) {
	FString.append("");
      }
      else {
	if (didPrint) {
	  FString.append(",");
	  }
      }
    }

    return FString.toString();
  }

  /**
   * returns a description of the search
   * @return a description of the search as a String
   */
  public String toString() {
    StringBuffer GAString = new StringBuffer();
    GAString.append("\tGenetic search.\n\tStart set: ");

    if (m_starting == null) {
      GAString.append("no attributes\n");
    }
    else {
      GAString.append(startSetToString()+"\n");
    }
    GAString.append("\tPopulation size: "+m_popSize);
    GAString.append("\n\tChromosome size: from "+m_minNumBin+" to "+m_maxNumBin);
    GAString.append("\n\tNumber of generations: "+m_maxGenerations);
    GAString.append("\n\tProbability of crossover: "
		+Utils.doubleToString(m_pCrossover,6,3));
    GAString.append("\n\tCrossover Type: "+getCrossoverType().getSelectedTag().getReadable());
    GAString.append("\n\tSelection Type: "+getSelectionType().getSelectedTag().getReadable());
    if(m_selectionType == ERANK || m_selectionType == LRANK){
        GAString.append("\n\tSelection Pressure: "+getSelectionPressure());
    }
    GAString.append("\n\tProbability of mutation: "
                    +Utils.doubleToString(m_pMutation,6,3));
    //GAString.append("\n\tObjective error and num of feature: "+getObjectiveFunction());
    GAString.append("\n\tReport frequency: "+m_reportFrequency);
    GAString.append("\n\tRandom number seed: "+m_seed);
    GAString.append("\n\tLocal Search: "+m_localSearch);
    GAString.append(m_localSearchMethod.toString());
    GAString.append("\n\tLocal Search scope: "+getLocalSearchScope());
    ///////////////////////added by zexuan////////////////////////
    GAString.append("\n\tBest objective: "+Math.abs(m_best.getObjective()));
    //double errorrate = -m_best.getObjective()/countFeatures(m_best.getChromosome())*(m_numAttribs-1)-0.0001;
    GAString.append("\n\tNumber of Feature : "+countFeatures(m_best.getChromosome()));
    GAString.append("\n\tTimes of calling evaluator: "+numCallingEvaluator);
    GAString.append("\n\tRunning time: "+m_runningTime);
    GAString.append("\n\tFinish generation: "+m_finishGeneration);
    GAString.append("\n\t"+Math.abs(m_best.getObjective())+"\t"+countFeatures(m_best.getChromosome())+"\t"
                    +m_finishGeneration+"\t"+numCallingEvaluator+"\t"+m_runningTime);
    /////////////////////////////////////////////////////////////
    GAString.append(m_generationReports.toString());
    GAString.append("Generation Trace Start:\n"+m_generationResults+"\nGeneration Trace End\n");
    GAString.append("Fitness Trace Start:\n"+m_fintnessCallsResults+"Fitness Trace End.");
    GAString.append("\n"+m_evReport);
    return GAString.toString();
  }

  /**
   * Searches the attribute subset space using a genetic algorithm.
   *
   * @param ASEvaluator the attribute evaluator to guide the search
   * @param data the training instances.
   * @return an array (not necessarily ordered) of selected attribute indexes
   * @exception Exception if the search can't be completed
   */
   public int[] search (ASEvaluation ASEval, Instances data)
    throws Exception {
     long startTime = System.currentTimeMillis();
     m_finishGeneration = 1;
     numCallingEvaluator = 0;
     bestFitnessOnCalls = -Double.MAX_VALUE;
     m_best = null;
     m_generationReports = new StringBuffer();
     m_generationResults = new StringBuffer();
     m_fintnessCallsResults = new StringBuffer();

     if (!(ASEval instanceof SubsetEvaluator)) {
       throw  new Exception(ASEval.getClass().getName()
			    + " is not a "
			    + "Subset evaluator!");
     }

    if (ASEval instanceof UnsupervisedSubsetEvaluator) {
      m_hasClass = false;
    }
    else {
      m_hasClass = true;
      m_classIndex = data.classIndex();
    }

    ASEvaluator = (SubsetEvaluator)ASEval;
    if(ASEvaluator instanceof InstancesSelectSubsetEval){
        m_numAttribs = data.numInstances();
    }else{
        m_numAttribs = data.numAttributes();
    }

    if(m_minNumBin < 1) m_minNumBin = 1;
    if(m_minNumBin > m_numAttribs-1) m_minNumBin = m_numAttribs-1;
    if(m_maxNumBin > m_numAttribs-1) m_maxNumBin = m_numAttribs-1;
    if(m_maxNumBin < 0) m_maxNumBin = m_numAttribs-1;



    m_startRange.setUpper(m_numAttribs-1);
    if (!(getStartSet().equals(""))) {
      m_starting = m_startRange.getSelection();
    }

    // initial random population
    m_lookupTable = new Hashtable(m_lookupTableSize);
    m_random = new Random(m_seed);
    //m_random = new Random();
    m_population = new GABitSet [m_popSize];

    //===============added by zexuan=================================
    if (m_localSearch){
        m_localSearchMethod.buildLocalSearch(data,m_minNumBin,m_maxNumBin,this,ASEvaluator);
    }
    if(m_mutationType == RM){
        if(m_localSearchMethod.rankedAttributes!=null){
            attributesRank = Utils.sort(m_localSearchMethod.rankedAttributes);
        }else{
            m_mutationRankingMethod.buildEvaluator(data);
            Ranker rk = new Ranker();
            attributesRank = Utils.sort(rk.search(m_mutationRankingMethod,data));
        }
    }
    //==================================================================
    // set up random initial population
    initPopulation(data.relationName());
    evaluatePopulation(ASEvaluator);
    populationStatistics();
    scalePopulation();
    checkBest();
    m_generationReports.append(populationReport(0));

    boolean converged;
    for (int i=1;i<=m_maxGenerations;i++) {

      //========================added by zexuan==================================
      //System.out.println("\nData: "+data.relationName()+"\tGA generation: "+i+"\tBest objective: "+m_best.getObjective()+"\tNum of Feature: "+countFeatures(m_best.getChromosome())+"\t Num of function calls: "+numCallingEvaluator);
      m_generationResults.append("\n"+i+"\t"+m_best.getObjective()+"\t"+countFeatures(m_best.getChromosome()));
      m_finishGeneration = i;
      //==========================================================================
      if(Utils.eq(m_best.getObjective(),m_optimum) || Utils.gr(m_best.getObjective(),m_optimum)
         || numCallingEvaluator >= m_maxEvaluation){
         break;
      }
      generation();
      evaluatePopulation(ASEvaluator);
      populationStatistics();
      scalePopulation();
      // find the best pop member and check for convergence
      converged = checkBest();

//      if(Utils.eq(m_best.getObjective(),0) && m_best.getChromosome().cardinality()==4){
//          break;
//      }

      if ((i == m_maxGenerations) ||
	  ((i % m_reportFrequency) == 0) ||
	  (converged == true)) {
	m_generationReports.append(populationReport(i));
	if (converged == true) {
          break;
	}
      }
    }

    //==============save last population=================
    if(m_startPoputlation)
    saveLastPopulation(data.relationName());
    //===================================================

    WrapperSubsetEval wrapper = (WrapperSubsetEval)ASEvaluator;
    wrapper.evaluateSubset(m_best.getChromosome());
    m_evReport = wrapper.getEvaluationReport();
    m_runningTime = System.currentTimeMillis()-startTime;
    return attributeList(m_best.getChromosome());
   }

  /**
   * converts a BitSet into a list of attribute indexes
   * @param group the BitSet to convert
   * @return an array of attribute indexes
   **/
  private int[] attributeList (BitSet group) {
    int count = 0;

    // count how many were selected
    for (int i = 0; i < m_numAttribs; i++) {
      if (group.get(i)) {
	count++;
      }
    }

    int[] list = new int[count];
    count = 0;

    for (int i = 0; i < m_numAttribs; i++) {
      if (group.get(i)) {
	list[count++] = i;
      }
    }

    return  list;
  }

  public void checkTopSolutions(){
      OUTER: for (int i = 0; i < m_popSize; i++) {
        int minInTop = 0;
        for (int j = 0; j < topSolutions.length; j++) {
            if(topSolutions[j]==null){
                topSolutions[j] = m_population[i];
                continue OUTER;
            }else if(topSolutions[j].getChromosome().equals(m_population[i].getChromosome())){
                continue OUTER;
            }else{
                if(j==minInTop) continue;
                if(compareGABitSet(topSolutions[j],topSolutions[minInTop])==-1){
                    minInTop = j;
                }
            }
        }
        if(compareGABitSet(m_population[i],topSolutions[minInTop])==1){
            topSolutions[minInTop] = m_population[i];
        }
    }
  }


  /**
   * checks to see if any population members in the current
   * population are better than the best found so far. Also checks
   * to see if the search has converged---that is there is no difference
   * in fitness between the best and worse population member
   * @return true is the search has converged
   * @exception Exception if something goes wrong
   */
  private boolean checkBest() throws Exception {
    int i,j,count,lowestCount = m_numAttribs;
    double b = -Double.MAX_VALUE;
    GABitSet localbest = null;
    BitSet temp;
    boolean converged = false;
    int oldcount = Integer.MAX_VALUE;


    checkTopSolutions();
    if (m_maxFitness - m_minFitness > 0) {
      // find the best in this population
      for (i=0;i<m_popSize;i++) {
	if (m_population[i].getObjective() > b) {
	  b = m_population[i].getObjective();
	  localbest = m_population[i];
	  oldcount = countFeatures(localbest.getChromosome());
	} else if (Utils.eq(m_population[i].getObjective(), b)) {
	  // see if it contains fewer features
	  count = countFeatures(m_population[i].getChromosome());
	  if (count < oldcount) {
	    b = m_population[i].getObjective();
	    localbest = m_population[i];
	    oldcount = count;
	  }
	}
      }
    } else {
      // look for the smallest subset
      for (i=0;i<m_popSize;i++) {
	temp = m_population[i].getChromosome();
	count = countFeatures(temp);

	if (count < lowestCount) {
	  lowestCount = count;
	  localbest = m_population[i];
	  b = localbest.getObjective();
	}
      }
      converged = true;
    }

    // count the number of features in localbest
    count = 0;
    temp = localbest.getChromosome();
    count = countFeatures(temp);

    // compare to the best found so far
    if (m_best == null) {
      m_best = (GABitSet)localbest.clone();
      m_bestFeatureCount = count;
    } else if (b > m_best.getObjective()) {
      m_best = (GABitSet)localbest.clone();
      m_bestFeatureCount = count;
    } else if (Utils.eq(m_best.getObjective(), b)) {
      // see if the localbest has fewer features than the best so far
      if (count < m_bestFeatureCount) {
	m_best = (GABitSet)localbest.clone();
	m_bestFeatureCount = count;
      }
    }
    return converged;
  }

  /**
   * counts the number of features in a subset
   * @param featureSet the feature set for which to count the features
   * @return the number of features in the subset
   */
  public int countFeatures(BitSet featureSet) {
    int count = 0;
    for (int i=0;i<m_numAttribs;i++) {
      if (featureSet.get(i)) {
	count++;
      }
    }
    return count;
  }

  /**
   * performs a single generation---selection, crossover, and mutation
   * @exception Exception if an error occurs
   */
  public void generation () throws Exception {
    int i,j=0;
    double best_fit = -Double.MAX_VALUE;
    int old_count = 0;
    int count;
    GABitSet [] newPop = new GABitSet [m_popSize];
    int parent1,parent2;

    /** first ensure that the population best is propogated into the new
	generation */
    for (i=0;i<m_popSize;i++) {
      if (m_population[i].getFitness() > best_fit) {
	j = i;
	best_fit = m_population[i].getFitness();
	old_count = countFeatures(m_population[i].getChromosome());
      } else if (Utils.eq(m_population[i].getFitness(), best_fit)) {
	count = countFeatures(m_population[i].getChromosome());
	if (count < old_count) {
	  j = i;
	  best_fit = m_population[i].getFitness();
	  old_count = count;
	}
      }
    }
    newPop[0] = (GABitSet)(m_population[j].clone());
    //newPop[1] = newPop[0];

    int sorted [] = sortPopulation();

    for (j=1;j<m_popSize;j+=2) {

      if(m_selectionType == LRANK){
          parent1 = Utils.linearRankingSelection(sorted,m_selectionPressure,m_random);
          parent2 = Utils.linearRankingSelection(sorted,m_selectionPressure,m_random);
      }else if(m_selectionType == ERANK){
          parent1 = Utils.exponentialRankingSelection(sorted,m_selectionPressure,m_random);
          parent2 = Utils.exponentialRankingSelection(sorted,m_selectionPressure,m_random);
      }else{
        parent1 = select();
        parent2 = select();
      }

      newPop[j] = (GABitSet)(m_population[parent1].clone());
      newPop[j+1] = (GABitSet)(m_population[parent2].clone());
      // if parents are equal mutate one bit
      if (parent1 == parent2) {
	int r, cl;
        cl = m_maxNumBin;
	if (m_hasClass) {
	  while ((r = (Math.abs(m_random.nextInt()) % cl)) == m_classIndex);
	}else {
	  r = m_random.nextInt() % cl;
	}
        if(m_maxNumBin == m_numAttribs && m_minNumBin==1){
          if (newPop[j].get(r)){
              newPop[j].clear(r);
          }else {
              newPop[j].set(r);
          }
        }else{
          int a[] = bitSetToArray(newPop[j],m_maxNumBin);
          int b;
          if (m_hasClass) {
              b = Math.abs(m_random.nextInt()) % m_numAttribs;
              while (b == m_classIndex || Utils.contain(a,a.length,b)) b=(b+1)%m_numAttribs;
          }else {
              b = Math.abs(m_random.nextInt()) % m_numAttribs;
              while (Utils.contain(a,a.length,b)) b=(b+1)%m_numAttribs;
          }
          a[r] = b;
          newPop[j].setChromosome(arrayToBitSet(a));
        }
      } else {
	// crossover
        crossover(parent1,parent2,newPop[j],newPop[j+1]);
	// mutate
        mutation(newPop[j]);
        mutation(newPop[j+1]);
      }
    }

    m_population = newPop;
  }

  private void mutation(GABitSet g){
    Random random = new Random();
    double r;
    if(m_maxNumBin == m_numAttribs-1 && m_minNumBin == 1){ // unfix chromosome length
      for (int i=0;i<m_numAttribs;i++) {
          r = random.nextDouble();
          if (m_hasClass && (i == m_classIndex)) {
              continue;
          }
          if(m_mutationType == NM){
              if (r < m_pMutation) {
                  if (g.get(i)) {
                      g.clear(i);
                  } else {
                      g.set(i);
                  }
              }
          }
          if(m_mutationType == RM){
              double logsig = 1/(1+Math.exp(attributesRank[i]-m_mutationPrivilegeRange));
              double pm = logsig*m_pMutation;
              if(g.get(i) && r>pm) {
                  g.clear(i);
              }
              if(!g.get(i) && r<pm){
                  g.set(i);
              }
          }
      }
    }else{//fixed chromosome length
      int [] a = bitSetToArray(g,m_maxNumBin);
      for (int i = 0; i < a.length; i++) {
          r = random.nextDouble();
          if (m_mutationType == NM) {
              if (r < m_pMutation) {
                  if(a[i]!=-1 && i>=m_minNumBin){
                      r = random.nextDouble();
                        if(r<0.5){
                            a[i] = -1;
                        }else{
                            int b = random.nextInt(m_numAttribs);
                            while (b == m_classIndex || Utils.contain(a, a.length, b)) {
                                b = (b+1)%m_numAttribs;
                            }
                            a[i] = b;
                        }
                  }else{
                      int b = random.nextInt(m_numAttribs);
                      while (b == m_classIndex || Utils.contain(a, a.length, b)) {
                          b = (b+1)%m_numAttribs;
                      }
                      a[i] = b;
                  }
              }
          }
          if(m_mutationType == RM){
              if(a[i]!=-1){
                  double logsig = 1/(1+Math.exp(attributesRank[a[i]]-m_mutationPrivilegeRange));
                  double pm = logsig*m_pMutation;
                  if(r>pm){
                     a[i]=-1;
                  }
              }else{
                  int b = random.nextInt(m_numAttribs);
                  while (b == m_classIndex || Utils.contain(a, a.length, b)) {
                      b = random.nextInt(m_numAttribs);
                  }
                  double logsig = 1/(1+Math.exp(attributesRank[b]-m_mutationPrivilegeRange));
                  double pm = logsig*m_pMutation;
                  if(r<pm){
                     a[i] = b;
                  }
              }

          }
      }
      g.setChromosome(arrayToBitSet(a));
    }
  }

  public int[] bitSetToArray(GABitSet bs,int length){
    //System.out.println("b2a"+bs.getChromosome());
    int [] bsa = new int[length];
    int j = 0;
    for (int i = 0; i < m_numAttribs; i++) {
      if(bs.get(i)){
        bsa[j++] = i;
      }
    }
    for(;j<length;j++){
      bsa[j] = -1;
    }
    return bsa;
  }

  private BitSet arrayToBitSet(int bsa []){

   BitSet bs = new BitSet();
   for (int i = 0; i < bsa.length; i++) {
     if(bsa[i] != -1){
       bs.set(bsa[i]);
     }
   }
   return bs;
  }


  private void crossover(int parent1,int parent2,GABitSet child1,GABitSet child2){
    double r = m_random.nextDouble();
    if (m_numAttribs >= 3) {
      if (r < m_pCrossover) {
        //uniform crossover
        if(m_crossoverType ==  UNIFORM){
          if(m_maxNumBin < m_numAttribs-1 || m_minNumBin > 1){ //fix length of chromosome
              int p1[] = bitSetToArray(m_population[parent1],m_maxNumBin);
              int p2[] = bitSetToArray(m_population[parent2],m_maxNumBin);
              int c1[] = new int[m_maxNumBin];
              int c2[] = new int[m_maxNumBin];
              Random random = new Random();
              double xoverr;
              for (int i = 0; i < m_maxNumBin; i++) {
                xoverr = random.nextDouble();
                if (xoverr < 0.5) {
                        if(!Utils.contain(c1,i,p2[i]) && !Utils.contain(c2,i,p1[i])){
                            c1[i] = p2[i];
                            c2[i] = p1[i];
                        }else{
                            c1[i] = p1[i];
                            c2[i] = p2[i];
                        }
                    }else{
                        if(!Utils.contain(c1,i,p1[i]) && !Utils.contain(c2,i,p2[i])){
                            c1[i] = p1[i];
                            c2[i] = p2[i];
                        }else{
                            c1[i] = p2[i];
                            c2[i] = p1[i];
                        }
                    }
              }

//              BitSet a = arrayToBitSet(c1);
//              BitSet b = arrayToBitSet(c2);
//              if(a.cardinality()< m_minNumBin || b.cardinality()< m_minNumBin ){
//                  System.out.println("p1="+Utils.arrayToString(p1)+"\t"+m_population[parent1].getChromosome().cardinality());
//                  System.out.println("p2="+Utils.arrayToString(p2)+"\t"+m_population[parent2].getChromosome().cardinality());
//                  System.out.println("c1="+Utils.arrayToString(c1));
//                  System.out.println("c2="+Utils.arrayToString(c2));
//              }

              child1.setChromosome(arrayToBitSet(c1));
              child2.setChromosome(arrayToBitSet(c2));
          }else{ //unfix length of chromosome
              Random random = new Random();
              double xoverr;
              for (int i = 0; i < m_numAttribs - 1; i++) {
                xoverr = random.nextDouble();
                if (xoverr < 0.5) {
                  if (m_population[parent1].get(i)) {
                    child2.set(i);
                  } else {
                    child2.clear(i);
                  }
                  if (m_population[parent2].get(i)) {
                    child1.set(i);
                  } else {
                    child1.clear(i);
                  }
                }
              }

          }
        }else{ //onepoint or multipoint crossover
          int numPoint = 1;
          if(m_maxNumBin == m_numAttribs-1 && m_minNumBin==1){//unfixed chromosome length
            if(m_crossoverType ==  MULTI_POINT){
              numPoint = m_random.nextInt(m_numAttribs-2);
              numPoint ++;
            }
            int [] cp = new int[numPoint];
            for (int i = 0, lastPoint = 0; i < numPoint; i++) {
              cp[i] = Math.abs(m_random.nextInt(m_numAttribs-2-(numPoint-i-1)-lastPoint));
              cp[i] += lastPoint;
              cp[i] ++;
              lastPoint = cp[i];
            }

            for(int i=0,begin=0,end=cp[i];;){
              for (int j=begin;j<end;j++) {
                if (m_population[parent1].get(j)) {
                    child2.set(j);
                }else {
                    child2.clear(j);
                }
                if (m_population[parent2].get(j)) {
                    child1.set(j);
                }else {
                    child1.clear(j);
                }
              }
              i+=2;
              if(i<numPoint){
                begin = cp[i-1];
                end = cp[i];
              }else if(i == numPoint){
                begin = cp[i-1];
                end = m_numAttribs-1;
              }else{
                break;
              }
            }
          }else{ //fix chromosome length
            if(m_crossoverType ==  MULTI_POINT){
              numPoint = m_random.nextInt(m_maxNumBin);
              numPoint ++;
            }
            int [] cp = new int[numPoint];
            for (int i = 0, lastPoint = 0; i < numPoint; i++) {
              cp[i] = Math.abs(m_random.nextInt(m_maxNumBin-1-(numPoint-i-1)-lastPoint));
              cp[i] += lastPoint;
              cp[i] ++;
              lastPoint = cp[i];
            }
            int p1[] = bitSetToArray(m_population[parent1],m_maxNumBin);
            int p2[] = bitSetToArray(m_population[parent2],m_maxNumBin);
            int c1[] = bitSetToArray(child1,m_maxNumBin);
            int c2[] = bitSetToArray(child2,m_maxNumBin);
            for(int i=0,begin=0,end=cp[i];;){
              for (int j=begin;j<end;j++) {
                if(!Utils.contain(c2,j,p1[j]) && !Utils.contain(c1,j,p2[j])){
                    c2[j] = p1[j];
                    c1[j] = p2[j];
                }
              }
              i+=2;
              if(i<numPoint){
                begin = cp[i-1];
                end = cp[i];
              }else if(i == numPoint){
                begin = cp[i-1];
                end = m_maxNumBin;
              }else{
                break;
              }
            }
            child1.setChromosome(arrayToBitSet(c1));
            child2.setChromosome(arrayToBitSet(c2));
          }//end of fixed chromosome length
        }//end of one/multi point
      }
    }
  }

  /**
   * selects a population member to be considered for crossover
   * @return the index of the selected population member
   */
  private int select() {
    int i;
    double r,partsum;

    partsum = 0;
    r = m_random.nextDouble() * m_sumFitness;
    for (i=0;i<m_popSize;i++) {
      partsum += m_population[i].getFitness();
      if (partsum >= r) {
	break;
      }
    }
    return i;
  }

  /**
   * evaluates an entire population. Population members are looked up in
   * a hash table and if they are not found then they are evaluated using
   * ASEvaluator.
   * @param ASEvaluator the subset evaluator to use for evaluating population
   * members
   * @exception Exception if something goes wrong during evaluation
   */
  private void evaluatePopulation (SubsetEvaluator ASEvaluator)
    throws Exception {

  calculateFitness(ASEvaluator,m_population);
  //========================local search=====================================
  if (m_localSearch) {
    localSearch(ASEvaluator);
  }
  //=========================================================================

}

  public void calculateFitness(SubsetEvaluator ASEvaluator,GABitSet [] gabs) throws Exception{
    double objective;
    ////////////////////////parallel/////////////////////////////////////
    if(m_parallel > 0){
        WrapperSubsetEval wrapper = (WrapperSubsetEval)ASEvaluator;
        String [] options = wrapper.getOptions();
        String inputFile = AttributeSelectionPanel.externalCV ? "temp.arff" : AttributeSelectionPanel.dataFile;
        for (int i=0;i<gabs.length;) {
          // if its not in the lookup table then evaluate and insert
          if(countFeatures(gabs[i].getChromosome())==0){
            gabs[i].setObjective(-1);
            i++;
            continue;
          }
          FitnessThread [] fts = new FitnessThread[m_parallel];
          int [] g = new int[m_parallel];
          for (int j = 0; j <m_parallel && i < gabs.length; i++) {
              g[j] = -1;
              if (m_lookupTable.containsKey(gabs[i].getChromosome()) == false) {
                  fts[j] = new FitnessThread(wrapper.getClass().getName(),options,inputFile,gabs[i].getChromosome().toString().replaceAll(" ",""),i,1);
                  g[j] = i;
                  numCallingEvaluator++;
                  j++;
              }
              else{
                  GABitSet temp = (GABitSet)m_lookupTable.get(gabs[i].getChromosome());
                  gabs[i].setObjective(temp.getObjective());
              }
          }
          for (int j = 0; j < m_parallel; j++) {
              if (fts[j]!=null) {
                  fts[j].join();
              }
          }
          for (int j = 0; j < m_parallel; j++) {
              if (fts[j]!=null) {
                  objective = fts[j].merit;
                  gabs[g[j]].setObjective(objective);
                  m_lookupTable.put(gabs[g[j]].getChromosome(),gabs[g[j]]);
              }
          }
        }
      }else{ //================no parallel====================================
        for (int i = 0; i < gabs.length; i++) {
            /*switch(i%2){
                case 0:
                    System.out.print("-"); break;
                case 1:
                    System.out.print("*"); break;
                default:;
            }*/

          // if its not in the lookup table then evaluate and insert
          if(countFeatures(gabs[i].getChromosome())==0){
            gabs[i].setObjective(-1);
            continue;
          }
          if (m_lookupTable.containsKey(gabs[i].getChromosome()) == false) {
            objective = ASEvaluator.evaluateSubset(gabs[i].getChromosome());
            //System.out.println("o="+objective+"\tb="+bestFitnessOnCalls);
            numCallingEvaluator++;
            if(objective > bestFitnessOnCalls){
                bestFitnessOnCalls = objective;
                m_fintnessCallsResults.append(numCallingEvaluator+"\t"+bestFitnessOnCalls+"\t"+countFeatures(gabs[i].getChromosome())+"\n");
            }else{
                m_fintnessCallsResults.append(numCallingEvaluator+"\t"+bestFitnessOnCalls+"\t"+m_bestFeatureCount+"\n");
            }
            //if(m_ErrAndNoFeature){
            //  objective = (objective-0.0001)*(countFeatures(gabs[i].getChromosome())/(m_numAttribs-1.0));
            //}
            gabs[i].setObjective(objective);
            m_lookupTable.put(gabs[i].getChromosome(), gabs[i]);
          } else {
            GABitSet temp = (GABitSet) m_lookupTable.get(gabs[i].getChromosome());
            gabs[i].setObjective(temp.getObjective());
          }
        }
      }
    }

  private void localSearch(SubsetEvaluator ASEvaluator)throws Exception{

      GABitSet bestclone[];
      int bestindex[];
      int numCandidate = 1;
      if(m_localSearchScope == -1 || m_localSearchScope >= m_popSize){
          numCandidate = m_popSize;
      }else{
          numCandidate = m_localSearchScope;
      }
      bestclone = new GABitSet[numCandidate];
      bestindex = new int[numCandidate];

      localSearchCandidate(bestclone,bestindex);
      for (int i = 0; i < bestclone.length; i++) {
          m_population[bestindex[i]] = m_localSearchMethod.search(bestclone[i]);
      }
  }

  //if a better than b return 1, a==b return 0, a less than b return -1
  public int compareGABitSet(GABitSet a,GABitSet b){
    if(Utils.gr(a.getObjective(), b.getObjective())){
      return 1;
    }
    if(Utils.eq(a.getObjective(), b.getObjective())){
      if(countFeatures(a.getChromosome())<countFeatures(b.getChromosome())){
        return 1;
      }else if(countFeatures(a.getChromosome())==countFeatures(b.getChromosome())){
        return 0;
      }
    }
    return -1;
  }


  private void localSearchCandidate(GABitSet [] bestclone, int [] bestindex)throws Exception{
    if(m_localSearchScope == -1 || m_localSearchScope >= m_popSize){
      for (int i = 0; i < m_popSize; i++) {
        bestclone[i] = (GABitSet)(m_population[i].clone());
        bestindex[i] = i;
      }
    }else{
      for (int i = 0; i < bestindex.length; i++) {
        bestindex[i] = -1;
      }
      for(int j=0; j<bestclone.length ;j++){
        double b = -Double.MAX_VALUE;
        int count,bestcount = Integer.MAX_VALUE;
        for (int i = 0; i < m_popSize; i++) {
          if(Utils.contain(bestindex,bestindex.length,i)){
            continue;
          }
          if (m_population[i].getObjective() > b) {
            b = m_population[i].getObjective();
            bestindex[j] = i;
            bestcount = countFeatures(m_population[i].getChromosome());
          } else if (Utils.eq(m_population[i].getObjective(), b)) {
            count = countFeatures(m_population[i].getChromosome());
            if (count < bestcount) {
              b = m_population[i].getObjective();
              bestindex[j] = i;
              bestcount = count;
            }
          }
        }
      }
      for (int i = 0; i < bestclone.length; i++) {
        bestclone[i] = (GABitSet)(m_population[bestindex[i]].clone());
      }
    }
  }

  private int [] sortPopulation(){
    int sorted [] = new int[m_popSize];
    for (int i = 0; i < m_popSize; i++) {
      sorted[i] = i;
    }
    for (int i = m_popSize; i>1; i--) {
      for (int j = 1; j < i; j++) {
        if(compareGABitSet(m_population[sorted[j-1]],m_population[sorted[j]])==1){
          int tmp = sorted[j-1];
          sorted[j-1] = sorted[j];
          sorted[j] = tmp;
        }
      }
    }
    return sorted;
  }



  /**
   * creates random population members for the initial population. Also
   * sets the first population member to be a start set (if any)
   * provided by the user
   * @exception Exception if the population can't be created
   */
  private void initPopulation (String name) throws Exception {
    int i,j,bit;
    int num_bits;
    boolean ok;
    int start = 0;


    if(m_startPoputlation){

        File f = new File("lastpopulation_"+name);
        if(f.exists()){
            ObjectInputStream out = new ObjectInputStream(new FileInputStream(f));
            GABitSet[]tmp = (GABitSet [])out.readObject();
            for (int t = 0; t < tmp.length; t++) {
                while(tmp[t].getChromosome().cardinality()<m_maxNumBin){
                    int k = m_random.nextInt(m_numAttribs);
                    while(tmp[t].get(k)){
                        k = m_random.nextInt(m_numAttribs);
                    }
                    tmp[t].getChromosome().set(k);
                }
                m_population[t] = tmp[t];
            }
            return;
        }
    }


    // add the start set as the first population member (if specified)
    if (m_starting != null) {
      m_population[0] = new GABitSet(m_numAttribs);
      for (i=0;i<m_starting.length;i++) {
	if ((m_starting[i]) != m_classIndex) {
	  m_population[0].set(m_starting[i]);
	}
      }
      start = 1;
    }


    for (i=start;i<m_popSize;i++) {

      m_population[i] = new GABitSet(m_numAttribs);

      num_bits = m_random.nextInt(m_maxNumBin-m_minNumBin+1);
      num_bits += m_minNumBin;

      for (j=0;j<num_bits;j++) {
        ok = false;
	do {
	  bit = m_random.nextInt();
	  if (bit < 0) {
	    bit *= -1;
	  }
	  bit = bit % m_numAttribs;
          while(m_population[i].get(bit)){
              bit = (bit+1)%m_numAttribs;
          }
          if (m_hasClass) {
              if (bit != m_classIndex) {
                  ok = true;
              }
          }else {
              ok = true;
          }
	} while (!ok);

	if (bit > m_numAttribs) {
	  throw new Exception("Problem in population init");
	}
	m_population[i].set(bit);

      }
//      System.out.println("GAbitSetsize="+m_population[i].getChromosome().size());
//      System.out.println(m_population[i].getChromosome().cardinality());

    }
  }

  /**
   * calculates summary statistics for the current population
   */
  private void populationStatistics() {
    int i;

    m_sumFitness = m_minFitness = m_maxFitness =
      m_population[0].getObjective();

    for (i=1;i<m_popSize;i++) {
      m_sumFitness += m_population[i].getObjective();
      if (m_population[i].getObjective() > m_maxFitness) {
	m_maxFitness = m_population[i].getObjective();
      }
      else if (m_population[i].getObjective() < m_minFitness) {
	m_minFitness = m_population[i].getObjective();
      }
    }
    m_avgFitness = (m_sumFitness / m_popSize);
  }

  /**
   * scales the raw (objective) merit of the population members
   */
  private void scalePopulation() {
    int j;
    double a = 0;
    double b = 0;
    double fmultiple = 2.0;
    double delta;

    // prescale
    if (m_minFitness > ((fmultiple * m_avgFitness - m_maxFitness) /
			(fmultiple - 1.0))) {
      delta = m_maxFitness - m_avgFitness;
      a = ((fmultiple - 1.0) * m_avgFitness / delta);
      b = m_avgFitness * (m_maxFitness - fmultiple * m_avgFitness) / delta;
    }
    else {
      delta = m_avgFitness - m_minFitness;
      a = m_avgFitness / delta;
      b = -m_minFitness * m_avgFitness / delta;
    }

    // scalepop
    m_sumFitness = 0;
    for (j=0;j<m_popSize;j++) {
      if (a == Double.POSITIVE_INFINITY || a == Double.NEGATIVE_INFINITY ||
	  b == Double.POSITIVE_INFINITY || b == Double.NEGATIVE_INFINITY) {
	m_population[j].setFitness(m_population[j].getObjective());
      } else {
	m_population[j].
	  setFitness(Math.abs((a * m_population[j].getObjective() + b)));
      }
      m_sumFitness += m_population[j].getFitness();
    }
  }

  /**
   * generates a report on the current population
   * @return a report as a String
   */
  private String populationReport (int genNum) {
    int i;
    StringBuffer temp = new StringBuffer();

    if (genNum == 0) {
      temp.append("\nInitial population\n");
    }
    else {
      temp.append("\nGeneration: "+genNum+"\n");
    }
    temp.append("merit   \tscaled  \tsubset\n");

    for (i=0;i<m_popSize;i++) {
      temp.append(Utils.doubleToString(Math.abs(m_population[i].getObjective()),8,5)
		  +"\t"+Utils.doubleToString(m_population[i].getFitness(),8,5)+"\t");
      temp.append(printPopMember(m_population[i].getChromosome())+"\n");
    }
    return temp.toString();
  }

  /**
   * prints a population member as a series of attribute numbers
   * @param temp the chromosome of a population member
   * @return a population member as a String of attribute numbers
   */
  private String printPopMember(BitSet temp) {
    StringBuffer text = new StringBuffer();

    for (int j=0;j<m_numAttribs;j++) {
      if (temp.get(j)) {
        text.append((j+1)+" ");
      }
    }
    return text.toString();
  }

  /**
   * prints a population member's chromosome
   * @param temp the chromosome of a population member
   * @return a population member's chromosome as a String
   */
//  private String printPopChrom(BitSet temp) {
//    StringBuffer text = new StringBuffer();
//
//    for (int j=0;j<m_numAttribs;j++) {
//      if (temp.get(j)) {
//	text.append("1");
//      } else {
//	text.append("0");
//      }
//    }
//    return text.toString();
//  }

  /**
   * reset to default values for options
   */
  private void resetOptions () {
    m_population = null;
    m_popSize = 51;
    m_lookupTableSize = 2001;
    m_pCrossover = 0.6;
    m_pMutation = 0.1;
    m_maxGenerations = 200;
    m_reportFrequency = m_maxGenerations;
    m_starting = null;
    m_startRange = new Range();
    m_seed = 1;
    m_parallel = 0;
    m_localSearch = true;
    m_localSearchMethod= new FilterRanking();
    m_crossoverType = UNIFORM;
    m_mutationType = NM;
    m_localSearchScope = 5;
    numCallingEvaluator = 0;
    m_optimum = 1.0;
    m_maxEvaluation = 60000;
    m_selectionType = LRANK;
    m_maxNumBin = 50;
    m_minNumBin = 1;
    m_selectionPressure = 1.5;
    m_mutationRankingMethod=new ReliefFAttributeEval();
    m_mutationPrivilegeRange = 1000;
  }


  public static void main(String [] args)throws Exception{


  }

    private void jbInit() throws Exception {
    }

  public void saveLastPopulation(String name)throws Exception{
      ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("lastpopulation_"+name));
      out.writeObject(m_population);
      out.close();
  }
}

