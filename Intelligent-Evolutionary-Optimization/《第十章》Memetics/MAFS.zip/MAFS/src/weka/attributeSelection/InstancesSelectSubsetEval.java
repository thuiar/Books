package weka.attributeSelection;

import weka.core.Instances;
import java.util.BitSet;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.LinearRegression;
import weka.core.SelectedTag;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */

public class InstancesSelectSubsetEval extends WrapperSubsetEval{

    public Instances data;
    public double evaluateSubset (BitSet subset)throws Exception{
         double error = 0;
         int[] selectedAttributes = new int[subset.cardinality()];
         for (int i = 0, j = 0; i < subset.size(); i++) {
             if (subset.get(i)) {
                 selectedAttributes[j++] = i;
             }
         }
         Instances trainCopy = new Instances(data,selectedAttributes.length);
         for (int i = 0; i < selectedAttributes.length; i++) {
             trainCopy.add(data.instance(selectedAttributes[i]));
         }
         Evaluation eva = new Evaluation(trainCopy);
         LinearRegression lr = new LinearRegression();
         lr.setEliminateColinearAttributes(false);
         lr.setAttributeSelectionMethod(new SelectedTag(LinearRegression.SELECTION_NONE, LinearRegression.TAGS_SELECTION));
         lr.buildClassifier(trainCopy);
         eva.evaluateModel(lr, data);
         error = eva.errorRate();
         //System.out.println(Utils.arrayToString(selectedAttributes)+"\t"+error);
         return -error;
     }
     public void buildEvaluator (Instances train){
         data = train;
     }
}

