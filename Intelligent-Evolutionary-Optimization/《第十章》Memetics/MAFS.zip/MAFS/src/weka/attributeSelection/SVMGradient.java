package weka.attributeSelection;

import weka.core.*;
import java.util.Enumeration;
import java.util.Vector;
import weka.classifiers.functions.SMO;
import java.io.Serializable;
import weka.filters.unsupervised.attribute.Standardize;
import weka.filters.unsupervised.attribute.Normalize;
import weka.filters.Filter;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class SVMGradient extends AttributeEvaluator
    implements OptionHandler,Serializable{
    protected double m_c = 1.0;
    protected int m_numToSetZeroIteration = 1;
    protected double m_stepsize = 0.1;
    protected double m_Xtol = 1e-4;
    protected int m_maxIter = 200;
    protected boolean m_iterationInfo = true;
    protected boolean m_gradientSearch = true;



    protected SMO smo = null;
    protected Instances smodata = null;
    protected SMO.BinarySMO bsmo = null;
    protected int numClassification = 0;
    double scale [];
    protected boolean m_convergedSolution = true;

    protected int m_filterType = SMO.FILTER_NORMALIZE;





    protected double m_exponent = 1.0;
    protected boolean m_lowerOrder = false;
    protected double m_gamma = 0.01;
    protected boolean m_useRBF = false;

    public double getExponent() {
        return m_exponent;
    }

    public void setExponent(double v) {
        if (v == 1.0) {
            m_lowerOrder = false;
        }
        m_exponent = v;
    }

    public double getGamma() {
        return m_gamma;
    }
    public void setGamma(double v) {
        m_gamma = v;
    }

    public boolean getLowerOrderTerms() {
        return m_lowerOrder;
    }
    public void setLowerOrderTerms(boolean v) {

        if (m_exponent == 1.0 || m_useRBF) {
            m_lowerOrder = false;
        } else {
            m_lowerOrder = v;
        }
    }
    public boolean getUseRBF() {
        return m_useRBF;
    }
    public void setUseRBF(boolean v) {
        if (v) {
            m_lowerOrder = false;
        }
        m_useRBF = v;
    }


    public SelectedTag getFilterType() {

        return new SelectedTag(m_filterType, SMO.TAGS_FILTER);
    }

    public void setFilterType(SelectedTag newType) {

        if (newType.getTags() == SMO.TAGS_FILTER) {
            m_filterType = newType.getSelectedTag().getID();
        }
    }


    public void setConvergedSolution(boolean b){
        m_convergedSolution = b;
    }
    public boolean getConvergedSolution(){
        return m_convergedSolution;
    }

    public int getNumClassification(){
        return numClassification;
    }
    public double getC() {
        return m_c;
    }
    public void setC(double c){
        m_c = c;
    }


    public int getNumToSetZeroIteration() {
        return m_numToSetZeroIteration;
    }
    public void setNumToSetZeroIteration(int q){
        m_numToSetZeroIteration = q;
    }
    public double getStepSize() {
        return m_stepsize;
    }
    public void setStepSize(double m){
        m_stepsize = m;
    }
    public double getXTolerance(){
        return m_Xtol;
    }
    public void setXTolerance(double x){
        m_Xtol = x;
    }
    public int getMaxIteration(){
        return m_maxIter;
    }
    public void setMaxIteration(int m){
        m_maxIter = m;
    }
    public boolean getGradientSearch() {
        return m_gradientSearch;
    }
    public void setGradientSearch(boolean v) {
        m_gradientSearch = v;
    }

    public void setIterationInfo(boolean a){
        m_iterationInfo = a;
    }
    public boolean getIterationInfo(){
        return m_iterationInfo;
    }

    public SVMGradient() {
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    public void setOptions(String[] options) throws Exception{
        String optionString;

        optionString = Utils.getOption('C', options);
        if (optionString.length() != 0) {
            setC(Double.parseDouble(optionString));
        }
        optionString = Utils.getOption('Q', options);
        if (optionString.length() != 0) {
            setNumToSetZeroIteration(Integer.parseInt(optionString));
        }
        optionString = Utils.getOption('P', options);
        if (optionString.length() != 0) {
            setStepSize(Double.parseDouble(optionString));
        }
        optionString = Utils.getOption('X', options);
        if (optionString.length() != 0) {
            setXTolerance(Double.parseDouble(optionString));
        }
        optionString = Utils.getOption('I', options);
        if (optionString.length() != 0) {
            setMaxIteration(Integer.parseInt(optionString));
        }
        optionString = Utils.getOption('F', options);
        if (optionString.length() != 0) {
            setIterationInfo(true);
        }
        optionString = Utils.getOption('V', options);
        if (optionString.length() != 0) {
            setConvergedSolution(true);
        }
        String nString = Utils.getOption('N', options);
        if (nString.length() != 0) {
            setFilterType(new SelectedTag(Integer.parseInt(nString), SMO.TAGS_FILTER));
        } else {
            setFilterType(new SelectedTag(SMO.FILTER_NORMALIZE, SMO.TAGS_FILTER));
        }
        String exponentsString = Utils.getOption('E', options);
        if (exponentsString.length() != 0) {
            m_exponent = (new Double(exponentsString)).doubleValue();
        } else {
            m_exponent = 1.0;
        }

        String gammaString = Utils.getOption('G', options);
        if (gammaString.length() != 0) {
            m_gamma = (new Double(gammaString)).doubleValue();
        } else {
            m_gamma = 0.01;
        }
        m_useRBF = Utils.getFlag('B', options);
        m_lowerOrder = Utils.getFlag('L', options);
        Utils.checkForRemainingOptions(options);
    }
    public String[] getOptions(){
        String[] options = new String[21];
        int current = 0;

        options[current++] = "-C";
        options[current++] = "" + getC();
        options[current++] = "-Q";
        options[current++] = "" + getNumToSetZeroIteration();
        options[current++] = "-P";
        options[current++] = "" + getStepSize();
        options[current++] = "-X";
        options[current++] = "" + getXTolerance();
        options[current++] = "-I";
        options[current++] = "" + getMaxIteration();
        options[current++] = "-N"; options[current++] = "" + m_filterType;
        options[current++] = "-E"; options[current++] = "" + m_exponent;
        options[current++] = "-G"; options[current++] = "" + m_gamma;
        if (m_lowerOrder) {
            options[current++] = "-L";
        }
        if (m_useRBF) {
            options[current++] = "-B";
        }

        if(getIterationInfo()){
            options[current++] = "-F";
        }
        if(getConvergedSolution()){
            options[current++] = "-V";
        }

        while (current < options.length) {
            options[current++] = "";
        }

        return options;


    }
    public Enumeration listOptions(){
        Vector newVector = new Vector(12);
        newVector.addElement(new Option("\tSpecify C of svm.","C",1,"-C <number>"));
        newVector.addElement(new Option("\tSpecify the number of smallest scale values to be set as zeros.","Q",1,"-Q <number>"));
        newVector.addElement(new Option("\tSpecify the number of Max Iteration.","I",1,"-I <number>"));
        newVector.addElement(new Option("\tSpecify the number of Step Size.","P",1,"-P <number>"));
        newVector.addElement(new Option("\tSpecify the number of X Tolerance.","X",1,"-X <number>"));
        newVector.addElement(new Option("\tPrint iteration information.","F",1,"-F"));
        newVector.addElement(new Option("\tReturn converge solution.","V",1,"-V"));
        newVector.addElement(new Option("\tWhether to 0=normalize/1=standardize/2=neither. (default 0=normalize)", "N", 1, "-N"));
        newVector.addElement(new Option("\tThe exponent for the "
                                        + "polynomial kernel. (default 1)",
                                        "E", 1, "-E <double>"));
        newVector.addElement(new Option("\tGamma for the RBF kernel. (default 0.01)",
                                        "G", 1, "-G <double>"));
        newVector.addElement(new Option("\tUse lower-order terms (only for non-linear\n" +
                                        "\tpolynomial kernels).",
                                        "L", 0, "-L"));
        newVector.addElement(new Option("\tUse RBF kernel. " +
                                        "(default poly)",
                                        "B", 0, "-B"));

        return newVector.elements();
    }


//    public Instances scaleData(Instances data,double [] scale){
//        Instances copy = new Instances(data);
//        for (int i = 0; i < copy.numInstances(); i++) {
//            for (int j = 0; j < scale.length; j++) {
//                double oriv = copy.instance(i).value(j);
//                copy.instance(i).setValue(j,oriv*scale[j]);
//            }
//        }
//        return copy;
//    }



    class MyOpt extends Optimization{
        protected double objectiveFunction(double[] x){
            double result = 0;
            try{
                Instances copy = smodata.scaleData(x);
                //System.out.println("smo building...");
                bsmo.buildClassifier(copy,0,1,smo.getBuildLogisticModels(),smo.getNumFolds(),smo.getRandomSeed());
                numClassification ++;
                result = bsmo.rmb.getBound()*copy.numInstances();
            }catch(Exception e){
                e.printStackTrace();
            }
            if(m_iterationInfo){
                System.out.print("x=");
                for (int i = 0; i < x.length; i++) {
                    System.out.print(x[i] + "\t");
                }
                System.out.println("objF= " + result);
            }
            return result;
        }

        protected double[] evaluateGradient(double[] x){
            double gp[] = new double[x.length];
            //System.out.print("g=");
            for (int i = 0; i < x.length; i++) {
                try{
                    gp[i] = bsmo.rmb.r2w2GradientScale(i, x[i], smodata);///smodata.numInstances();
                    //System.out.print(gp[i]+"\t");
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
            //System.out.println("");
            return gp;
        }
//        protected double[] evaluateHessian(double[] x, int k){
//            double h[] = new double[x.length];
//            for (int i = 0; i < x.length; i++) {
//                try {
//                    h[i] = bsmo.rmb.r2w2HessianScale(i,k,x[i],x[k],smodata);
//                } catch (Exception ex) {
//                    ex.printStackTrace();
//                }
//            }
//            return h;
//        }
    }

    public double evaluateAttribute (int attribute) throws Exception {
        return  scale[attribute];
    }



    /**
     * Searches the attribute subset/ranking space.
     *
     * @param ASEvaluator the attribute evaluator to guide the search
     * @param data the training instances.
     * @return an array (not necessarily ordered) of selected attribute
     *   indexes
     * @throws Exception if the search can't be completed
     * @todo Implement this weka.attributeSelection.ASSearch method
     */
    public void buildEvaluator(Instances d) throws Exception {
        scale = new double[d.numAttributes()-1];
        java.util.Arrays.fill(scale,1.0);
        //smo = (SMO)((WrapperSubsetEval)ASEvaluator).getClassifier();
        smo = new SMO();
        smo.setC(m_c);

        smo.setFilterType(new SelectedTag(SMO.FILTER_NONE, SMO.TAGS_FILTER));
        smo.setGeneralizationError(new SelectedTag(SMO.RMB, SMO.TAGS_GENERALIZATIONERROR));
        smo.setCacheSize(0);
        if (m_filterType == SMO.FILTER_STANDARDIZE) {
            Standardize m_Filter = new Standardize();
            m_Filter.setInputFormat(d);
            smodata = Filter.useFilter(d, m_Filter);
        } else if (m_filterType == SMO.FILTER_NORMALIZE) {
            Normalize m_Filter = new Normalize();
            m_Filter.setInputFormat(d);
            smodata = Filter.useFilter(d, m_Filter);
        } else {
            smodata = d;
        }
        smo.setExponent(m_exponent);
        smo.setLowerOrderTerms(m_lowerOrder);
        smo.setGamma(m_gamma);
        smo.setUseRBF(m_useRBF);
        smo.buildClassifier(smodata);
        bsmo = smo.m_classifiers[0][1];
        MyOpt solver = new MyOpt();
        if(m_gradientSearch){
            double[][] constraints = new double[2][scale.length];
            java.util.Arrays.fill(constraints[0],-Double.MAX_VALUE);
            java.util.Arrays.fill(constraints[1],Double.MAX_VALUE);
            // Find the minimum, 200 iterations as default
            solver.setMaxIteration(m_maxIter);
            solver.setMaxStepLength(m_stepsize);
            solver.setTOLX(m_Xtol);
            numClassification = 0;
            //System.out.println("Gradient start:");
            solver.setConvergeSolution(m_convergedSolution);
            scale = solver.findArgmin(scale, constraints);
            while(scale==null){
                scale = solver.getVarbValues();
                scale = solver.findArgmin(scale, constraints);
            }
            for (int i = 0; i < scale.length; i++) {
                scale[i] = Math.abs(scale[i]);
            }
        }else{
            scale = solver.evaluateGradient(scale);
            for (int i = 0; i < scale.length; i++) {
                scale[i] *= -1;
            }
        }

        if(m_iterationInfo){
            System.out.println("Num of svm classification: "+numClassification);
        }
    }






    public static void main(String [] args) throws Exception {
    }

    private void jbInit() throws Exception {
    }

}
