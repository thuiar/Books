package weka.attributeSelection.GA;

import weka.core.Instances;
import weka.core.OptionHandler;
import weka.core.Option;
import java.util.Vector;
import java.util.Enumeration;
import weka.core.Utils;
import weka.attributeSelection.SubsetEvaluator;
import weka.attributeSelection.GeneticSearch;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class SequentialSearch extends GALocalSearch implements OptionHandler {

    private Instances data;
    int maxSelectedAtt,minSelectedAtt;
    private int m_localSearchStep=3;

    public SequentialSearch() {
    }


    public int getLocalSearchStep(){
        return m_localSearchStep;
    }
    public void setLocalSearchStep(int s){
        m_localSearchStep = s;
    }
    public String[] getOptions () {

        String[] options = new String[2];
        int current = 0;
        options[current++] = "-l";
        options[current++] = "" + getLocalSearchStep();

        while (current < options.length) {
            options[current++] = "";
        }
        return  options;
    }

    public void setOptions (String[] options) throws Exception {
        String optionString;

        optionString = Utils.getOption('l', options);
        if (optionString.length() != 0) {
            setLocalSearchStep(Integer.parseInt(optionString));
        }
    }

    public Enumeration listOptions () {
        Vector newVector = new Vector(1);
        newVector.addElement(new Option("\tSet local search step size", "l", 3, "-l <step size>"));
        return  newVector.elements();
    }

    /**
     * buildLocalSearch
     *
     * @param data Instances
     * @param maxSelectedAtt int
     * @todo Implement this
     *   weka.attributeSelection.GeneticSearchLocalSearch.GALocalSearch
     *   method
     */
    public void buildLocalSearch(Instances d,int min, int max, GA g,SubsetEvaluator se) {
        data = d;
        maxSelectedAtt = max;
        minSelectedAtt = min;
        ga = g;
        eval = se;
    }

    /**
     * search
     *
     * @param gab GABitSet
     * @return GABitSet[]
     * @todo Implement this
     *   weka.attributeSelection.GeneticSearchLocalSearch.GALocalSearch
     *   method
     */
    public GABitSet search(GABitSet gab) {
        try{
            GABitSet tmpB = (GABitSet)gab.clone();



            for (int j = 0; j < m_localSearchStep-1; j++) {
                tmpB=sequentiallyAddOne(eval,tmpB);
            }
            for (int j = 0; j < m_localSearchStep; j++) {
                tmpB=sequentiallyDelOne(eval,tmpB);
            }
            return tmpB;
        }catch(Exception e){
            e.printStackTrace();
        }
        return gab;
    }


    private GABitSet sequentiallyAddOne(SubsetEvaluator ASEvaluator,GABitSet gabs)throws Exception{
        int numAttribs = data.numAttributes();
        if(gabs.getChromosome().cardinality() == (numAttribs-1)) return gabs;
        GABitSet bestObjective = (GABitSet)gabs.clone();
        GABitSet tmp[] = new GABitSet[numAttribs-1-gabs.getChromosome().cardinality()];
        for (int i = 0,j=0; i < numAttribs-1; i++) {
            if(!gabs.get(i)){
                tmp[j] = (GABitSet)(gabs.clone());
                tmp[j].set(i);
                j++;
            }
        }
        ga.calculateFitness(ASEvaluator,tmp);
        for (int i = 0; i < tmp.length; i++) {
            if(ga.compareGABitSet(tmp[i],bestObjective) == 1){
                bestObjective = tmp[i];
            }
        }
        return bestObjective;
    }

    private GABitSet sequentiallyDelOne(SubsetEvaluator ASEvaluator,GABitSet gabs)throws Exception{
        if(gabs.getChromosome().cardinality()==1 || gabs.getChromosome().cardinality()==minSelectedAtt) return gabs;
        GABitSet bestObjective = (GABitSet)gabs.clone();
        GABitSet tmp[] = new GABitSet[gabs.getChromosome().cardinality()];
        for (int i = 0,j=0; i < data.numAttributes()-1; i++) {
            if(gabs.get(i)){
                tmp[j] = (GABitSet)(gabs.clone());
                tmp[j].clear(i);
                j++;
            }
        }
        ga.calculateFitness(ASEvaluator,tmp);
        for (int i = 0; i < tmp.length; i++) {
            if(ga.compareGABitSet(tmp[i],bestObjective) == 1){
                bestObjective = tmp[i];
            }
        }
        return bestObjective;
    }

    public String toString(){
        return "\n\tLocal Search Method: FilterRanking"+
                "\n\tLocal Search Step: "+getLocalSearchStep();

    }

}
