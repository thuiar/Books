package weka.attributeSelection.GA;


import weka.core.Instances;
import weka.core.OptionHandler;
import weka.core.Utils;
import java.util.Vector;
import weka.core.Option;
import java.util.Enumeration;
import weka.attributeSelection.GeneticSearch;
import java.util.Random;
import weka.core.Tag;
import weka.core.SelectedTag;
import weka.attributeSelection.SubsetEvaluator;


/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Randomly extends GALocalSearch implements OptionHandler{

    private Instances data;
    int maxSelectedAtt;
    int minSelectedAtt;
    private int m_localSearchStep=3;

    protected int m_localSearchImprovementStrategy = IMPROVEMENTFIRST;
    public static final int IMPROVEMENTFIRST = 1;
    public static final int GREEDY = 2;
    public static final Tag [] TAGS_LSIMPROVEMENTSTRATEGY = {
            new Tag(IMPROVEMENTFIRST, "Improvement First"),
            new Tag(GREEDY, "Greedy")
    };

    public SelectedTag getLSImprovementStrategy() {

        return new SelectedTag(m_localSearchImprovementStrategy, TAGS_LSIMPROVEMENTSTRATEGY);
    }

    public void setLSImprovementStrategy(SelectedTag strategy) {

        if (strategy.getTags() == TAGS_LSIMPROVEMENTSTRATEGY) {
            m_localSearchImprovementStrategy = strategy.getSelectedTag().getID();
        }
    }


    public int getLocalSearchStep(){
        return m_localSearchStep;
    }
     public void setLocalSearchStep(int s){
         m_localSearchStep = s;
     }
     public String[] getOptions () {

       String[] options = new String[3];
       int current = 0;
       options[current++] = "-l";
       options[current++] = "" + getLocalSearchStep();
       if (m_localSearchImprovementStrategy == IMPROVEMENTFIRST){
            options[current++] = "-m";
        }else if(m_localSearchImprovementStrategy == GREEDY){
            options[current++] = "-n";
        }


       while (current < options.length) {
           options[current++] = "";
       }
       return  options;
   }

   public void setOptions (String[] options) throws Exception {
        String optionString;

        optionString = Utils.getOption('l', options);
        if (optionString.length() != 0) {
            setLocalSearchStep(Integer.parseInt(optionString));
        }
        if(Utils.getFlag('m', options)){
            setLSImprovementStrategy(new SelectedTag(IMPROVEMENTFIRST, TAGS_LSIMPROVEMENTSTRATEGY));
        }else {
            setLSImprovementStrategy(new SelectedTag(GREEDY, TAGS_LSIMPROVEMENTSTRATEGY));
        }



    }

    public Enumeration listOptions () {
       Vector newVector = new Vector(3);
       newVector.addElement(new Option("\tSet local search step size", "l", 3, "-l <step size>"));
       newVector.addElement(new Option("\tImprovement Frist local search","m", 0, "-m"));
        newVector.addElement(new Option("\tGreedy local search","n", 0, "-n"));
       return  newVector.elements();
   }

    /**
     * buildLocalSearch
     *
     * @param data Instances
     * @param maxSelectedAtt int
     * @todo Implement this
     *   weka.attributeSelection.GeneticSearchLocalSearch.GALocalSearch
     *   method
     */
    public void buildLocalSearch(Instances d, int min,int max,GA g,SubsetEvaluator se) {
        data = d;
        maxSelectedAtt = max;
        minSelectedAtt = min;
        ga = g;
        eval = se;
    }

    /**
     * search
     *
     * @param gab GABitSet
     * @return GABitSet[]
     * @todo Implement this
     *   weka.attributeSelection.GeneticSearchLocalSearch.GALocalSearch
     *   method
     */
    public GABitSet search(GABitSet gab) {
        try {
            if (m_localSearchImprovementStrategy == IMPROVEMENTFIRST) {
                Random r = new Random();
                int a[] = new int[m_localSearchStep * m_localSearchStep - 1];
                int k = ga.getParallel() > 0 ? ga.getParallel() : 1;
                for (int j = 0; j < a.length; ) {
                    if (j + ga.getParallel() > a.length) {
                        k = a.length - j;
                    }
                    GABitSet tmpB[] = new GABitSet[k];
                    for (int jj = 0; jj < k; jj++, j++) {
                        int tmp = r.nextInt(m_localSearchStep *
                                            m_localSearchStep - 1) + 1;
                        while (Utils.contain(a, j, tmp)) {
                            tmp = r.nextInt(m_localSearchStep *
                                            m_localSearchStep - 1) + 1;
                        }
                        a[j] = tmp;
                        tmpB[jj] = (GABitSet) (gab.clone());
                        int addNum = a[j] / m_localSearchStep;
                        int delNum = a[j] % m_localSearchStep;
                        int currentNum = gab.getChromosome().cardinality();
                        if(currentNum+addNum>data.numAttributes()-1){
                            addNum -= currentNum+addNum+1-data.numAttributes();
                        }
                        if(currentNum-delNum<1){
                            delNum -= 1-currentNum+delNum;
                        }
                        int finalNum = currentNum+addNum-delNum;
                        if( finalNum > maxSelectedAtt){
                            addNum -= finalNum - maxSelectedAtt;
                        }else if(finalNum < minSelectedAtt){
                            delNum -= minSelectedAtt-finalNum;
                        }

                        randomlyAddDel(addNum,delNum,tmpB[jj]);
                    }
                    ga.calculateFitness(eval, tmpB);
                    for (int jj = 0; jj < k; jj++) {
                        if (ga.compareGABitSet(tmpB[jj], gab) == 1) {
                            ga.numCallingEvaluator -= (k - 1 - jj);
                            return tmpB[jj];
                        }
                    }
                }
            }else{
                GABitSet tmpB[] = new GABitSet[m_localSearchStep * m_localSearchStep - 1];
                for (int j = 1; j < (m_localSearchStep * m_localSearchStep); j++) {
                    tmpB[j - 1] = (GABitSet) (gab.clone());
                    int addNum = j / m_localSearchStep;
                    int delNum = j % m_localSearchStep;
                    int currentNum = gab.getChromosome().cardinality();
                    if(currentNum+addNum>data.numAttributes()-1){
                        addNum -= currentNum+addNum+1-data.numAttributes();
                    }
                    if(currentNum-delNum<1){
                        delNum -= 1-currentNum+delNum;
                    }
                    int finalNum = currentNum+addNum-delNum;
                    if( finalNum > maxSelectedAtt){
                        addNum -= finalNum - maxSelectedAtt;
                    }else if(finalNum < minSelectedAtt){
                        delNum -= minSelectedAtt-finalNum;
                    }
                    randomlyAddDel(addNum, delNum,tmpB[j - 1]);
                }
                ga.calculateFitness(eval, tmpB);
                for (int j = 0; j < tmpB.length; j++) {
                    if (ga.compareGABitSet(tmpB[j], gab) == 1) {
                        gab = tmpB[j];
                    }
                }
                return gab;

            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return gab;
    }

    private void randomlyAddDel(int addNo,int delNo,GABitSet gbs){
        Random r = new Random();
        for (int i = 0; i < addNo; i++) {
            randomlyAddOne(gbs,r);
        }
        for (int i = 0; i < delNo; i++) {
            randomlyDelOne(gbs,r);
        }
    }

    private void randomlyAddOne(GABitSet gabs,Random r){
        int numAttribs = data.numAttributes();
        int index = r.nextInt(numAttribs-1-gabs.getChromosome().cardinality());
        for (int i = 0,j=0; i < numAttribs-1; i++) {
            if(!gabs.get(i)){
                if(j==index){
                    gabs.set(i);
                    break;
                }
                j++;
            }
        }
    }

    private void randomlyDelOne(GABitSet gabs,Random r){
        int index = r.nextInt(gabs.getChromosome().cardinality());
        for (int i = 0,j=0; i < data.numAttributes()-1; i++) {
            if(gabs.get(i)){
                if(j==index){
                    gabs.clear(i);
                    break;
                }
                j++;
            }
        }
    }


    public String toString(){
            return "\n\tLocal Search Method: FilterRanking"+
                    "\n\tLocal Search Strategy: "+getLSImprovementStrategy().getSelectedTag().getReadable()+
                    "\n\tLocal Search Step: "+getLocalSearchStep();

    }

}
