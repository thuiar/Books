package weka.attributeSelection.GA;

import weka.attributeSelection.GeneticSearch;
import weka.core.Instances;
import weka.core.Option;
import java.util.Vector;
import weka.core.Utils;
import java.util.Enumeration;
import weka.core.OptionHandler;
import weka.attributeSelection.WrapperSubsetEval;
import weka.attributeSelection.SubsetEvaluator;
import weka.attributeSelection.RankGeneMeasures;
import weka.core.SelectedTag;
import weka.attributeSelection.Ranker;
import weka.core.Tag;
import java.util.Random;
import weka.classifiers.Classifier;
import weka.classifiers.functions.SMO;
import weka.classifiers.meta.MultiClassClassifier;
import weka.classifiers.functions.supportVector.Kernel;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.Filter;


/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class SVM_RFE extends GALocalSearch implements OptionHandler{

    private Instances data;
    int maxSelectedAtt;
    int minSelectedAtt;
    private int m_localSearchStep=3;
    //double m_c=1;
    int maxSens[];
    int minSens[];
//    public int m_addCriteria = 1;
//    public static final int SENS = 1;
//    public static final int ONED = 2;
//    public static final Tag [] TAGS_ADDC = {
//            new Tag(SENS, "Sensitivity"),
//            new Tag(ONED, "One Dimension SVM Ranking")
//    };

    private double m_selectionPressure = 0.2;
    protected int m_selectionType = ERANK;
    public static final int LRANK = 1;
    public static final int ERANK = 2;
    public static final Tag [] TAGS_SELECTIONTYPE = {
            new Tag(LRANK, "Linear Rank Selection"),
            new Tag(ERANK, "Exponential Rank Selection")
    };

    protected int m_localSearchImprovementStrategy = IMPROVEMENTFIRST;
    public static final int IMPROVEMENTFIRST = 1;
    public static final int GREEDY = 2;
    public static final Tag [] TAGS_LSIMPROVEMENTSTRATEGY = {
            new Tag(IMPROVEMENTFIRST, "Improvement First"),
            new Tag(GREEDY, "Greedy")
    };


    public SelectedTag getLSImprovementStrategy() {

        return new SelectedTag(m_localSearchImprovementStrategy, TAGS_LSIMPROVEMENTSTRATEGY);
    }

    public void setLSImprovementStrategy(SelectedTag strategy) {

        if (strategy.getTags() == TAGS_LSIMPROVEMENTSTRATEGY) {
            m_localSearchImprovementStrategy = strategy.getSelectedTag().getID();
        }
    }



    public double getSelectionPressure(){
        return m_selectionPressure;
    }
    public void setSelectionPressure(double s){
        m_selectionPressure = s;
    }

    public SelectedTag getSelectionType() {
        return new SelectedTag(m_selectionType, TAGS_SELECTIONTYPE);
    }

    public void setSelectionType(SelectedTag type) {

        if (type.getTags() == TAGS_SELECTIONTYPE) {
            m_selectionType = type.getSelectedTag().getID();
        }
    }

//    public SelectedTag getAddCriteria() {
//        return new SelectedTag(m_addCriteria, TAGS_ADDC);
//    }
//
//    public void setAddCriteria(SelectedTag type) {
//
//        if (type.getTags() == TAGS_ADDC) {
//            m_addCriteria = type.getSelectedTag().getID();
//        }
//    }


//    public double getC() {
//        return m_c;
//    }
//    public void setC(double c){
//        m_c = c;
//    }
    public int getLocalSearchStep(){
        return m_localSearchStep;
    }
    public void setLocalSearchStep(int s){
        m_localSearchStep = s;
    }

    public String[] getOptions () {

        String[] options = new String[10];
        int current = 0;
        options[current++] = "-l";
        options[current++] = "" + getLocalSearchStep();
//        options[current++] = "-C";
//        options[current++] = "" + getC();
        options[current++] = "-P";
        options[current++] = "" + getSelectionPressure();
        options[current++] = "-S";
        options[current++] = "" + m_selectionType;
//        options[current++] = "-A";
//        options[current++] = "" + m_addCriteria;


        while (current < options.length) {
            options[current++] = "";
        }
        return  options;
    }

    public void setOptions (String[] options) throws Exception {
        String optionString;

        optionString = Utils.getOption('l', options);
        if (optionString.length() != 0) {
            setLocalSearchStep(Integer.parseInt(optionString));
        }

//        optionString = Utils.getOption('C', options);
//        if (optionString.length() != 0) {
//            setC(Double.parseDouble(optionString));
//        }

        optionString = Utils.getOption('P', options);
        if (optionString.length() != 0) {
            m_selectionPressure = Double.parseDouble(optionString);
        }

        optionString = Utils.getOption('S', options);
        if (optionString.length() != 0) {
            m_selectionType = Integer.parseInt(optionString);
        }

//        optionString = Utils.getOption('A', options);
//        if (optionString.length() != 0) {
//             m_addCriteria = Integer.parseInt(optionString);
//        }




    }

    public Enumeration listOptions () {
        Vector newVector = new Vector(1);
        newVector.addElement(new Option("\tSet local search step size", "l", 3, "-l <step size>"));
        return  newVector.elements();
    }


    /**
     * buildLocalSearch
     *
     * @param data Instances
     * @param maxSelectedAtt int
     * @param gs GeneticSearch
     * @todo Implement this weka.attributeSelection.GA.GALocalSearch method
     */
    public void buildLocalSearch(Instances d, int min,int max, GA g,SubsetEvaluator se) {
        data = d;
        maxSelectedAtt = max;
        minSelectedAtt = min;
        ga = g;
        eval = se;
//        if(m_addCriteria==ONED){
//            try {
//                RankGeneMeasures svm1d = new RankGeneMeasures();
//                svm1d.setMeasureType(new SelectedTag(RankGeneMeasures.ODSVM, RankGeneMeasures.TAGS_MEASURETYPE));
//                svm1d.set_C(m_c);
//                svm1d.buildEvaluator(d);
//                Ranker rk = new Ranker();
//                int tmp[] = rk.search(svm1d,data);
//                rankedAttributes = new int[tmp.length];
//                for (int i = 0; i < tmp.length; i++) {
//                    rankedAttributes[i] = tmp[tmp.length-1-i];
//                }
//            } catch (Exception ex) {
//                ex.printStackTrace();
//            }
//        }
    }


    public void addOne(SMO smo, GABitSet gab)throws Exception{
        //add feature
//            if(m_addCriteria==ONED){//one dimension svm ranking
//                Random r = new Random();
//                int add = m_selectionType==1?Utils.linearRankingSelection(rankedAttributes,m_selectionPressure,r):Utils.exponentialRankingSelection(rankedAttributes,m_selectionPressure,r);
//                while(gab.get(add)){
//                    add = m_selectionType==1?Utils.linearRankingSelection(rankedAttributes,m_selectionPressure,r):Utils.exponentialRankingSelection(rankedAttributes,m_selectionPressure,r);
//                }
//                gab.set(add);
//            }else{//sensitivity
//                int i = -1;
//                if(smo.m_generalizationError==SMO.M2){
//                    i = getMaxSensW2i(smo,gab);
//                }else if(smo.m_generalizationError==SMO.RMB){
//                    i = getMaxSensRMBi(smo,gab);
//                }else{
//                    throw new Exception("Not support other genernalization error type yet!");
//                }
        //gab.set(i);
        Random r = new Random();
        int add = m_selectionType==1?Utils.linearRankingSelection(maxSens,m_selectionPressure,r):Utils.exponentialRankingSelection(maxSens,m_selectionPressure,r);
        while(gab.get(add)){
            add = m_selectionType==1?Utils.linearRankingSelection(maxSens,m_selectionPressure,r):Utils.exponentialRankingSelection(maxSens,m_selectionPressure,r);
        }
        gab.set(add);


           // }
    }

    public void delOne(SMO smo, GABitSet gab) throws Exception{
//        int i = -1;
//        if(smo.m_generalizationError==SMO.M2){
//            i = getMinSensW2i(smo,gab);
//        }else if(smo.m_generalizationError==SMO.RMB){
//            i = getMinSensRMBi(smo,gab);
//        }else{
//            throw new Exception("Not support other genernalization error type yet!");
//        }
//        gab.clear(i);
        Random r = new Random();
        int del = m_selectionType==1?Utils.linearRankingSelection(minSens,m_selectionPressure,r):Utils.exponentialRankingSelection(minSens,m_selectionPressure,r);
        while(!gab.get(del)){
            del = m_selectionType==1?Utils.linearRankingSelection(minSens,m_selectionPressure,r):Utils.exponentialRankingSelection(minSens,m_selectionPressure,r);
        }
        gab.clear(del);


    }

    private void addDel(int addNo,int delNo,GABitSet gbs,SMO smo)throws Exception{
        //Instances traindata;
        for (int i = 0; i < addNo; i++) {
//            if(m_addCriteria == SENS){
//                smo.randomize = false;
//                traindata = filter(data,gbs);
//                smo.buildClassifier(traindata);
//                ga.numCallingEvaluator ++;
//            }
            addOne(smo,gbs);
        }
        for (int i = 0; i < delNo; i++) {
//            smo.randomize = true;
//            traindata = filter(data,gbs);
//            smo.buildClassifier(traindata);
//            ga.numCallingEvaluator ++;
            delOne(smo,gbs);
        }
    }


    /**
     * search
     *
     * @param gab GABitSet
     * @return GABitSet
     * @todo Implement this weka.attributeSelection.GA.GALocalSearch method
     */
    public GABitSet search(GABitSet gab) {
        try{
            Classifier f = ((WrapperSubsetEval)eval).getClassifier();
            SMO smo = null;
            if(f instanceof SMO){
                smo = (SMO)f;
            }else{
                smo = (SMO)(((MultiClassClassifier)f).getClassifier());
            }
            if(smo.getUseRBF() || smo.getExponent()!=1){
                throw new Exception("Can only use linear kernel");
            }
            Instances traindata;
            smo.randomize = false;
            traindata = filter(data,gab);
            smo.buildClassifier(traindata);
            ga.numCallingEvaluator ++;
            if(smo.m_generalizationError==SMO.M2){
                maxSens = getMaxSensW2i(smo,gab);
            }else if(smo.m_generalizationError==SMO.RMB){
                maxSens = getMaxSensRMBi(smo,gab);
            }else{
                throw new Exception("Not support other genernalization error type yet!");
            }

            smo.randomize = true;
            traindata = filter(data,gab);
            smo.buildClassifier(traindata);
            ga.numCallingEvaluator ++;
            if(smo.m_generalizationError==SMO.M2){
                minSens = getMinSensW2i(smo,gab);
            }else if(smo.m_generalizationError==SMO.RMB){
                minSens = getMinSensRMBi(smo,gab);
            }else{
                throw new Exception("Not support other genernalization error type yet!");
            }




            if (this.m_localSearchImprovementStrategy == IMPROVEMENTFIRST) {
                Random r = new Random();
                int a[] = new int[m_localSearchStep * m_localSearchStep - 1];
                int k = ga.getParallel() > 0 ? ga.getParallel() : 1;
                for (int j = 0; j < a.length; ) {
                    if (j + ga.getParallel() > a.length) {
                        k = a.length - j;
                    }
                    GABitSet tmpB[] = new GABitSet[k];
                    for (int jj = 0; jj < k; jj++, j++) {
                        int tmp = r.nextInt(m_localSearchStep *
                                            m_localSearchStep - 1) + 1;
                        while (Utils.contain(a, j, tmp)) {
                            tmp = r.nextInt(m_localSearchStep *
                                            m_localSearchStep - 1) + 1;
                        }
                        a[j] = tmp;
                        tmpB[jj] = (GABitSet) (gab.clone());
                        int addNum = a[j] / m_localSearchStep;
                        int delNum = a[j] % m_localSearchStep;
                        int currentNum = gab.getChromosome().cardinality();
                        if(currentNum+addNum>data.numAttributes()-1){
                            addNum -= currentNum+addNum+1-data.numAttributes();
                        }
                        if(currentNum-delNum<1){
                            delNum -= 1-currentNum+delNum;
                        }
                        int finalNum = currentNum+addNum-delNum;
                        if( finalNum > maxSelectedAtt){
                            addNum -= finalNum - maxSelectedAtt;
                        }else if(finalNum < minSelectedAtt){
                            delNum -= minSelectedAtt-finalNum;
                        }

                        addDel(addNum,delNum,tmpB[jj],smo);
                    }
                    ga.calculateFitness(eval, tmpB);
                    for (int jj = 0; jj < k; jj++) {
                        if (ga.compareGABitSet(tmpB[jj], gab) == 1) {
                            ga.numCallingEvaluator -= (k - 1 - jj);
                            return tmpB[jj];
                        }
                    }
                }
            } else {
                GABitSet tmpB[] = new GABitSet[m_localSearchStep * m_localSearchStep - 1];
                for (int j = 1; j < (m_localSearchStep * m_localSearchStep); j++) {
                    tmpB[j - 1] = (GABitSet) (gab.clone());
                    int addNum = j / m_localSearchStep;
                    int delNum = j % m_localSearchStep;
                    int currentNum = gab.getChromosome().cardinality();
                    if(currentNum+addNum>data.numAttributes()-1){
                        addNum -= currentNum+addNum+1-data.numAttributes();
                    }
                    if(currentNum-delNum<1){
                        delNum -= 1-currentNum+delNum;
                    }
                    int finalNum = currentNum+addNum-delNum;
                    if( finalNum > maxSelectedAtt){
                        addNum -= finalNum - maxSelectedAtt;
                    }else if(finalNum < minSelectedAtt){
                        delNum -= minSelectedAtt-finalNum;
                    }
                    addDel(addNum, delNum,tmpB[j - 1],smo);
                }
                ga.calculateFitness(eval, tmpB);
                for (int j = 0; j < tmpB.length; j++) {
                    if (ga.compareGABitSet(tmpB[j], gab) == 1) {
                        gab = tmpB[j];
                    }
                }
                return gab;

            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return gab;
    }

    public String toString(){
        return "\n\tLocal Search Method: FilterRanking"+
                "\n\tLocal Search Step: "+getLocalSearchStep();

    }

    public int[] getMaxSensW2i(SMO smo, GABitSet gab)throws Exception{
        Instances ins = smo.m_classifiers[0][1].m_data;
        double alpha[] = smo.m_classifiers[0][1].m_alpha;
        double classes[] = smo.m_classifiers[0][1].m_class;
        Kernel kernel = smo.m_classifiers[0][1].m_kernel;
        //double maxSen = -Double.MAX_VALUE;
        double originalc=0,ci = 0;
        int f = 0;
        originalc = smo.m_classifiers[0][1].m_m2;
        double sens[] = new double[data.numAttributes()];
        for (int i = 0; i < data.numAttributes(); i++) {
            if(i==data.classIndex() || gab.get(i)){
                sens[i] = Double.MAX_VALUE;
                f++;
                continue;
            }
            ci = 0;
            for (int j = 0; j < data.numInstances(); j++) {
                ci += 0.5*alpha[j]*alpha[j]*(kernel.eval(j,j,ins.instance(j))+data.instance(j).value(i)*data.instance(j).value(i));
                for (int k = 0; k < j; k++) {
                    ci += alpha[j]*alpha[k]*classes[j]*classes[k]*(kernel.eval(j,k,ins.instance(j))+data.instance(j).value(i)*data.instance(k).value(i));
                }
            }
            sens[i] = Math.abs(originalc-ci);
//            if(Math.abs(originalc-ci)>maxSen){
//                maxSen = Math.abs(originalc-ci);
//                maxSenIndex = i;
//            }
        }
        int tmp[] = Utils.sort(sens);
        int maxSenIndex[] = new int[data.numAttributes()-f];
        System.arraycopy(tmp,0,maxSenIndex,0,maxSenIndex.length);
        return maxSenIndex;
    }

    public int[] getMinSensW2i(SMO smo, GABitSet gab)throws Exception{
        Instances ins = smo.m_classifiers[0][1].m_data;
        double alpha[] = smo.m_classifiers[0][1].m_alpha;
        double classes[] = smo.m_classifiers[0][1].m_class;
        Kernel kernel = smo.m_classifiers[0][1].m_kernel;
        //double minSen = Double.MAX_VALUE;
        //int minSenIndex = -1, i=0;
        double originalc=0,ci = 0;
        originalc = smo.m_classifiers[0][1].m_m2;
        double sens[] = new double[ins.numAttributes()];
        int f = 0;
        for (int i = 0; i < ins.numAttributes(); i++) {
            if(i==ins.classIndex()) {
                sens[i] = Double.MAX_VALUE;
                f++;
                continue;
            }
            ci = 0;
            for (int j = 0; j < ins.numInstances(); j++) {
                ci += 0.5*alpha[j]*alpha[j]*(kernel.eval(j,j,ins.instance(j))-ins.instance(j).value(i)*ins.instance(j).value(i));
                for (int k = 0; k < j; k++) {
                    ci += alpha[j]*alpha[k]*classes[j]*classes[k]*(kernel.eval(j,k,ins.instance(j))-ins.instance(j).value(i)*ins.instance(k).value(i));
                }
            }
            sens[i] = -Math.abs(originalc-ci);
//            if(Math.abs(originalc-ci)<minSen){
//                minSen = Math.abs(originalc-ci);
//                minSenIndex = i;
//            }
        }
        int tmp[] = Utils.sort(sens);
        int minSenIndex [] = new int[ins.numAttributes()-f];
        int indexInOriginalData[] = bitSetToArray(gab,gab.m_chromosome.cardinality());
        for (int i = 0; i < minSenIndex.length; i++) {
            minSenIndex[i] = indexInOriginalData[tmp[i]];
        }


//        for (int v = 0,u=0; v < data.numAttributes(); v++) {
//            if(v==data.classIndex()) continue;
//            if(gab.get(v)){
//                if(u==minSenIndex) {
//                    minSenIndex = v;
//                    break;
//                }else{
//                    u++;
//                }
//            }
//        }
        return minSenIndex;
    }




    public int[] getMaxSensRMBi(SMO smo, GABitSet gab)throws Exception{
        Instances ins = smo.m_classifiers[0][1].m_data;
        double alpha[] = smo.m_classifiers[0][1].m_alpha;
        double classes[] = smo.m_classifiers[0][1].m_class;
        double beta[] = smo.m_classifiers[0][1].rmb.beta;
        Kernel kernel = smo.m_classifiers[0][1].m_kernel;
//        double maxSen = -Double.MAX_VALUE;
//        int maxSenIndex = -1, i=0;
        double originalc=0,ci = 0;
        originalc = smo.m_classifiers[0][1].m_radiusMarginBound*ins.numInstances();
        double sens[] = new double[data.numAttributes()];
        int f = 0;
        for (int i = 0; i < data.numAttributes(); i++) {
            if(i==data.classIndex() || gab.get(i)){
                sens[i] = Double.MAX_VALUE;
                f++;
                continue;
            }
            double R2 = 0, W2=0;
            for (int j = 0; j < data.numInstances(); j++) {
                double t = kernel.eval(j,j,ins.instance(j))+data.instance(j).value(i)*data.instance(j).value(i);
                R2 += beta[j]*t;
                R2 -= beta[j]*beta[j]*t;
                W2 += alpha[j]*alpha[j]*t;
                for (int k = 0; k < j; k++) {
                    t = kernel.eval(j,k,ins.instance(j))+data.instance(j).value(i)*data.instance(k).value(i);
                    W2 += 2*alpha[j]*alpha[k]*classes[j]*classes[k]*t;
                    R2 -= 2*beta[j]*beta[k]*t;
                }
            }
            ci = R2*W2;
            sens[i] = Math.abs(originalc-ci);
//            if(Math.abs(originalc-ci)>maxSen){
//                maxSen = Math.abs(originalc-ci);
//                maxSenIndex = i;
//            }
        }
        int tmp[] = Utils.sort(sens);
        int maxSenIndex[] = new int[data.numAttributes()-f];
        System.arraycopy(tmp,0,maxSenIndex,0,maxSenIndex.length);




        return maxSenIndex;
    }


    public int[] getMinSensRMBi(SMO smo, GABitSet gab)throws Exception{
        Instances ins = smo.m_classifiers[0][1].m_data;
        double alpha[] = smo.m_classifiers[0][1].m_alpha;
        double classes[] = smo.m_classifiers[0][1].m_class;
        double beta[] = smo.m_classifiers[0][1].rmb.beta;
        Kernel kernel = smo.m_classifiers[0][1].m_kernel;
//        double minSen = Double.MAX_VALUE;
//        int minSenIndex = -1, i=0;
        double originalc=0,ci = 0;
        originalc = smo.m_classifiers[0][1].m_radiusMarginBound*ins.numInstances();
        double sens[] = new double[ins.numAttributes()];
        int f = 0;
        for (int i = 0; i < ins.numAttributes(); i++) {
            if(i==ins.classIndex()){
                sens[i] = Double.MAX_VALUE;
                f++;
                continue;
            }
            double R2 = 0, W2=0;
            for (int j = 0; j < ins.numInstances(); j++) {
                double t = kernel.eval(j,j,ins.instance(j))-ins.instance(j).value(i)*ins.instance(j).value(i);
                R2 += beta[j]*t;
                R2 -= beta[j]*beta[j]*t;
                W2 += alpha[j]*alpha[j]*t;
                for (int k = 0; k < j; k++) {
                    t = kernel.eval(j,k,ins.instance(j))-ins.instance(j).value(i)*ins.instance(k).value(i);
                    W2 += 2*alpha[j]*alpha[k]*classes[j]*classes[k]*t;
                    R2 -= 2*beta[j]*beta[k]*t;
                }
            }
            ci = R2*W2;
            sens[i] = -Math.abs(originalc-ci);
//            if(Math.abs(originalc-ci)<minSen){
//                minSen = Math.abs(originalc-ci);
//                minSenIndex = i;
//            }
        }
        int tmp[] = Utils.sort(sens);
        int minSenIndex [] = new int[ins.numAttributes()-f];
        int indexInOriginalData[] = bitSetToArray(gab,gab.m_chromosome.cardinality());
        for (int i = 0; i < minSenIndex.length; i++) {
            minSenIndex[i] = indexInOriginalData[tmp[i]];
        }

//        for (int v = 0,u=0; v < data.numAttributes(); v++) {
//            if(v==data.classIndex()) continue;
//            if(gab.get(v)){
//                if(u==minSenIndex) {
//                    minSenIndex = v;
//                    break;
//                }else{
//                    u++;
//                }
//            }
//        }
//        Utils.printArray("gab=",((GeneticSearch)ga).bitSetToArray(gab,gab.m_chromosome.cardinality()));
//        System.out.println("minsi="+minSenIndex);
        return minSenIndex;
    }



    public Instances filter(Instances data, GABitSet gab)throws Exception{


        Remove delTransform = new Remove();
        delTransform.setInvertSelection(true);
        // copy the instances
        Instances trainCopy = new Instances(data);

        // set up an array of attribute indexes for the filter (+1 for the class)
        int[] featArray = new int[gab.getChromosome().cardinality() + 1];
        int i,j;
        for (i = 0, j = 0; i < trainCopy.numAttributes(); i++) {
            if (gab.get(i)) {
                featArray[j++] = i;
            }
        }

        featArray[j] = trainCopy.classIndex();
        delTransform.setAttributeIndicesArray(featArray);
        delTransform.setInputFormat(trainCopy);
        return Filter.useFilter(trainCopy, delTransform);

    }

    public int[] bitSetToArray(GABitSet bs,int length){
        //System.out.println("b2a"+bs.getChromosome());
        int [] bsa = new int[length];
        int j = 0;
        for (int i = 0; i < data.numAttributes(); i++) {
            if(bs.get(i)){
                bsa[j++] = i;
            }
        }
        for(;j<length;j++){
            bsa[j] = -1;
        }
        return bsa;
    }



}
