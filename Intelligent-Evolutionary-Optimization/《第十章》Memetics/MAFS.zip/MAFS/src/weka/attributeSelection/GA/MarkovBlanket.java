package weka.attributeSelection.GA;

import weka.attributeSelection.GeneticSearch;
import weka.core.Instances;
import weka.core.OptionHandler;
import weka.core.Utils;
import java.util.Enumeration;
import java.util.Vector;
import weka.core.Option;
//import weka.attributeSelection.CfsSubsetEval;
import weka.core.Tag;
import weka.core.SelectedTag;
import java.util.Random;
import weka.filters.Filter;
import weka.filters.supervised.attribute.Discretize;
import weka.core.FastVector;
import java.util.*;
import weka.attributeSelection.SubsetEvaluator;
/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class MarkovBlanket extends GALocalSearch implements OptionHandler{


    private Instances data;
    private int m_localSearchStep=3;
    int maxSelectedAtt;
    int minSelectedAtt;
    int classAtt;
    //Hashtable suTable;
    //LinkedHashMap lhm;
    private boolean m_probabilistic = true;
    private double m_selectionPressure = 0.2;
    private double [][] suMatrix;
    Random r;


    protected int m_selectionType = ERANK;
    public static final int LRANK = 1;
    public static final int ERANK = 2;
    public static final Tag [] TAGS_SELECTIONTYPE = {
            new Tag(LRANK, "Linear Rank Selection"),
            new Tag(ERANK, "Exponential Rank Selection")
    };


    protected int m_localSearchImprovementStrategy = IMPROVEMENTFIRST;
    public static final int IMPROVEMENTFIRST = 1;
    public static final int GREEDY = 2;
    public static final Tag [] TAGS_LSIMPROVEMENTSTRATEGY = {
            new Tag(IMPROVEMENTFIRST, "Improvement First"),
            new Tag(GREEDY, "Greedy")
    };


    public SelectedTag getLSImprovementStrategy() {

        return new SelectedTag(m_localSearchImprovementStrategy, TAGS_LSIMPROVEMENTSTRATEGY);
    }

    public void setLSImprovementStrategy(SelectedTag strategy) {

        if (strategy.getTags() == TAGS_LSIMPROVEMENTSTRATEGY) {
            m_localSearchImprovementStrategy = strategy.getSelectedTag().getID();
        }
    }


    public int getLocalSearchStep(){
        return m_localSearchStep;
    }
    public void setLocalSearchStep(int s){
        m_localSearchStep = s;
    }

    public double getSelectionPressure(){
        return m_selectionPressure;
    }
    public void setSelectionPressure(double s){
        m_selectionPressure = s;
    }

    public boolean getProbabilistic(){
        return m_probabilistic;
    }
    public void setProbabilistic(boolean b){
        m_probabilistic = b;
    }

    public SelectedTag getSelectionType() {
        return new SelectedTag(m_selectionType, TAGS_SELECTIONTYPE);
    }

    public void setSelectionType(SelectedTag type) {

        if (type.getTags() == TAGS_SELECTIONTYPE) {
            m_selectionType = type.getSelectedTag().getID();
        }
    }

    public String[] getOptions () {


        String[] options = new String[7];
        int current = 0;
        options[current++] = "-l";
        options[current++] = "" + getLocalSearchStep();
        options[current++] = "-S";
        options[current++] = "" + getSelectionPressure();
        if(getProbabilistic()){
            options[current++] = "-P";
        }

        if (m_selectionType == LRANK) {
            options[current++] = "-s";
        }else if(m_selectionType == ERANK){
            options[current++] = "-e";
        }

        if (m_localSearchImprovementStrategy == IMPROVEMENTFIRST){
            options[current++] = "-m";
        }else if(m_localSearchImprovementStrategy == GREEDY){
            options[current++] = "-n";
        }
        while (current < options.length) {
           options[current++] = "";
       }


        return  options;
    }



    public void setOptions (String[] options) throws Exception {
         String optionString;
         optionString = Utils.getOption('l', options);
         if (optionString.length() != 0) {
             setLocalSearchStep(Integer.parseInt(optionString));
         }
         optionString = Utils.getOption('S', options);
         if (optionString.length() != 0) {
             setSelectionPressure(Double.parseDouble(optionString));
         }

         setProbabilistic(Utils.getFlag('P',options));
         if (Utils.getFlag('s', options)) {
             setSelectionType(new SelectedTag(LRANK, TAGS_SELECTIONTYPE));
         } else{
             setSelectionType(new SelectedTag(ERANK, TAGS_SELECTIONTYPE));
         }

         if(Utils.getFlag('m', options)){
             setLSImprovementStrategy(new SelectedTag(IMPROVEMENTFIRST, TAGS_LSIMPROVEMENTSTRATEGY));
         }else {
             setLSImprovementStrategy(new SelectedTag(GREEDY, TAGS_LSIMPROVEMENTSTRATEGY));
         }
     }


    public Enumeration listOptions () {
        Vector newVector = new Vector(7);
        newVector.addElement(new Option("\tSet local search step size", "l", 3, "-l <step size>"));
        newVector.addElement(new Option("\tSet local search step size", "P", 0, "-P"));
        newVector.addElement(new Option("\tLinear Rank selection","s", 0, "-s"));
        newVector.addElement(new Option("\tExponential Rank selection","e", 0, "-e"));
        newVector.addElement(new Option("\tSet selection pressure","S", 0, "-S <pressure>"));
        newVector.addElement(new Option("\tImprovement Frist local search","m", 0, "-m"));
        newVector.addElement(new Option("\tGreedy local search","n", 0, "-n"));
        return  newVector.elements();
    }



    public MarkovBlanket() {
    }

    /**
     * buildLocalSearch
     *
     * @param data Instances
     * @param maxSelectedAtt int
     * @param gs GeneticSearch
     * @todo Implement this weka.attributeSelection.GA.GALocalSearch method
     */
    public void buildLocalSearch(Instances d,int min, int max,GA g,SubsetEvaluator se) {
        data = d;
        maxSelectedAtt = max;
        minSelectedAtt = min;
        ga = g;
        eval = se;
        classAtt = data.classIndex();
        //suTable = new Hashtable(1000);
        //lhm = new LinkedHashMap(data.numAttributes());
        r = new Random();

        try{
            Discretize disTransform = new Discretize();
            disTransform.setUseBetterEncoding(true);
            disTransform.setInputFormat(data);
            data = Filter.useFilter(data, disTransform);
            if(data.numAttributes()<1500){
                suMatrix = new double[data.numAttributes()][];
                for (int i = 0; i < data.numAttributes(); i++) {
                    suMatrix[i] = new double[i];
                    for (int j = 0; j < i; j++) {
                        suMatrix[i][j] = symmetricalUncertainty(i, j);
                    }
                }
            }
            double suic[] = new double[data.numAttributes()-1];
            for (int i = 0,j=0; i < data.numAttributes(); i++) {
                if(i!=classAtt){
                    suic[j] = -su(i,classAtt);
                    j++;
                }
            }
            rankedAttributes = Utils.sort(suic);
//            for (int i = 0; i < sortedList.length; i++) {
//                FastVector fv = new FastVector();
//                for (int j = i+1; j < sortedList.length; j++) {
//                    if (su(sortedList[i],sortedList[j])>=su(sortedList[j],classAtt)) {
//                        fv.addElement(new Integer(sortedList[j]));
//                    }
//                }
//                lhm.put(new Integer(sortedList[i]),fv);
//            }

//====================store only predominant feature as keys=======================
//            int sortedListCopy[] = new int[sortedList.length];
//            System.arraycopy(sortedList,0,sortedListCopy,0,sortedList.length);
//            for (int i = 0; i < sortedListCopy.length; i++) {
//                if(sortedListCopy[i]!=-1){
//                    FastVector fv = new FastVector();
//                    for (int j = i+1; j < sortedListCopy.length; j++) {
//                        if (sortedListCopy[j]!=-1 && /*su(sortedListCopy[i],classAtt)>=su(sortedListCopy[j],classAtt) &&*/ su(sortedListCopy[i],sortedListCopy[j])>=su(sortedListCopy[j],classAtt)) {
//                            fv.addElement(new Integer(sortedListCopy[j]));
//                            sortedListCopy[j] = -1;
//                        }
//                    }
//                    lhm.put(new Integer(sortedListCopy[i]),fv);
//                }
//            }
//===============================================================================
//            Iterator it = lhm.keySet().iterator();
//            while (it.hasNext()) {
//                Object k = it.next();
//                System.out.print("Key: "+k+" values: ");
//                FastVector fv=(FastVector)lhm.get(k);
//                Enumeration e = fv.elements();
//                while(e.hasMoreElements()){
//                    System.out.print("\t"+e.nextElement());
//                }
//                System.out.println("");
//            }
        }catch(Exception e){
            e.printStackTrace();
        }


    }

    /**
     * search
     *
     * @param gab GABitSet
     * @return GABitSet
     * @todo Implement this weka.attributeSelection.GA.GALocalSearch method
     */
    public GABitSet search(GABitSet gab) {
        try {
           if (m_localSearchImprovementStrategy == IMPROVEMENTFIRST) {
               Random r = new Random();
               int a[] = new int[m_localSearchStep * m_localSearchStep - 1];
               int k = ga.getParallel() > 0 ? ga.getParallel() : 1;
               for (int j = 0; j < a.length; ) {
                   if (j + ga.getParallel() > a.length) {
                       k = a.length - j;
                   }
                   GABitSet tmpB[] = new GABitSet[k];
                   for (int jj = 0; jj < k; jj++, j++) {
                       int tmp = r.nextInt(m_localSearchStep *
                                           m_localSearchStep - 1) + 1;
                       while (Utils.contain(a, j, tmp)) {
                           tmp = r.nextInt(m_localSearchStep *
                                           m_localSearchStep - 1) + 1;
                       }
                       a[j] = tmp;
                       tmpB[jj] = (GABitSet) (gab.clone());
                       int addNum = a[j] / m_localSearchStep;
                       int delNum = a[j] % m_localSearchStep;
                       int currentNum = gab.getChromosome().cardinality();
                       if(currentNum+addNum>data.numAttributes()-1){
                           addNum -= currentNum+addNum+1-data.numAttributes();
                       }
                       if(currentNum-delNum<1){
                           delNum -= 1-currentNum+delNum;
                       }
                       int finalNum = currentNum+addNum-delNum;
                       if( finalNum > maxSelectedAtt){
                           addNum -= finalNum - maxSelectedAtt;
                       }else if(finalNum < minSelectedAtt){
                           delNum -= minSelectedAtt-finalNum;
                       }
                       addDel(addNum,delNum,tmpB[jj]);

                   }
                   ga.calculateFitness(eval, tmpB);
                   for (int jj = 0; jj < k; jj++) {
                       if (ga.compareGABitSet(tmpB[jj], gab) == 1) {
                           ga.numCallingEvaluator -= (k - 1 - jj);
                           return tmpB[jj];
                       }
                   }
               }
           }else{
               GABitSet tmpB[] = new GABitSet[m_localSearchStep * m_localSearchStep - 1];
                for (int j = 1; j < (m_localSearchStep * m_localSearchStep); j++) {
                    tmpB[j - 1] = (GABitSet) (gab.clone());
                    int addNum = j / m_localSearchStep;
                    int delNum = j % m_localSearchStep;
                    int currentNum = gab.getChromosome().cardinality();
                    if(currentNum+addNum>data.numAttributes()-1){
                        addNum -= currentNum+addNum+1-data.numAttributes();
                    }
                    if(currentNum-delNum<1){
                        delNum -= 1-currentNum+delNum;
                    }
                    int finalNum = currentNum+addNum-delNum;
                    if( finalNum > maxSelectedAtt){
                        addNum -= finalNum - maxSelectedAtt;
                    }else if(finalNum < minSelectedAtt){
                        delNum -= minSelectedAtt-finalNum;
                    }
                    addDel(addNum, delNum,tmpB[j - 1]);

                }
               ga.calculateFitness(eval, tmpB);
               for (int j = 0; j < tmpB.length; j++) {
                   if (ga.compareGABitSet(tmpB[j], gab) == 1) {
                       gab = tmpB[j];
                   }
               }
               return gab;

           }

       } catch (Exception ex) {
           ex.printStackTrace();
       }


        return gab;
    }

    private void addDel(int addNo,int delNo,GABitSet gbs){
        for (int i = 0; i < addNo; i++) {
            addOne(gbs);
        }
        for (int i = 0; i < delNo; i++) {
            delOne(gbs);
        }
    }
    private void addOne(GABitSet gbs){
        int numAttribs = data.numAttributes();
        double suic [] = new double[numAttribs];
        int nNotSelected = numAttribs-gbs.getChromosome().cardinality();
        int rankedList[] = new int[nNotSelected];
        //calcualte the systemetrical uncertainty of the selected features with respect to the class label
        for (int i = 0,j=nNotSelected-1; i < rankedAttributes.length; i++) {
            if (!gbs.get(rankedAttributes[i])) {
                rankedList[j] = rankedAttributes[i];
                j--;
            }
        }
        int candi = m_selectionType==LRANK ? Utils.linearRankingSelection(rankedList,m_selectionPressure,r):Utils.exponentialRankingSelection(rankedList,m_selectionPressure,r);
//        while(hasMarkovBlanket(gbs,candi)){
//           candi = m_selectionType==LRANK ? gs.linearRankingSelection(rankedList,m_selectionPressure,r):gs.exponentialRankingSelection(rankedList,m_selectionPressure,r);
//        }
        gbs.set(candi);

        //add features without markov blanket and return
//        int maxi = Utils.maxIndex(suic);
//        for(int i=nNotSelected,maxindex = maxi; i>0; i--){
//            if(!hasMarkovBlanket(gbs,maxindex)){
//                gbs.set(maxindex);
//                return;
//            }else{
//                suic[maxindex] = -Double.MAX_VALUE;
//            }
//            maxindex = Utils.maxIndex(suic);
//        }
//        //otherwise add the feature with maximum suic
//        gbs.set(maxi);
    }

    private void delOne(GABitSet gbs){
        int numAttribs = data.numAttributes();
        //double suic [] = new double[numAttribs];
        int nSelected = gbs.getChromosome().cardinality();
        int rankedList[] = new int[nSelected];
        boolean redundancy = false;
        for (int i = 0,j=0; i < rankedAttributes.length; i++) {
            if (gbs.get(rankedAttributes[i]) && rankedAttributes[i]!=classAtt) {
                rankedList[nSelected-1-j] = rankedAttributes[i];
                j++;
//                rankedList[j] = sortedList[i];
//                j++;
//                Enumeration e = markovBlanketCover(gbs,sortedList[i]).elements();
//                if(e.hasMoreElements()){
//                    while(e.hasMoreElements()){
//                        int t = ((Integer)e.nextElement()).intValue();
//                        gbs.clear(t);
//                    }
//                    redundancy = true;
//                }
            }
        }
//        if(!redundancy){
//            int candi = m_selectionType==LRANK ? gs.linearRankingSelection(rankedList,m_selectionPressure,r):gs.exponentialRankingSelection(rankedList,m_selectionPressure,r);
//            gbs.clear(candi);
//        }


        int candi = m_selectionType==LRANK ? Utils.linearRankingSelection(rankedList,m_selectionPressure,r):Utils.exponentialRankingSelection(rankedList,m_selectionPressure,r);
        Enumeration e = markovBlanketCover(gbs,candi).elements();
        if(e.hasMoreElements()){
            while(e.hasMoreElements()){
                if(gbs.m_chromosome.cardinality()==minSelectedAtt){
                    return;
                }
                gbs.clear(((Integer)e.nextElement()).intValue());
            }
        }else{
            if(gbs.m_chromosome.cardinality()==minSelectedAtt){
                    return;
            }
            gbs.clear(candi);
        }
    }


    //check weather attribute att has Markov Blanket in the selected subset
    private boolean hasMarkovBlanket(GABitSet gbs,int att){
        for (int i = 0; i < data.numAttributes(); i++) {
            if (gbs.get(i) && i!=classAtt && i!=att && su(i,classAtt)>=su(att,classAtt) && su(att,i)>=su(att,classAtt)) {
                return true;
            }
        }
        return false;
    }

    private FastVector markovBlanketCover(GABitSet gbs,int att){
        FastVector fv = new FastVector();
        for (int i = 0; i < data.numAttributes(); i++) {
            if (gbs.get(i) && i!=classAtt && i!=att && su(att,classAtt)>=su(i,classAtt) && su(i,att)>=su(i,classAtt)) {
                fv.addElement(new Integer(i));
            }
        }
        return fv;
    }


    private double su(int i,int j){
        if(data.numAttributes()<1500){
            return i>j ? suMatrix[i][j] : suMatrix[j][i];
        }else{
            double r = 0;
            //        if(suTable.containsKey(new Pair(i,j))){
            //            r = ((Double) suTable.get(new Pair(i, j))).doubleValue();
            //        }else{
            r = symmetricalUncertainty(i, j);
            //            suTable.put(new Pair(i,j),new Double(r));
            //        }
            return r;
        }
    }

    public String toString(){
        return "\n\tLocal Search Method: FilterRanking"+
                "\n\tLocal Search Strategy: "+getLSImprovementStrategy().getSelectedTag().getReadable()+
                "\n\tLocal Search Step: "+getLocalSearchStep();

    }


    double entropy(int attrIndex){
        double ans=0,temp;
        double curIndex [] = new double[data.numInstances()];
        for (int i = 0; i < curIndex.length; i++) {
            curIndex[i] = data.instance(i).value(attrIndex);
        }

        for(int i=0; i< data.attribute(attrIndex).numValues();i++){
            temp=partialProb(attrIndex,i);
            if(temp!=(double)0)
                ans+= temp *(Math.log(temp)/Math.log((double)2.0));
        }
        return -ans;
    }


    double partialProb(int attrIndex,int attrValue){
        int count=0;
        for(int i=0;i<data.numInstances();i++)
            if(data.instance(i).value(attrIndex) == (double)attrValue)
                count++;
        if(count!=0)
            return ((double)count/(double)data.numInstances());
        else
            return (double)0;
    }

    double condEntropy(int indexOne,int indexTwo){
        double ans=0,temp,temp_ans,cond_temp;
        double oneMS [] = new double[data.numInstances()];
        double twoMS [] = new double[data.numInstances()];
        for (int i = 0; i < oneMS.length; i++) {
            oneMS[i] = data.instance(i).value(indexOne);
            twoMS[i] = data.instance(i).value(indexTwo);
        }
        for(int j=0;j<data.attribute(indexTwo).numValues();j++){
            temp=partialProb(indexTwo,j);
            temp_ans=0;

            for(int i=0;i<data.attribute(indexOne).numValues();i++){
                cond_temp=partialCondProb(indexOne,i,indexTwo,j);
                if(cond_temp != (double)0)
                    temp_ans += cond_temp *(Math.log(cond_temp)/Math.log((double)2.0));
            }
            ans+=temp*temp_ans;
        }
        return -ans;
    }

    double partialCondProb(int indexOne,int valueOne,int indexTwo,int valueTwo){
        int num=0,den=0;

        for(int i=0;i<data.numInstances();i++){
            if(data.instance(i).value(indexTwo) == (double)valueTwo){
                den++;
                if(data.instance(i).value(indexOne) == (double)valueOne)
                    num++;
            }
        }

        if(den!=0)
            return (double)num/(double)den;
        else
            return (double)0;
    }

    double informationGain(int indexOne,int indexTwo){
        return entropy(indexOne) - condEntropy(indexOne,indexTwo);
    }

    double symmetricalUncertainty(int indexOne,int indexTwo){
        double ig,e1,e2;

        ig=informationGain(indexOne,indexTwo);
        e1=entropy(indexOne);
        e2=entropy(indexTwo);

        if((e1+e2) !=(double)0)
            return((double)2 * (ig/(e1+e2)));
        else
            return (double)1;
    }

    public static void main(String []args){
        Random r = new Random();
        System.out.println(r.nextInt());
    }

    protected class Pair{
        int x,y;
        protected Pair(int a, int b){
            x=a;
            y=b;
        }
        public int hashcode(){
            return x+y;
        }
        public boolean equals(Object o){
            return (o instanceof Pair) && ((((Pair)o).x == x && ((Pair)o).y == y) || (((Pair)o).x == y && ((Pair)o).y == x));
        }
        public String toString(){
            return "x="+x+",y="+y;
        }
    }

}
