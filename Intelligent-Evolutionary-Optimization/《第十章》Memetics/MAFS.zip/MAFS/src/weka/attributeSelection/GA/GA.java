package weka.attributeSelection.GA;


import java.util.Random;

import weka.attributeSelection.ASSearch;
import weka.attributeSelection.SubsetEvaluator;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public abstract class GA extends ASSearch {
    public long numCallingEvaluator;
    public Random m_random;
    public abstract void calculateFitness(SubsetEvaluator ASEvaluator,GABitSet gabs[] ) throws Exception;
    public abstract int compareGABitSet(GABitSet a,GABitSet b);
    public abstract int getParallel();



}
