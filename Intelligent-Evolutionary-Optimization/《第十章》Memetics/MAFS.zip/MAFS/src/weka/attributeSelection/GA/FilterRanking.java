package weka.attributeSelection.GA;

import weka.core.OptionHandler;
import weka.attributeSelection.ASEvaluation;
import weka.core.Utils;
import java.util.Enumeration;
import java.util.Vector;
import weka.core.Option;
import weka.core.Instances;
import weka.attributeSelection.Ranker;
import weka.attributeSelection.ReliefFAttributeEval;
import java.util.Random;
import weka.core.Tag;
import weka.core.SelectedTag;
import weka.attributeSelection.SubsetEvaluator;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class FilterRanking extends GALocalSearch implements OptionHandler{
    private ASEvaluation m_filterRankingMethod=new ReliefFAttributeEval();

    private Instances data;
    private int m_localSearchStep=3;
    private boolean m_probabilistic = true;
    int maxSelectedAtt,minSelectedAtt;
    private double m_selectionPressure = 0.2;


    protected int m_selectionType = ERANK;
    public static final int LRANK = 1;
    public static final int ERANK = 2;
    public static final Tag [] TAGS_SELECTIONTYPE = {
            new Tag(LRANK, "Linear Rank Selection"),
            new Tag(ERANK, "Exponential Rank Selection")
    };

    protected int m_localSearchImprovementStrategy = IMPROVEMENTFIRST;
    public static final int IMPROVEMENTFIRST = 1;
    public static final int GREEDY = 2;
    public static final Tag [] TAGS_LSIMPROVEMENTSTRATEGY = {
            new Tag(IMPROVEMENTFIRST, "Improvement First"),
            new Tag(GREEDY, "Greedy")
    };


    public SelectedTag getLSImprovementStrategy() {

        return new SelectedTag(m_localSearchImprovementStrategy, TAGS_LSIMPROVEMENTSTRATEGY);
    }

    public void setLSImprovementStrategy(SelectedTag strategy) {

        if (strategy.getTags() == TAGS_LSIMPROVEMENTSTRATEGY) {
            m_localSearchImprovementStrategy = strategy.getSelectedTag().getID();
        }
    }




    public ASEvaluation getFilterRankingMethod(){
        return m_filterRankingMethod;
    }

    public void setFilterRankingMethod(ASEvaluation a){
        m_filterRankingMethod = a;
    }

    public int getLocalSearchStep(){
        return m_localSearchStep;
    }
    public void setLocalSearchStep(int s){
        m_localSearchStep = s;
    }

    public double getSelectionPressure(){
        return m_selectionPressure;
    }
    public void setSelectionPressure(double s){
        m_selectionPressure = s;
    }

    public boolean getProbabilistic(){
        return m_probabilistic;
    }
    public void setProbabilistic(boolean b){
        m_probabilistic = b;
    }

    public SelectedTag getSelectionType() {

        return new SelectedTag(m_selectionType, TAGS_SELECTIONTYPE);
    }

    public void setSelectionType(SelectedTag type) {

        if (type.getTags() == TAGS_SELECTIONTYPE) {
            m_selectionType = type.getSelectedTag().getID();
        }
    }


    public String[] getOptions () {
        String[] localHeuristicOptions = new String[0];

        if (( m_filterRankingMethod!= null) &&
            (m_filterRankingMethod instanceof OptionHandler)) {
            localHeuristicOptions = ((OptionHandler)m_filterRankingMethod).getOptions();
        }

        String[] options = new String[20+localHeuristicOptions.length];
        int current = 0;
        if (getFilterRankingMethod() != null) {
            options[current++] = "-B";
            options[current++] = getFilterRankingMethod().getClass().getName();
        }
        options[current++] = "-l";
        options[current++] = "" + getLocalSearchStep();
        options[current++] = "-S";
        options[current++] = "" + getSelectionPressure();
        if(getProbabilistic()){
            options[current++] = "-P";
        }

        if (m_selectionType == LRANK) {
            options[current++] = "-s";
        }else if(m_selectionType == ERANK){
            options[current++] = "-e";
        }

        if (m_localSearchImprovementStrategy == IMPROVEMENTFIRST){
            options[current++] = "-m";
        }else if(m_localSearchImprovementStrategy == GREEDY){
            options[current++] = "-n";
        }


        options[current++] = "--";
        System.arraycopy(localHeuristicOptions, 0, options, current,localHeuristicOptions.length);
        current += localHeuristicOptions.length;
        while (current < options.length) {
            options[current++] = "";
        }
        return  options;
    }

    public void setOptions (String[] options) throws Exception {
        String optionString;

        optionString = Utils.getOption('B', options);
        setFilterRankingMethod(ASEvaluation.forName(optionString,Utils.partitionOptions(options)));
        optionString = Utils.getOption('l', options);
        if (optionString.length() != 0) {
            setLocalSearchStep(Integer.parseInt(optionString));
        }
        optionString = Utils.getOption('S', options);
        if (optionString.length() != 0) {
            setSelectionPressure(Double.parseDouble(optionString));
        }

        setProbabilistic(Utils.getFlag('P',options));
        if (Utils.getFlag('s', options)) {
            setSelectionType(new SelectedTag(LRANK, TAGS_SELECTIONTYPE));
        } else{
            setSelectionType(new SelectedTag(ERANK, TAGS_SELECTIONTYPE));
        }

        if(Utils.getFlag('m', options)){
            setLSImprovementStrategy(new SelectedTag(IMPROVEMENTFIRST, TAGS_LSIMPROVEMENTSTRATEGY));
        }else {
            setLSImprovementStrategy(new SelectedTag(GREEDY, TAGS_LSIMPROVEMENTSTRATEGY));
        }



    }


    public Enumeration listOptions () {
        Vector newVector = new Vector(8);

        newVector.addElement(new Option("\tSet the heuristic for local search", "B", 1, "-B <instance evaluator>"));
        newVector.addElement(new Option("\tSet local search step size", "l", 3, "-l <step size>"));
        newVector.addElement(new Option("\tSet local search step size", "P", 0, "-P"));
        newVector.addElement(new Option("\tLinear Rank selection","s", 0, "-s"));
        newVector.addElement(new Option("\tExponential Rank selection","e", 0, "-e"));
        newVector.addElement(new Option("\tSet selection pressure","S", 0, "-S <pressure>"));
        newVector.addElement(new Option("\tImprovement Frist local search","m", 0, "-m"));
        newVector.addElement(new Option("\tGreedy local search","n", 0, "-n"));
        return  newVector.elements();
    }



    public GABitSet search(GABitSet gab){
        try{
            if (this.m_localSearchImprovementStrategy == IMPROVEMENTFIRST) {
                Random r = new Random();
                int a[] = new int[m_localSearchStep * m_localSearchStep - 1];
                int k = ga.getParallel() > 0 ? ga.getParallel() : 1;
                for (int j = 0; j < a.length; ) {
                    if (j + ga.getParallel() > a.length) {
                        k = a.length - j;
                    }
                    GABitSet tmpB[] = new GABitSet[k];
                    for (int jj = 0; jj < k; jj++, j++) {
                        int tmp = r.nextInt(m_localSearchStep *
                                            m_localSearchStep - 1) + 1;
                        while (Utils.contain(a, j, tmp)) {
                            tmp = r.nextInt(m_localSearchStep *
                                            m_localSearchStep - 1) + 1;
                        }
                        a[j] = tmp;
                        tmpB[jj] = (GABitSet) (gab.clone());
                        int addNum = a[j] / m_localSearchStep;
                        int delNum = a[j] % m_localSearchStep;
                        int currentNum = gab.getChromosome().cardinality();
                        if(currentNum+addNum>data.numAttributes()-1){
                            addNum -= currentNum+addNum+1-data.numAttributes();
                        }
                        if(currentNum-delNum<1){
                            delNum -= 1-currentNum+delNum;
                        }
                        int finalNum = currentNum+addNum-delNum;
                        if( finalNum > maxSelectedAtt){
                            addNum -= finalNum - maxSelectedAtt;
                        }else if(finalNum < minSelectedAtt){
                            delNum -= minSelectedAtt-finalNum;
                        }

                        addDel(addNum,delNum,tmpB[jj]);
                    }
                    ga.calculateFitness(eval, tmpB);
                    for (int jj = 0; jj < k; jj++) {
                        if (ga.compareGABitSet(tmpB[jj], gab) == 1) {
                            ga.numCallingEvaluator -= (k - 1 - jj);
                            return tmpB[jj];
                        }
                    }
                }
            } else {
                GABitSet tmpB[] = new GABitSet[m_localSearchStep * m_localSearchStep - 1];
                for (int j = 1; j < (m_localSearchStep * m_localSearchStep); j++) {
                    tmpB[j - 1] = (GABitSet) (gab.clone());
                    int addNum = j / m_localSearchStep;
                    int delNum = j % m_localSearchStep;
                    int currentNum = gab.getChromosome().cardinality();
                    if(currentNum+addNum>data.numAttributes()-1){
                        addNum -= currentNum+addNum+1-data.numAttributes();
                    }
                    if(currentNum-delNum<1){
                        delNum -= 1-currentNum+delNum;
                    }
                    int finalNum = currentNum+addNum-delNum;
                    if( finalNum > maxSelectedAtt){
                        addNum -= finalNum - maxSelectedAtt;
                    }else if(finalNum < minSelectedAtt){
                        delNum -= minSelectedAtt-finalNum;
                    }
                    addDel(addNum, delNum,tmpB[j - 1]);
                }
                ga.calculateFitness(eval, tmpB);
                for (int j = 0; j < tmpB.length; j++) {
                    if (ga.compareGABitSet(tmpB[j], gab) == 1) {
                        gab = tmpB[j];
                    }
                }
                return gab;

            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return gab;
    }

    public void buildLocalSearch(Instances d,int min,int max,GA g,SubsetEvaluator se){
        data = d;
        maxSelectedAtt = max;
        minSelectedAtt = min;
        ga = g;
        eval = se;
        try {
            m_filterRankingMethod.buildEvaluator(data);
            Ranker rk = new Ranker();
            rankedAttributes = rk.search(m_filterRankingMethod,data);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void addDel(int addNo,int delNo,GABitSet gbs){
        Random r = new Random();

        for (int i = 0; i < addNo; i++) {
            addOne(gbs,r);
        }
        for (int i = 0; i < delNo; i++) {
            delOne(gbs,r);
        }
    }

    private int lookUpRank(int attributeNum){
        for (int i = 0; i < rankedAttributes.length; i++) {
            if(rankedAttributes[i] == attributeNum){
                return i;
            }
        }
        return -1;
    }


    ////add num feature to the GABitSet gbs
    private void addOne(GABitSet gbs,Random r){
        int n = rankedAttributes.length - gbs.getChromosome().cardinality();
        int [] addList = new int[n];
        for (int i = 0,j=0; i < rankedAttributes.length; i++) {
            if(!gbs.get(rankedAttributes[i])){
                addList[n-1-j] = rankedAttributes[i];
                j++;
            }
        }
        if(m_probabilistic){
            if(m_selectionType == ERANK){
                gbs.set(Utils.exponentialRankingSelection(addList, m_selectionPressure, r));
            }else{
                gbs.set(Utils.linearRankingSelection(addList, m_selectionPressure, r));
            }
        }else{
            gbs.set(addList[n-1]);
        }
    }

    private void delOne(GABitSet gbs,Random r){
        int n = gbs.getChromosome().cardinality();
        int [] delList = new int[n];
        for (int i = 0,j=0; i < rankedAttributes.length; i++) {
            if(gbs.get(rankedAttributes[i])){
                delList[j] = rankedAttributes[i];
                j++;
            }
        }
        if(m_probabilistic){
            if(m_selectionType == ERANK){
                gbs.clear(Utils.exponentialRankingSelection(delList, m_selectionPressure, r));
            }else{
                gbs.clear(Utils.linearRankingSelection(delList, m_selectionPressure, r));
            }
        }else{
            gbs.clear(delList[n-1]);
        }
    }

    public String toString(){
        return "\n\tLocal Search Method: FilterRanking"+
                "\n\tLocal Search Strategy: "+getLSImprovementStrategy().getSelectedTag().getReadable()+
                "\n\tLocal Search Step: "+getLocalSearchStep()+
                "\n\tProbabilistic Local Search: "+getProbabilistic()+
                "\n\tLocal Search Selection Type: "+getSelectionType().getSelectedTag().getReadable()+
                "\n\tLocal Search Selection Pressure: "+getSelectionPressure();

    }

    public FilterRanking() {
    }
}
