package weka.attributeSelection.GA;

import java.util.BitSet;
import java.io.Serializable;
import weka.attributeSelection.GeneticSearch;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class GABitSet implements Cloneable, Serializable {

  public BitSet m_chromosome;

    /** holds raw merit */
    //private double m_classifierAccuracy;
  private double m_objective = -Double.MAX_VALUE;
  private double m_fitness;

  public int rank;
  public double constr_violation;
  public double [] xreal;
  public double []obj;
  public double []constr;
  public double crowd_dist;



  /**
   * Constructor
   */
  public GABitSet () {
    m_chromosome = new BitSet();
  }

  public GABitSet(int n){
      m_chromosome = new BitSet(n);
  }

  /**
   * makes a copy of this GABitSet
   * @return a copy of the object
   * @exception Exception if something goes wrong
   */
  public Object clone() throws CloneNotSupportedException {
    GABitSet temp = new GABitSet();

    temp.setObjective(this.getObjective());
    temp.setFitness(this.getFitness());
    temp.setChromosome((BitSet)(this.m_chromosome.clone()));
    temp.rank = this.rank;
    temp.constr_violation = this.constr_violation;
    temp.crowd_dist = this.crowd_dist;
    if(xreal!=null){
        temp.xreal = new double[xreal.length];
        System.arraycopy(this.xreal, 0, temp.xreal, 0, xreal.length);
    }
    if(constr!=null){
        temp.constr = new double[this.constr.length];
        System.arraycopy(this.constr, 0, temp.constr, 0, constr.length);
    }
    if(obj !=null){
        temp.obj = new double[this.obj.length];
        System.arraycopy(this.obj, 0, temp.obj, 0, obj.length);
    }
    return temp;
    //return super.clone();
  }

  /**
   * sets the objective merit value
   * @param objective the objective value of this population member
   */
  public void setObjective(double objective) {
    m_objective = objective;
  }

  /**
   * gets the objective merit
   * @return the objective merit of this population member
   */
  public double getObjective() {
    return m_objective;
  }

  /**
   * sets the scaled fitness
   * @param the scaled fitness of this population member
   */
  public void setFitness(double fitness) {
    m_fitness = fitness;
  }

  /**
   * gets the scaled fitness
   * @return the scaled fitness of this population member
   */
  public double getFitness() {
    return m_fitness;
  }

  /**
   * get the chromosome
   * @return the chromosome of this population member
   */
  public BitSet getChromosome() {
    return m_chromosome;
  }

  /**
   * set the chromosome
   * @param the chromosome to be set for this population member
   */
  public void setChromosome(BitSet c) {
    m_chromosome = c;
  }

  /**
   * unset a bit in the chromosome
   * @param bit the bit to be cleared
   */
  public void clear(int bit) {
    m_chromosome.clear(bit);
  }

  /**
   * set a bit in the chromosome
   * @param bit the bit to be set
   */
  public void set(int bit) {
    m_chromosome.set(bit);
  }

  /**
   * get the value of a bit in the chromosome
   * @param bit the bit to query
   * @return the value of the bit
   */
  public boolean get(int bit) {
      return m_chromosome.get(bit);
  }
  }
