package weka.attributeSelection.GA;

import weka.attributeSelection.GeneticSearch;
import weka.core.Instances;
import weka.core.Utils;
import java.io.Serializable;
import weka.core.OptionHandler;
import weka.attributeSelection.SubsetEvaluator;
import weka.core.SerializedObject;
import weka.classifiers.Classifier;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public abstract class GALocalSearch implements Serializable,Cloneable{
    public int [] rankedAttributes = null;
    SubsetEvaluator eval;
    GA ga;
    public abstract GABitSet search(GABitSet gab);
    public abstract void buildLocalSearch(Instances data,int minNumBin, int maxNumBin,GA ga,SubsetEvaluator sbe);
    public static GALocalSearch forName(String evaluatorName, String [] options) throws Exception {
        return (GALocalSearch)Utils.forName(GALocalSearch.class, evaluatorName, options);
    }
    public GALocalSearch() {
    }
    public static GALocalSearch makeCopy(GALocalSearch model) throws Exception {

    return (GALocalSearch)new SerializedObject(model).getObject();
  }

  /**
   * Creates a given number of deep copies of the given classifier using serialization.
   *
   * @param model the classifier to copy
   * @param num the number of classifier copies to create.
   * @return an array of classifiers.
   * @exception Exception if an error occurs
   */
  public static GALocalSearch [] makeCopies(GALocalSearch model,
                                         int num) throws Exception {

    if (model == null) {
      throw new Exception("No model set");
    }
    GALocalSearch [] galss = new GALocalSearch [num];
    SerializedObject so = new SerializedObject(model);
    for(int i = 0; i < galss.length; i++) {
      galss[i] = (GALocalSearch) so.getObject();
    }
    return galss;
  }

}
