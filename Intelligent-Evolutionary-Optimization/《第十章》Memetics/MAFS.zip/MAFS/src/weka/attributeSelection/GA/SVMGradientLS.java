package weka.attributeSelection.GA;

import weka.attributeSelection.GeneticSearch;
import weka.core.Instances;
import weka.core.Option;
import java.util.Vector;
import weka.classifiers.functions.SMO;
import weka.core.Utils;
import java.util.Enumeration;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.Filter;
import weka.attributeSelection.SVMGradient;
import weka.attributeSelection.Ranker;
import weka.core.SelectedTag;
import weka.attributeSelection.RankGeneMeasures;
import java.util.Random;
import weka.attributeSelection.SubsetEvaluator;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class SVMGradientLS extends GALocalSearch {
    protected double m_c = 1.0;
    protected int m_localSearchStep=3;
    protected double m_stepsize = 0.1;
    protected double m_Xtol = 1e-3;
    protected int m_maxIter = 50;
    protected boolean m_iterationInfo = false;
    protected int numClassification = 0;
    double scale [];
    private Instances data;
    int maxSelectedAtt;
    int minSelectedAtt;
    protected boolean m_convergedSolution = true;
    protected boolean m_gradientSearch = true;

    protected int m_filterType = SMO.FILTER_NORMALIZE;


    protected double m_exponent = 1.0;
    protected boolean m_lowerOrder = false;
    protected double m_gamma = 0.01;
    protected boolean m_useRBF = false;

    public double getExponent() {
        return m_exponent;
    }

    public void setExponent(double v) {
        if (v == 1.0) {
            m_lowerOrder = false;
        }
        m_exponent = v;
    }

    public double getGamma() {
        return m_gamma;
    }
    public void setGamma(double v) {
        m_gamma = v;
    }

    public boolean getLowerOrderTerms() {
        return m_lowerOrder;
    }
    public void setLowerOrderTerms(boolean v) {

        if (m_exponent == 1.0 || m_useRBF) {
            m_lowerOrder = false;
        } else {
            m_lowerOrder = v;
        }
    }
    public boolean getUseRBF() {
        return m_useRBF;
    }
    public void setUseRBF(boolean v) {
        if (v) {
            m_lowerOrder = false;
        }
        m_useRBF = v;
    }
    public boolean getGradientSearch() {
        return m_gradientSearch;
    }
    public void setGradientSearch(boolean v) {
        m_gradientSearch = v;
    }



    public SelectedTag getFilterType() {

        return new SelectedTag(m_filterType, SMO.TAGS_FILTER);
    }

    public void setFilterType(SelectedTag newType) {

        if (newType.getTags() == SMO.TAGS_FILTER) {
            m_filterType = newType.getSelectedTag().getID();
        }
    }

    public void setConvergedSolution(boolean b){
        m_convergedSolution = b;
    }
    public boolean getConvergedSolution(){
        return m_convergedSolution;
    }




    public int getNumClassification(){
        return numClassification;
    }
    public double getC() {
        return m_c;
    }
    public void setC(double c){
        m_c = c;
    }
    public int getLocalSearchStep() {
        return m_localSearchStep;
    }
   public void setLocalSearchStep(int q){
       m_localSearchStep = q;
   }
   public double getStepSize() {
       return m_stepsize;
   }
   public void setStepSize(double m){
       m_stepsize = m;
   }
   public double getXTolerance(){
       return m_Xtol;
   }
   public void setXTolerance(double x){
       m_Xtol = x;
   }
   public int getMaxIteration(){
       return m_maxIter;
   }
   public void setMaxIteration(int m){
       m_maxIter = m;
   }
   public void setIterationInfo(boolean a){
       m_iterationInfo = a;
   }
   public boolean getIterationInfo(){
       return m_iterationInfo;
   }



   public void setOptions(String[] options) throws Exception{
       String optionString;

       optionString = Utils.getOption('C', options);
       if (optionString.length() != 0) {
           setC(Double.parseDouble(optionString));
       }
       optionString = Utils.getOption('Q', options);
       if (optionString.length() != 0) {
           setLocalSearchStep(Integer.parseInt(optionString));
       }
       optionString = Utils.getOption('P', options);
       if (optionString.length() != 0) {
           setStepSize(Double.parseDouble(optionString));
       }
       optionString = Utils.getOption('X', options);
       if (optionString.length() != 0) {
           setXTolerance(Double.parseDouble(optionString));
       }
       optionString = Utils.getOption('I', options);
       if (optionString.length() != 0) {
           setMaxIteration(Integer.parseInt(optionString));
       }
       optionString = Utils.getOption('F', options);
       if (optionString.length() != 0) {
           setIterationInfo(true);
       }
       optionString = Utils.getOption('V', options);
        if (optionString.length() != 0) {
            setConvergedSolution(true);
        }
        String nString = Utils.getOption('N', options);
        if (nString.length() != 0) {
            setFilterType(new SelectedTag(Integer.parseInt(nString), SMO.TAGS_FILTER));
        } else {
            setFilterType(new SelectedTag(SMO.FILTER_NORMALIZE, SMO.TAGS_FILTER));
        }
        String exponentsString = Utils.getOption('E', options);
        if (exponentsString.length() != 0) {
            m_exponent = (new Double(exponentsString)).doubleValue();
        } else {
            m_exponent = 1.0;
        }

        String gammaString = Utils.getOption('G', options);
        if (gammaString.length() != 0) {
            m_gamma = (new Double(gammaString)).doubleValue();
        } else {
            m_gamma = 0.01;
        }
        m_useRBF = Utils.getFlag('B', options);
        m_lowerOrder = Utils.getFlag('L', options);
        m_gradientSearch = Utils.getFlag('S', options);


       Utils.checkForRemainingOptions(options);
   }
   public String[] getOptions(){
       String[] options = new String[22];
       int current = 0;

       options[current++] = "-C";
       options[current++] = "" + getC();
       options[current++] = "-Q";
       options[current++] = "" + getLocalSearchStep();
       options[current++] = "-P";
       options[current++] = "" + getStepSize();
       options[current++] = "-X";
       options[current++] = "" + getXTolerance();
       options[current++] = "-I";
       options[current++] = "" + getMaxIteration();
       options[current++] = "-N"; options[current++] = "" + m_filterType;
       options[current++] = "-E"; options[current++] = "" + m_exponent;
        options[current++] = "-G"; options[current++] = "" + m_gamma;
        if (m_lowerOrder) {
            options[current++] = "-L";
        }
        if (m_useRBF) {
            options[current++] = "-B";
        }
        if (m_gradientSearch) {
            options[current++] = "-S";
        }




       if(getIterationInfo()){
           options[current++] = "-F";
       }
       if(getConvergedSolution()){
            options[current++] = "-V";
        }

       while (current < options.length) {
           options[current++] = "";
       }

       return options;


   }
   public Enumeration listOptions(){
       Vector newVector = new Vector(13);
       newVector.addElement(new Option("\tSpecify C of svm.","C",1,"-C <number>"));
       newVector.addElement(new Option("\tSpecify the localSearchStep.","Q",1,"-Q <number>"));
       newVector.addElement(new Option("\tSpecify the number of Max Iteration.","I",1,"-I <number>"));
       newVector.addElement(new Option("\tSpecify the number of Step Size.","P",1,"-P <number>"));
       newVector.addElement(new Option("\tSpecify the number of X Tolerance.","X",1,"-X <number>"));
       newVector.addElement(new Option("\tPrint iteration information.","F",1,"-F"));
       newVector.addElement(new Option("\tReturn converge solution.","V",1,"-V"));
       newVector.addElement(new Option("\tWhether to 0=normalize/1=standardize/2=neither. (default 0=normalize)", "N", 1, "-N"));
       newVector.addElement(new Option("\tThe exponent for the "
                                        + "polynomial kernel. (default 1)",
                                        "E", 1, "-E <double>"));
        newVector.addElement(new Option("\tGamma for the RBF kernel. (default 0.01)",
                                        "G", 1, "-G <double>"));
        newVector.addElement(new Option("\tUse lower-order terms (only for non-linear\n" +
                                        "\tpolynomial kernels).",
                                        "L", 0, "-L"));
        newVector.addElement(new Option("\tUse RBF kernel. " +
                                        "(default poly)",
                                        "B", 0, "-B"));
        newVector.addElement(new Option("\tUse Gradient Search. false rank feature base gradient, true optimization rank by scale " +
                                        "(default true)",
                                        "S", 1, "-S"));

       return newVector.elements();
   }


   /**
    * buildLocalSearch
    *
    * @param data Instances
    * @param maxSelectedAtt int
    * @param gs GeneticSearch
    * @todo Implement this weka.attributeSelection.GA.GALocalSearch method
     */
    public void buildLocalSearch(Instances d, int min,int max, GA g,SubsetEvaluator se) {
        data = d;
        maxSelectedAtt = max;
        minSelectedAtt = min;
        ga = g;
        eval = se;
        try {
            RankGeneMeasures svm1d = new RankGeneMeasures();
            svm1d.setMeasureType(new SelectedTag(RankGeneMeasures.ODSVM, RankGeneMeasures.TAGS_MEASURETYPE));
            svm1d.set_C(m_c);
            svm1d.buildEvaluator(d);
            Ranker rk = new Ranker();
            int tmp[] = rk.search(svm1d,data);
            rankedAttributes = new int[tmp.length];
            for (int i = 0; i < tmp.length; i++) {
                rankedAttributes[i] = tmp[tmp.length-1-i];
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }


    }

    /**
     * search
     *
     * @param gab GABitSet
     * @return GABitSet
     * @todo Implement this weka.attributeSelection.GA.GALocalSearch method
     */
    public GABitSet search(GABitSet gab) {
        try {
            int numSelected = gab.getChromosome().cardinality();
//            if(numSelected <= m_localSearchStep){
//                return gab;
//            }
            Random r = new Random();
            //System.out.println(gab.getChromosome().toString());
            for (int i = 0; i < m_localSearchStep-1 && numSelected<maxSelectedAtt; i++) {
                int add = Utils.exponentialRankingSelection(rankedAttributes,0.1,r);
                while(gab.get(add)){
                    add = Utils.exponentialRankingSelection(rankedAttributes,0.1,r);
                    //System.out.println(add);
                }
                gab.set(add);
                numSelected++;
            }

            Remove delTransform = new Remove();
            delTransform.setInvertSelection(true);
            int[] featArray = new int[numSelected + 1];
            int j = 0;
            for (int i = 0; i < data.numAttributes(); i++) {
                if (gab.get(i)) {
                    featArray[j++] = i;
                }
            }
            featArray[j] = data.classIndex();
            delTransform.setAttributeIndicesArray(featArray);
            delTransform.setInputFormat(data);
            Instances smodata = Filter.useFilter(data, delTransform);
            SVMGradient svmg = new SVMGradient();
            Ranker rk = new Ranker();
            svmg.setC(m_c);
            svmg.setIterationInfo(m_iterationInfo);
            svmg.setMaxIteration(m_maxIter);
            svmg.setStepSize(m_stepsize);
            svmg.setXTolerance(m_Xtol);
            svmg.setConvergedSolution(m_convergedSolution);
            svmg.setFilterType(new SelectedTag(m_filterType, SMO.TAGS_FILTER));
            svmg.setExponent(m_exponent);
            svmg.setGamma(m_gamma);
            svmg.setLowerOrderTerms(m_lowerOrder);
            svmg.setUseRBF(m_useRBF);
            svmg.setGradientSearch(m_gradientSearch);
            svmg.buildEvaluator(smodata);

            int ranked[] = rk.search(svmg,smodata);
            ga.numCallingEvaluator += svmg.getNumClassification();

            GABitSet tmpgab[] = {(GABitSet)gab.clone()};

            int i = ranked.length-1;
            do{
                if(tmpgab[0].getChromosome().cardinality()==minSelectedAtt){
                    break;
                }
                gab = (GABitSet)tmpgab[0].clone();
                tmpgab[0].clear(featArray[ranked[i]]);
                ga.calculateFitness(eval,tmpgab);
                i--;
            }while(ga.compareGABitSet(tmpgab[0],gab) == 1);


            return gab;


        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
//    public GABitSet fastDel(int from,int to,int stepsize,GABitSet t,int[]ranked,int[]featArray)throws Exception{
//        if(from<to){
//            if(from+stepsize>to){
//                return t;
//            }
//            GABitSet tmpgab[] = {(GABitSet)t.clone()};
//            for (int i = to; i >= from+stepsize; i--) {
//                tmpgab[0].clear(featArray[ranked[i]]);
//            }
//            gs.calculateFitness(gs.ASEvaluator,tmpgab);
//            if(gs.compareGABitSet(tmpgab[0],t) == 1){
//                return fastDel(from+stepsize,from,(stepsize+1)/2,tmpgab[0],ranked,featArray);
//            }else{
//                return fastDel(from+stepsize,to,(stepsize+1)/2,t,ranked,featArray);
//            }
//        }else{
//            if(from-stepsize<to){
//                return t;
//            }
//            GABitSet tmpgab[] = {(GABitSet)t.clone()};
//            for (int i = from; i >= from-stepsize; i--) {
//                tmpgab[0].clear(featArray[ranked[i]]);
//            }
//            gs.calculateFitness(gs.ASEvaluator,tmpgab);
//            if(gs.compareGABitSet(tmpgab[0],t) == 1){
//                return fastDel(from-stepsize,to,to<=m_localSearchStep?stepsize:(stepsize+1)/2,tmpgab[0],ranked,featArray);
//            }else{
//                return fastDel(from-stepsize,from,(stepsize+1)/2,t,ranked,featArray);
//            }
//        }
//
//    }
}
