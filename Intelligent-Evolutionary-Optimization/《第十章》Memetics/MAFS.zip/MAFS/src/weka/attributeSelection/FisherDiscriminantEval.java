package weka.attributeSelection;

import weka.core.Instances;
import weka.core.OptionHandler;
import weka.core.Utils;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *evaluate feature: [mean(class1)+mean(class2)]^2/(variance(class1)+varianc3(class2))
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class FisherDiscriminantEval extends AttributeEvaluator{

    private int m_classIndex;
    private Instances m_insts;
    private int m_instancesOfClass [];
    public FisherDiscriminantEval() {
    }

    /**
     * Generates a attribute evaluator.
     *
     * @param data set of instances serving as training data
     * @throws Exception if the evaluator has not been generated successfully
     * @todo Implement this weka.attributeSelection.ASEvaluation method
     */
    public void buildEvaluator(Instances data) throws Exception {
        m_classIndex = data.classIndex();
        m_insts = data;
        if(m_insts.attribute(m_classIndex).numValues()!=2){
           throw new Exception(this.getClass().getName()+" can handle only 2-class problem");
        }
        m_instancesOfClass = new int[2];
        for (int i = 0; i < m_insts.numInstances(); i++) {
            m_instancesOfClass[(int)m_insts.instance(i).value(m_classIndex)]++;
        }
    }

    /**
     *
     * @param attribute the index of the attribute to be evaluated
     * @return the "merit" of the attribute
     * @throws Exception if the attribute could not be evaluated
     * @todo Implement this weka.attributeSelection.AttributeEvaluator method
     */
    public double evaluateAttribute(int attribute) throws Exception {
        double class1[] = new double[m_instancesOfClass[0]], class2[]=new double[m_instancesOfClass[1]];
        for (int i = 0,i1=0,i2=0; i < m_insts.numInstances(); i++) {
            if((int)m_insts.instance(i).value(m_classIndex)==0){
                class1[i1++] = m_insts.instance(i).value(attribute);
            }else{
                class2[i2++] = m_insts.instance(i).value(attribute);
            }
        }
        double sumMean = Utils.mean(class1)+Utils.mean(class2);
        return sumMean*sumMean/(Utils.variance(class1)+Utils.variance(class2)+1e-10);
    }
}
