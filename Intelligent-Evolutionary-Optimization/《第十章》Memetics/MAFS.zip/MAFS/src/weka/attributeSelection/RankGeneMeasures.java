package weka.attributeSelection;

import weka.core.Instances;
import weka.core.OptionHandler;
import weka.core.SelectedTag;
import weka.core.Utils;
import weka.core.Tag;
import java.util.Vector;
import weka.core.Option;
import java.util.Enumeration;
import java.util.Comparator;
import java.util.Arrays;
import java.util.Random;
import java.io.Serializable;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class RankGeneMeasures extends AttributeEvaluator implements OptionHandler {

    Instances train_points;
    int no_of_train_points=0;
    int no_of_dimensions=0,no_of_genes=0,no_of_categories=0;
    int left_count[], right_count[];
    int sv1_class,sv2_class;
    //double onedsv1,onedsv2;
    double svm_c=1;
    double t_test;
    double [] t_test_array;
    public Unidim []candidates;

    private int m_measureType = IG;
    public static final int IG = 1;
    public static final int TR = 2;
    public static final int SM = 3;
    public static final int MM = 4;
    public static final int GI = 5;
    public static final int SV = 6;
    public static final int TS = 7;
    public static final int ODSVM = 8;
    public static final Tag [] TAGS_MEASURETYPE = {
     new Tag(IG, "Information Gain"),
     new Tag(TR, "Twoing Rule"),
     new Tag(SM,"Sum Minority"),
     new Tag(MM,"Max Minority"),
     new Tag(GI,"Gini Index"),
     new Tag(SV,"Sum of Variances"),
     new Tag(TS,"T-Statistic"),
     new Tag(ODSVM,"One Dimensional SVM")
    };


    class Oned_SVM{
        public int cat;
        public double value;
        public double left_total;
        public double right_total;
    };

    class Unidim implements Serializable{
        public double value;
        public int cat;
    };

    class UnidimComparator implements Comparator {
        public int compare(Object ptr1, Object ptr2) {
            double x;
            x = ((Unidim)ptr1).value - ((Unidim)ptr2).value;
            if (x > 0) return(1);
            else if (x<0) return(-1);
            else return(0);
        }
    };


    public RankGeneMeasures(){
    }

    public RankGeneMeasures(int measureType){
        setMeasureType(new SelectedTag(measureType,TAGS_MEASURETYPE));
    }

    public SelectedTag getMeasureType() {

     return new SelectedTag(m_measureType, TAGS_MEASURETYPE);
   }

   public void setMeasureType(SelectedTag type) {

     if (type.getTags() == TAGS_MEASURETYPE) {
       m_measureType = type.getSelectedTag().getID();
     }
   }

   public void set_C(double c){
       svm_c = c;
   }
   public void setOptions(String[] options) throws Exception {

       if (Utils.getFlag('I', options)) {
           setMeasureType(new SelectedTag(IG, TAGS_MEASURETYPE));
       }
       if (Utils.getFlag('R', options)) {
           setMeasureType(new SelectedTag(TR, TAGS_MEASURETYPE));
       }
       if (Utils.getFlag('S', options)) {
           setMeasureType(new SelectedTag(SM, TAGS_MEASURETYPE));
       }
       if (Utils.getFlag('M', options)) {
           setMeasureType(new SelectedTag(MM, TAGS_MEASURETYPE));
       }
       if (Utils.getFlag('G', options)) {
           setMeasureType(new SelectedTag(GI, TAGS_MEASURETYPE));
       }
       if (Utils.getFlag('V', options)) {
           setMeasureType(new SelectedTag(SV, TAGS_MEASURETYPE));
       }
       if (Utils.getFlag('T', options)) {
           setMeasureType(new SelectedTag(TS, TAGS_MEASURETYPE));
       }
       if (Utils.getFlag('O', options)) {
           setMeasureType(new SelectedTag(ODSVM, TAGS_MEASURETYPE));
       }
   }
   public String [] getOptions() {

       String [] options = new String [1];
       int current = 0;
       switch (m_measureType) {
       case IG:
           options[current++] = "-I";
           break;
       case TR:
           options[current++] = "-R";
           break;
       case SM:
           options[current++] = "-S";
           break;
       case MM:
           options[current++] = "-M";
           break;
       case GI:
           options[current++] = "-G";
           break;
       case SV:
           options[current++] = "-V";
           break;
       case TS:
           options[current++] = "-T";
           break;
       case ODSVM:
           options[current++] = "-O";
           break;
       }

       while (current < options.length) {
           options[current++] = "";
       }
       return options;
  }

  public Enumeration listOptions() {

     Vector newVector = new Vector(8);

     newVector.addElement(new Option("\tUse impurity measure of Information Gain.\n", "I", 1, "-I"));
     newVector.addElement(new Option("\tUse impurity measure of Twoing Rule.\n", "R", 1, "-R"));
     newVector.addElement(new Option("\tUse impurity measure of Sum Minority.\n", "S", 1, "-S"));
     newVector.addElement(new Option("\tUse impurity measure of Max Minority.\n", "M", 1, "-M"));
     newVector.addElement(new Option("\tUse impurity measure of Gini Index.\n", "G", 1, "-G"));
     newVector.addElement(new Option("\tUse impurity measure of Sum of Variances.\n", "V", 1, "-V"));
     newVector.addElement(new Option("\tUse impurity measure of T-statistics.\n", "T", 1, "-T"));
     newVector.addElement(new Option("\tUse impurity measure of One Dimension SVM.\n", "O", 1, "-O"));
     return newVector.elements();
  }


    /**
     * Generates a attribute evaluator.
     *
     * @param data set of instances serving as training data
     * @throws Exception if the evaluator has not been generated successfully
     * @todo Implement this weka.attributeSelection.ASEvaluation method
     */
    public void buildEvaluator(Instances d) throws Exception {
        train_points = d;
        no_of_train_points = d.numInstances();
        no_of_dimensions = d.numAttributes()-1;
        no_of_categories = d.attribute(d.classIndex()).numValues();
        if (m_measureType >=7 && no_of_categories > 2) {
            throw new Exception("Error: Measures 7 (t-test) and 8 (one-dimensional support vector machines) only accept data sets with two classes.\n");
        }
        no_of_genes = no_of_dimensions;
        left_count = new int[no_of_categories+1];
        right_count = new int[no_of_categories+1];
        t_test_array = new double[no_of_genes];
        candidates = new Unidim[no_of_train_points+1];
    }

    /**
     *
     * @param attribute the index of the attribute to be evaluated
     * @return the "merit" of the attribute
     * @throws Exception if the attribute could not be evaluated
     * @todo Implement this weka.attributeSelection.AttributeEvaluator method
     */
    public double evaluateAttribute(int attribute) throws Exception {
        candidates[0] = new Unidim();
        for (int i = 0; i < no_of_train_points; i++) {
            candidates[i+1] = new Unidim();
            candidates[i+1].value = train_points.instance(i).value(attribute);
            candidates[i+1].cat = (int)train_points.instance(i).value(train_points.classIndex())+1;
        }
        return -linear_split(no_of_train_points);
    }


    double compute_impurity(int cur_no_of_points){
        double temp = 0;
        switch(m_measureType){
        case IG:
            temp = info_gain();
            break;
        case TR:
            temp = twoing();
            break;
        case SM:
            temp = summinority();
            break;
        case MM:
            temp = maxminority();
            break;
        case GI:
            temp = gini_index();
            break;
        case SV:
            temp = variance();
            break;
        }
        return temp;
    }




    double linear_split(int no_of_eff_points){
        int i,j,from,to,count1,count2,position1,position2;
        int position = 0;
        double temp,impurity_1d;
        double smallest,largest;
        double mean1,mean2,var1,var2,t;
        double []array1;
        double []array2;
        Oned_SVM []candidates1;
        Oned_SVM []candidates2;
        if (m_measureType <= 6) {
            Arrays.sort(candidates,1,candidates.length,new UnidimComparator());
            reset_counts();
            for (i=1;i<=no_of_eff_points;i++)
            {
                right_count[candidates[i].cat]++;
                //left_count[candidates[i].cat]--;
            }
            impurity_1d = compute_impurity(no_of_eff_points);
            Random random = new Random();
            for (i=1;i<=no_of_eff_points;i++)
            {
                from = i;
                for (to=from+1;to<=no_of_eff_points && candidates[to].value ==
                        candidates[from].value;to++);
                to -= 1;

                for (j=from;j<=to;j++)
                {
                    left_count[candidates[j].cat]++;
                    right_count[candidates[j].cat]--;
                }

                i = to;
                temp = compute_impurity(no_of_eff_points);


                if (temp < impurity_1d ||
                    (temp == impurity_1d && random.nextDouble() < 0.5))
                {
                    impurity_1d = temp;
//                    onedsv1 = candidates[from].value;
//                    onedsv2 = candidates[to+1].value;
                    if (impurity_1d == 0) break;
                }
            }
        }

        else if (m_measureType == 7) {
            Arrays.sort(candidates,1,candidates.length,new UnidimComparator());
            count1 = 0;
            count2 = 0;
            for(i=1;i<=no_of_eff_points;i++) {
                if(candidates[i].cat == 1)
                    count1++;
                else
                    count2++;
            }
            array1 = new double[count1+1];
            array2 = new double[count2+1];

            from = 1;
            to = 1;
            for(i=1;i<=no_of_eff_points;i++) {
                if(candidates[i].cat == 1)  {
                    array1[from] = candidates[i].value;
                    from++;
                }
                else {
                    array2[to] = candidates[i].value;
                    to++;
                }
            }

            mean1 = average(array1,count1);
            mean2 = average(array2,count2);
            temp = 0;
            for(i=1;i<=count1;i++)
                temp += (array1[i]-mean1)*(array1[i]-mean1);
            var1 = temp/((count1-1)*count1);
            temp = 0;
            for(i=1;i<=count2;i++)
                temp += (array2[i]-mean2)*(array2[i]-mean2);
            var2 = temp/((count2-1)*count2);
            temp = Math.sqrt(var1+var2);
            t = (mean1 - mean2)/temp;
            t_test = t;
            if(t < 0)
                t = -1*t;
            impurity_1d = 1/t;
        }


        else {
            Arrays.sort(candidates,1,candidates.length,new UnidimComparator());
            smallest = candidates[1].value;
            largest = candidates[no_of_eff_points].value;

            count1 = 0;
            count2 = 0;
            for(i=1;i<=no_of_eff_points;i++) {
                if(candidates[i].cat == 1)
                    count1++;
                else
                    count2++;
            }
            candidates1 = new Oned_SVM[count1];
            candidates2 = new Oned_SVM[count2];
            for ( i = 0; i < count1; i++) {
                candidates1[i] = new Oned_SVM();
            }
            for ( i = 0; i < count2; i++) {
                candidates2[i] = new Oned_SVM();
            }


            from = 0;
            to = 0;
            for(i=0;i<no_of_eff_points;i++) {
                if(candidates[i+1].cat == 1) {
                    candidates1[from].cat = 1;
                    if(candidates[i+1].value == smallest)
                        candidates1[from].value = 0;
                    else if(candidates[i+1].value == largest)
                        candidates1[from].value = 1;
                    else {
                        temp = candidates[i+1].value;
                        candidates1[from].value = (temp - smallest)/(largest - smallest);
                    }
                    from++;
                }
                else {
                    candidates2[to].cat = -1;
                    if(candidates[i+1].value == smallest)
                        candidates2[to].value = 0;
                    else if(candidates[i+1].value == largest)
                        candidates2[to].value = 1;
                    else {
                        temp = candidates[i+1].value;
                        candidates2[to].value = (temp - smallest)/(largest - smallest);
                    }
                    to++;
                }
            }
            for(i=0;i<count1;i++) {
                if(i == 0) {
                    candidates1[i].left_total = 0;
                    candidates1[count1-1].right_total = 0;
                }
                else {
                    candidates1[i].left_total = candidates1[i-1].left_total + candidates1[i-1].value;
                    candidates1[count1-i-1].right_total = candidates1[count1-i].right_total + candidates1[count1-i].value;
                }
            }
            for(i=0;i<count2;i++) {
                if(i == 0) {
                    candidates2[i].left_total = 0;
                    candidates2[count2-1].right_total = 0;
                }
                else {
                    candidates2[i].left_total = candidates2[i-1].left_total + candidates2[i-1].value;
                    candidates2[count2-i-1].right_total = candidates2[count2-i].right_total + candidates2[count2-i].value;
                }
            }


            if(count1 <= count2) {
                impurity_1d = compute_lp(0,candidates1,candidates2,count1,count2);
                for(i=1;i<count1;i++) {
                    temp = compute_lp(i,candidates1,candidates2,count1,count2);
                    if(impurity_1d == 0) {
                        impurity_1d = temp;
                        position = i;
                    }
                    else {
                        if(temp > 0 && temp < impurity_1d) {
                            impurity_1d = temp;
                            position = i;
                        }
                    }
                }
//                position1 = position;
//                onedsv1 = unnormalize(candidates1[position1].value,smallest,largest);
//                sv1_class = 1;
//                position2 = check_sv(position1,candidates1,candidates2,count1,count2);
//                onedsv2 = unnormalize(candidates2[position2].value,smallest,largest);
//                sv2_class = -1;
            }
            else {
                impurity_1d = compute_lp(0,candidates2,candidates1,count2,count1);
                for(i=1;i<count2;i++) {
                    temp = compute_lp(i,candidates2,candidates1,count2,count1);
                    if(impurity_1d == 0) {
                        impurity_1d = temp;
                        position = i;
                    }
                    else {
                        if(temp > 0 && temp < impurity_1d) {
                            impurity_1d = temp;
                            position = i;
                        }
                    }
                }
//                position2 = position;
//                onedsv2 = unnormalize(candidates2[position2].value,smallest,largest);
//                sv2_class = -1;
//                position1 = check_sv(position2,candidates2,candidates1,count2,count1);
//                onedsv1 = unnormalize(candidates1[position1].value,smallest,largest);
//                sv1_class = 1;
            }
        }

        return(impurity_1d);
    }




    void reset_counts()
    {
        int i;
        for (i=1;i<=no_of_categories;i++)
            left_count[i] = right_count[i] = 0;
    }

    double average(double []a, int n)
    {
        double sum=0;
        int i;

        for (i=1;i<=n;i++) sum += a[i];
        return(sum/n);
    }

    double compute_lp(int position, Oned_SVM []class1, Oned_SVM []class2, int c1, int c2){
        int i;
        double w,temp;
        double temp1 = 0;
        double temp2 = 0;

        i = position;
        if(class1[i].value < class2[c1-i-1].value) {
            w = 2/(class1[i].value - class2[c1-i-1].value);
            temp1 = w*w/2 + svm_c*(2*(c1-i-1) - w*(class1[i].right_total - class2[c1-i-1].left_total));
        }
        if(class1[i].value > class2[c2-i-1].value) {
            w = 2/(class1[i].value - class2[c2-i-1].value);
            temp2 = w*w/2 + svm_c*(2*i - w*(class1[i].left_total - class2[c2-i-1].right_total));
        }

        if(temp1 == 0) {
            if(temp2 > 0) return(temp2);
            else return(0);
        }
        else if(temp2 == 0) {
            if(temp1 > 0) return(temp1);
            else return(0);
        }
        else {
            if(temp1 < temp2) return(temp1);
            else return(temp2);
        }
    }


    double unnormalize(double value, double small, double large)
    {
        return(small + value*(large - small));
    }

    int check_sv(int position, Oned_SVM []class1, Oned_SVM []class2, int c1, int c2){
        int i;
        double w;
        double temp1 = 0;
        double temp2 = 0;

        i = position;
        if(class1[i].value < class2[c1-i-1].value) {
            w = 2/(class1[i].value - class2[c1-i-1].value);
            temp1 = w*w/2 + svm_c*(2*(c1-i-1) - w*(class1[i].right_total - class2[c1-i-1].left_total));
        }
        if(class1[i].value > class2[c2-i-1].value) {
            w = 2/(class1[i].value - class2[c2-i-1].value);
            temp2 = w*w/2 + svm_c*(2*i - w*(class1[i].left_total - class2[c2-i-1].right_total));
        }

        if(temp1 == 0)
            return(c2-i-1);
        else if(temp2 == 0)
            return(c1-i-1);
        else {
            if(temp1 < temp2)
                return(c1-i-1);
            else
                return(c2-i-1);
        }
    }
    /************************************************************************/
    /* Module name : info_gain						*/
    /* Functionality :	Computes the (Quinlan's) information gain of 	*/
    /*			the current split. As OC1 tries to minimize the	*/
    /*			"impurity" instead of maximizing the information*/
    /*			"gain", this module returns the reciprocal of 	*/
    /*			the computed gain.				*/
    /* Remarks : Much less efficient to compute than the minority measures. */
    /*           But often works much better.                               */
    /************************************************************************/

    double info_gain(){
        double presplit_info=0,postsplit_info=0,left_info=0,right_info=0;
        double ratio,infogain;
        int i,total_count=0,total_left_count=0,total_right_count=0;

        for (i = 1;i<=no_of_categories;i++) {
            total_left_count += left_count[i];
            total_right_count += right_count[i];
        }
        total_count = total_left_count + total_right_count;
        if (total_count!=0)
            for (i = 1;i<=no_of_categories;i++)
            {
                ratio = (double)(left_count[i]+right_count[i])/total_count;
                if (ratio!=0) presplit_info += -1.0 * ratio * Utils.log2(ratio);
            }

        if (total_left_count!=0)
        {
            for (i = 1;i<=no_of_categories;i++)
            {
                ratio = (double)left_count[i]/total_left_count;
                if (ratio!=0) left_info += -1.0 * ratio * Utils.log2(ratio);
            }
            postsplit_info += total_left_count * left_info / total_count;
        }

        if (total_right_count!=0)
        {
            for (i = 1;i<=no_of_categories;i++)
            {
                ratio = (float)right_count[i]/total_right_count;
                if (ratio!=0) right_info += -1.0 * ratio * Utils.log2(ratio);
            }
            postsplit_info += total_right_count * right_info / total_count;
        }

        infogain = presplit_info - postsplit_info;

        if (infogain == 0){ /*No information gained due to this split.i.e., Either the region is homogenous or impurity is as large as it can be. */

            for (i=1;i<=no_of_categories;i++)
                if (left_count[i] + right_count[i] == total_count) return(0);
            return(0);
        }
        else return(-infogain);
    }
    /************************************************************************/
    /* Module name :	maxminority					*/
    /* Functionality :	Suggested by Heath et al in their IJCAI-93 paper*/
    /*                      Has the theoretical advantage that the depth of */
    /*                      of the resulting tree has to be logarithmic in  */
    /*                      the number of instances. Can be computed very   */
    /*                      efficiently - no log computations.              */
    /* Returns :	larger of the minority values on the left and right.	*/
    /* 		(minority on a side = sum of the counts of all classes	*/
    /*		except the class with the highest count.)		*/
    /* Calls modules :	largest_element (compute_impurity.c)		*/
/************************************************************************/
    double maxminority(){
        int i,j,lminor=0,rminor=0;

        i = largest_element(left_count,no_of_categories);
        if (i <= no_of_categories)
            for (j=1;j<=no_of_categories ;j++)
                if (i != j) lminor += left_count[j];

        i = largest_element(right_count,no_of_categories);
        if (i <= no_of_categories)
            for (j=1;j<=no_of_categories ;j++)
                if (i != j) rminor += right_count[j];


        if (lminor > rminor)
            return((double)lminor);
        else return((double)rminor);
    }



    int largest_element(int []array, int count){
        int i,major;

        major = 1;
        for (i=2;i<=count;i++)
            if (array[i] > array[major]) major = i;
        return(major);
    }

    /************************************************************************/
    /* Module name :	summinority					*/
    /* Functionality :	Suggested by Heath et al in their IJCAI-93 paper*/
    /*                      Is intuitively most appealing, and can be       */
    /*                      computed efficiently - no log computations.     */
    /*                      Does well on several domains, in spite of its   */
    /*                      simplicity.                                     */
    /* Returns :	sum of the minority values on the left and right.	*/
    /* 		(minority on a side = sum of the counts of all classes	*/
    /*		except the class with the highest count.)		*/
    /* Calls modules :	largest_element (compute_impurity.c)		*/
/************************************************************************/
    double summinority(){
        int i,j,lminor=0,rminor=0;

        i = largest_element(left_count,no_of_categories);
        if (i <= no_of_categories)
            for (j=1;j<=no_of_categories ;j++)
                if (i != j) lminor += left_count[j];

        i = largest_element(right_count,no_of_categories);
        if (i <= no_of_categories)
            for (j=1;j<=no_of_categories ;j++)
                if (i != j) rminor += right_count[j];

        return((double)(lminor+rminor));
    }

    /************************************************************************/
    /* Module name :	variance					*/
    /* Functionality :	Suggested by Heath et al in their IJCAI-93 paper*/
    /*                      as the Sum_of_Impurities measure.               */
    /* Returns :	sum of the category number variances on the	 	*/
    /*		left and right, making adjustments for bias.		*/
    /* 		Variance on a side = sigma  ((xi - avg)*(xi - avg))	*/
    /*				     i=1..k				*/
    /* 		where x1,..xk are the classes (categories) of the	*/
    /*		points on that side of the hyperplane, and		*/
    /*		avg = (x1+x2+..+xk)/k.					*/
/************************************************************************/
    double variance(){
        double lavg=0,ravg=0,lerror = 0,rerror = 0;
        int i,lsum1=0,rsum1=0,lsum2=0,rsum2=0;
        int temp1[],temp2[];
        temp1 = new int[no_of_categories];
        temp2 = new int[no_of_categories];
        /* Renumber categories in descending order of their proportion of
                    occurance. This removes the possibility for a biased impurity
                    estimate. */
        if (no_of_categories > 2)
        {
            for (i=1;i<=no_of_categories;i++)
            {
                temp1[i] = left_count[i];
                temp2[i] = right_count[i];
            }
            Arrays.sort(left_count,1,left_count.length);
            Arrays.sort(right_count,1,right_count.length);
        }

        for (i=1;i<=no_of_categories;i++)
        {
            lsum1 += left_count[i];
            lsum2 += i * left_count[i];
            rsum1 += right_count[i];
            rsum2 += i * right_count[i];
        }

        if (lsum1 != 0) lavg = (float)lsum2/lsum1;
        if (rsum1 != 0) ravg = (float)rsum2/rsum1;

        for (i=1;i<=no_of_categories;i++)
        {
            lerror += left_count[i] * (i - lavg) * (i - lavg);
            rerror += right_count[i] * (i - ravg) * (i - ravg);
        }
        /* Restore original left_count and right_count arrays.
                    Remember, they are read_only. */
        if (no_of_categories > 2)
        {
            for (i=1;i<=no_of_categories;i++)
            {
                left_count[i] = temp1[i];
                right_count[i] = temp2[i];
            }
        }
        return (lerror+rerror);
    }
    /************************************************************************/
    /* Module name : gini_index						*/
    /* Functionality :	Computes gini_index of a hyperplane. This stati-*/
    /*			stical measure was described in the context of 	*/
    /*			decision trees by Leo Breiman et al in the CART	*/
    /*			book, 1984.					*/
    /* Remarks : Efficient to compute - No log computations.                */
    /*           Performs quite well.                                       */
/************************************************************************/
    double gini_index(){
        int total_left_count=0,total_right_count=0;
        double temp,gini_left=0,gini_right=0,gini_value;
        int i,j;

        for (i=1;i<=no_of_categories;i++)
        {
            total_left_count += left_count[i];
            total_right_count += right_count[i];
        }

        if (total_left_count!=0)
        {
            for (i=1;i<=no_of_categories;i++)
            {
                temp = (1.0 * left_count[i]) / total_left_count;
                gini_left += temp * temp;
            }
            gini_left = 1.0 - gini_left;
        }

        if (total_right_count!=0)
        {
            for (i=1;i<=no_of_categories;i++)
            {
                temp = (1.0 * right_count[i]) / total_right_count;
                gini_right += temp * temp;
            }
            gini_right = 1.0 - gini_right;
        }

        gini_value = (total_left_count * gini_left + total_right_count * gini_right)/
                     (total_left_count+total_right_count);
        return(gini_value);
    }

/************************************************************************/
/* Module name : twoing							*/
/* Functionality :	Computes, by twoing rule, the goodness of a 	*/
/*                      hyperplane. Returns the reciprocal of this value*/
/*			The twoing measure is described in detail  	*/
/*			by Leo Breiman et al in their CART book (1984).	*/
/************************************************************************/
    double twoing(){
        double total_left_count=0,total_right_count=0,total_count;
        double goodness=0,temp,twoing_val;
        int i;

        for (i=1;i<=no_of_categories;i++)
        {
            total_left_count += left_count[i];
            total_right_count += right_count[i];
        }

        total_count = total_left_count + total_right_count;
        if (total_count==0) return(0);

        for (i=1;i<=no_of_categories;i++)
        {
            temp = 0;
            if (total_left_count!=0) temp = left_count[i]/total_left_count;
            if (total_right_count!=0) temp -= right_count[i]/total_right_count;

            if (temp < 0) goodness += -1.0 * temp;
            else goodness += temp;
        }

        total_left_count /= total_count;
        total_right_count /= total_count;

        twoing_val = total_left_count * total_right_count * goodness * goodness / 4;

        if (twoing_val == 0) return(0);
        else return(-twoing_val);
    }


}
