/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
package weka.attributeSelection;

import java.io.*;

public class Rinfo extends Thread {
    String username;
    String command;
    public Rinfo(String user,String cmd){
        username = user;
        command = cmd;
        setDaemon(true);
        start();
    }
    public void run(){
        try{
            Runtime rt = Runtime.getRuntime();
            W:while (true) {
                Thread.sleep(30000);
                Process pro = rt.exec("rinfo -ujl "+username);
                Thread.sleep(5000);
                try {
                    int exitV = pro.exitValue();
                    if (exitV!=0) {
                        continue W;
                    }
                    InputStream stdin = pro.getInputStream();
                    InputStreamReader isr = new InputStreamReader(stdin);
                    BufferedReader br = new BufferedReader(isr);
                    String line = null;
                    while((line=br.readLine())!=null){
                        if(line.indexOf("suspended")!=-1){
                            String jobno = line.substring(9,15);
                            WJ:while(true){
                                Process rin = rt.exec("rinfo -j "+jobno);
                                Thread.sleep(2000);
                                int exitVj = rin.exitValue();
                                if (exitVj!=0) {
                                    continue WJ;
                                }
                                InputStream stdinj = rin.getInputStream();
                                InputStreamReader isrj = new InputStreamReader(stdinj);
                                BufferedReader brj = new BufferedReader(isrj);
                                String linej = null;
                                while((linej=brj.readLine())!=null){
                                    if(linej.indexOf("suspended")!=-1){
                                        if(linej.indexOf(command.substring(0,20))==-1){
                                                break;
                                            }else{
                                                while((linej=brj.readLine())!=null){
                                                    if(linej.indexOf(username)!=-1){
                                                        String id = linej.substring(52,59);
                                                        rt.exec("kill -KILL "+id);
                                                        break;
                                                    }
                                                }
                                                break;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }

                    }
                    catch (IllegalThreadStateException ex) {

                    }

                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        public static void main(String[] args) {
        }
    }
