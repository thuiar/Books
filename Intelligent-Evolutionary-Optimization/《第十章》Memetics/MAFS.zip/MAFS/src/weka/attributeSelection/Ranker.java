/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 *    Ranker.java
 *    Copyright (C) 1999 Mark Hall
 *
 */


package  weka.attributeSelection;

import  java.io.*;
import  java.util.*;
import  weka.core.*;
import weka.classifiers.*;
import weka.classifiers.lazy.IB1;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.Filter;
import weka.classifiers.functions.SMO;
import weka.classifiers.rules.ZeroR;

/**
 * Class for ranking the attributes evaluated by a AttributeEvaluator
 *
 * Valid options are: <p>
 *
 * -P <start set> <br>
 * Specify a starting set of attributes. Eg 1,4,7-9. <p>
 *
 * -T <threshold> <br>
 * Specify a threshold by which the AttributeSelection module can. <br>
 * discard attributes. <p>
 *
 * @author Mark Hall (mhall@cs.waikato.ac.nz)
 * @version $Revision: 1.20 $
 */
public class Ranker extends ASSearch
  implements RankedOutputSearch, StartSetHandler, OptionHandler {

  /** Holds the starting set as an array of attributes */
  private int[] m_starting;

  /** Holds the start set for the search as a range */
  private Range m_startRange;

  /** Holds the ordered list of attributes */
  private int[] m_attributeList;

  /** Holds the list of attribute merit scores */
  private double[] m_attributeMerit;

  /** Data has class attribute---if unsupervised evaluator then no class */
  private boolean m_hasClass;

  /** Class index of the data if supervised evaluator */
  private int m_classIndex;

  /** The number of attribtes */
  private int m_numAttribs;

  /**
   * A threshold by which to discard attributes---used by the
   * AttributeSelection module
   */
  private double m_threshold;

  /** The number of attributes to select. -1 indicates that all attributes
      are to be retained. Has precedence over m_threshold */
  private int m_numToSelect;

  /** Used to compute the number to select */
  private int m_calculatedNumToSelect;

  //==============added by zexuan================================
  private boolean m_optimizeFeatureNum;
  private Classifier m_classifier;
  private String m_classificationResults = "";
  private int m_folds;
  private Instances m_data;
  private double [][] ranking;

  private int m_fitnessType = 1;
  public static final int ER = 1;
  public static final int P = 2;
  public static final int R = 4;
  public static final int FM = 8;
  public static final int SVC = 16;
  public static final int JHB = 32;
  public static final int RMB = 64;
  public static final Tag [] TAGS_FITNESSTYPE = {
   new Tag(ER, "ErrorRate"),
   new Tag(P, "Precision"),
   new Tag(R, "Recall"),
   new Tag(FM, "FMeasure"),
   new Tag(SVC, "Support Vector Count (SMO)"),
   new Tag(JHB, "Jaakkola-Haussler Bound (SMO)"),
   new Tag(RMB, "Radius Margin Bound (SMO)")
  };


  //==============================================================


  /**
   * Returns a string describing this search method
   * @return a description of the search suitable for
   * displaying in the explorer/experimenter gui
   */
  public String globalInfo() {
    return "Ranker : \n\nRanks attributes by their individual evaluations. "
      +"Use in conjunction with attribute evaluators (ReliefF, GainRatio, "
      +"Entropy etc).\n";
  }

  /**
   * Constructor
   */
  public Ranker () {
    resetOptions();
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String numToSelectTipText() {
    return "Specify the number of attributes to retain. The default value "
      +"(-1) indicates that all attributes are to be retained. Use either "
      +"this option or a threshold to reduce the attribute set.";
  }

  /**
   * Specify the number of attributes to select from the ranked list. -1
   * indicates that all attributes are to be retained.
   * @param n the number of attributes to retain
   */
  public void setNumToSelect(int n) {
    m_numToSelect = n;
  }

  /**
   * Gets the number of attributes to be retained.
   * @return the number of attributes to retain
   */
  public int getNumToSelect() {
    return m_numToSelect;
  }

  /**
   * Gets the calculated number to select. This might be computed
   * from a threshold, or if < 0 is set as the number to select then
   * it is set to the number of attributes in the (transformed) data.
   * @return the calculated number of attributes to select
   */
  public int getCalculatedNumToSelect() {
    if (m_numToSelect >= 0 && !m_optimizeFeatureNum) {
      m_calculatedNumToSelect = m_numToSelect;
    }
    return m_calculatedNumToSelect;
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String thresholdTipText() {
    return "Set threshold by which attributes can be discarded. Default value "
      + "results in no attributes being discarded. Use either this option or "
      +"numToSelect to reduce the attribute set.";
  }

  /**
   * Set the threshold by which the AttributeSelection module can discard
   * attributes.
   * @param threshold the threshold.
   */
  public void setThreshold(double threshold) {
    m_threshold = threshold;
  }

  /**
   * Returns the threshold so that the AttributeSelection module can
   * discard attributes from the ranking.
   */
  public double getThreshold() {
    return m_threshold;
  }


  //===========added by zexuan=============================
  public boolean getOptimizeFeatureNum(){
    return m_optimizeFeatureNum;
  }

  public void setOptimizeFeatureNum(boolean b){
    m_optimizeFeatureNum = b;
  }

  public Classifier getClassifier () {
    return  m_classifier;
  }

  public void setClassifier (Classifier newClassifier) {
    m_classifier = newClassifier;
  }

  public int getFolds () {
    return  m_folds;
  }

  public void setFolds (int f) {
    m_folds = f;
  }

  public double [][] getRankedAttributes() throws Exception{
    return ranking;
  }
  public String getClassificationResutls(){
   return this.m_classificationResults;
  }

  public SelectedTag getFitnessType() {

    return new SelectedTag(m_fitnessType, TAGS_FITNESSTYPE);
  }

  public void setFitnessType(SelectedTag type) {

    if (type.getTags() == TAGS_FITNESSTYPE) {
      m_fitnessType = type.getSelectedTag().getID();
    }
  }

  //=======================================================


  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String generateRankingTipText() {
    return "A constant option. Ranker is only capable of generating "
      +" attribute rankings.";
  }

  /**
   * This is a dummy set method---Ranker is ONLY capable of producing
   * a ranked list of attributes for attribute evaluators.
   * @param doRank this parameter is N/A and is ignored
   */
  public void setGenerateRanking(boolean doRank) {

  }

  /**
   * This is a dummy method. Ranker can ONLY be used with attribute
   * evaluators and as such can only produce a ranked list of attributes
   * @return true all the time.
   */
  public boolean getGenerateRanking() {
    return true;
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String startSetTipText() {
    return "Specify a set of attributes to ignore. "
      +" When generating the ranking, Ranker will not evaluate the attributes "
      +" in this list. "
      +"This is specified as a comma "
      +"seperated list off attribute indexes starting at 1. It can include "
      +"ranges. Eg. 1,2,5-9,17.";
  }

  /**
   * Sets a starting set of attributes for the search. It is the
   * search method's responsibility to report this start set (if any)
   * in its toString() method.
   * @param startSet a string containing a list of attributes (and or ranges),
   * eg. 1,2,6,10-15.
   * @exception Exception if start set can't be set.
   */
  public void setStartSet (String startSet) throws Exception {
    m_startRange.setRanges(startSet);
  }

  /**
   * Returns a list of attributes (and or attribute ranges) as a String
   * @return a list of attributes (and or attribute ranges)
   */
  public String getStartSet () {
    return m_startRange.getRanges();
  }

  /**
   * Returns an enumeration describing the available options.
   * @return an enumeration of all the available options.
   **/
  public Enumeration listOptions () {
    Vector newVector = new Vector(12);

    newVector.addElement(new Option("\tclass name of base learner to use for"
                                    + "\n\taccuracy estimation. Place any"
                                    + "\n\tclassifier options LAST on the"
                                    + "\n\tcommand line following a \"--\"."
                                    , "B", 1, "-B <base learner>"));

    newVector.addElement(new Option("\tnumber of cross validation folds to "
                                    + "use\n\tfor estimating accuracy."
                                    + "\n\t(default=-1)", "F", 1, "-F <num>"));

    newVector
      .addElement(new Option("\tSpecify a starting set of attributes."
			     + "\n\tEg. 1,3,5-7."
			     +"\t\nAny starting attributes specified are"
			     +"\t\nignored during the ranking."
			     ,"P",1
			     , "-P <start set>"));
    newVector
      .addElement(new Option("\tSpecify a theshold by which attributes"
			     + "\tmay be discarded from the ranking.","T",1
			     , "-T <threshold>"));

    newVector
      .addElement(new Option("\tSpecify number of attributes to select"
			     ,"N",1
			     , "-N <num to select>"));
    newVector.addElement(new Option("\tSet optimization of feature num using classification."
                                    +"\n\t(default = false)"
                                    , "O",0, "-O"));

    newVector.addElement(new Option("\tSet Precision as Fitness","p", 0, "-p"));
    newVector.addElement(new Option("\tSet Recall as Fitness","r", 0, "-r"));
    newVector.addElement(new Option("\tSet FMeasure as Fitness","f", 0, "-f"));
    newVector.addElement(new Option("\tSet support vector count as Fitness","s", 0, "-s"));
    newVector.addElement(new Option("\tSet Jaakkola Haussler bound as Fitness","j", 0, "-j"));
    newVector.addElement(new Option("\tSet radius margin bound as Fitness","j", 0, "-j"));

    return newVector.elements();

  }

  /**
   * Parses a given list of options.
   *
   * Valid options are: <p>
   *
   * -P <start set> <br>
   * Specify a starting set of attributes. Eg 1,4,7-9. <p>
   *
   * -T <threshold> <br>
   * Specify a threshold by which the AttributeSelection module can <br>
   * discard attributes. <p>
   *
   * -N <number to retain> <br>
   * Specify the number of attributes to retain. Overides any threshold. <br>
   * <p>
   *
   * @param options the list of options as an array of strings
   * @exception Exception if an option is not supported
   *
   **/
  public void setOptions (String[] options)
    throws Exception {
    String optionString;
    resetOptions();

    optionString = Utils.getOption('B', options);

    if (optionString.length() == 0) {
      throw  new Exception("A learning scheme must be specified with"
                           + "-B option");
    }

    setClassifier(Classifier.forName(optionString,
                                     Utils.partitionOptions(options)));

    optionString = Utils.getOption('P', options);
    if (optionString.length() != 0) {
      setStartSet(optionString);
    }

    optionString = Utils.getOption('F', options);

    if (optionString.length() != 0) {
        setFolds(Integer.parseInt(optionString));
    }


    optionString = Utils.getOption('T', options);
    if (optionString.length() != 0) {
      Double temp;
      temp = Double.valueOf(optionString);
      setThreshold(temp.doubleValue());
    }

    optionString = Utils.getOption('N', options);
    if (optionString.length() != 0) {
      setNumToSelect(Integer.parseInt(optionString));
    }

    if (Utils.getFlag('p', options)) {
        setFitnessType(new SelectedTag(P, TAGS_FITNESSTYPE));
    } else if (Utils.getFlag('r', options)) {
        setFitnessType(new SelectedTag(R, TAGS_FITNESSTYPE));
    } else if (Utils.getFlag('f', options)){
        setFitnessType(new SelectedTag(FM, TAGS_FITNESSTYPE));
    }else if (Utils.getFlag('s', options)){
        setFitnessType(new SelectedTag(SVC, TAGS_FITNESSTYPE));
    }else if (Utils.getFlag('j', options)){
        setFitnessType(new SelectedTag(JHB, TAGS_FITNESSTYPE));
    }else if(Utils.getFlag('m', options)){
        setFitnessType(new SelectedTag(RMB, TAGS_FITNESSTYPE));
    }else{
        setFitnessType(new SelectedTag(ER, TAGS_FITNESSTYPE));
    }

    setOptimizeFeatureNum(Utils.getFlag('O',options));
  }

  /**
   * Gets the current settings of ReliefFAttributeEval.
   *
   * @return an array of strings suitable for passing to setOptions()
   */
  public String[] getOptions () {
    String[] classifierOptions = new String[0];

    if ((m_classifier != null) &&
        (m_classifier instanceof OptionHandler)) {
      classifierOptions = ((OptionHandler)m_classifier).getOptions();
    }

    String[] options = new String[13+classifierOptions.length];
    int current = 0;

    if (!(getStartSet().equals(""))) {
      options[current++] = "-P";
      options[current++] = ""+startSetToString();
    }

    options[current++] = "-F";
    options[current++] = "" + getFolds();

    options[current++] = "-T";
    options[current++] = "" + getThreshold();

    options[current++] = "-N";
    options[current++] = ""+getNumToSelect();
    if(getOptimizeFeatureNum()){
      options[current++] = "-O";
    }

    if (getClassifier() != null) {
      options[current++] = "-B";
      options[current++] = getClassifier().getClass().getName();
    }

    if (m_fitnessType == P) {
        options[current++] = "-p";
    } else if (m_fitnessType == R) {
        options[current++] = "-r";
    }else if(m_fitnessType == FM){
        options[current++] = "-f";
    }else if(m_fitnessType == SVC){
        options[current++] = "-s";
    }else if(m_fitnessType == JHB){
        options[current++] = "-j";
    }else if(m_fitnessType == RMB){
      options[current++] = "-m";
    }

    options[current++] = "--";
    System.arraycopy(classifierOptions, 0, options, current,
                     classifierOptions.length);
    current += classifierOptions.length;


    while (current < options.length) {
      options[current++] = "";
    }
    return  options;
  }

  /**
   * converts the array of starting attributes to a string. This is
   * used by getOptions to return the actual attributes specified
   * as the starting set. This is better than using m_startRanges.getRanges()
   * as the same start set can be specified in different ways from the
   * command line---eg 1,2,3 == 1-3. This is to ensure that stuff that
   * is stored in a database is comparable.
   * @return a comma seperated list of individual attribute numbers as a String
   */
  private String startSetToString() {
    StringBuffer FString = new StringBuffer();
    boolean didPrint;

    if (m_starting == null) {
      return getStartSet();
    }

    for (int i = 0; i < m_starting.length; i++) {
      didPrint = false;

      if ((m_hasClass == false) ||
	  (m_hasClass == true && i != m_classIndex)) {
	FString.append((m_starting[i] + 1));
	didPrint = true;
      }

      if (i == (m_starting.length - 1)) {
	FString.append("");
      }
      else {
	if (didPrint) {
	  FString.append(",");
	}
      }
    }

    return FString.toString();
  }

  /**
   * Kind of a dummy search algorithm. Calls a Attribute evaluator to
   * evaluate each attribute not included in the startSet and then sorts
   * them to produce a ranked list of attributes.
   *
   * @param ASEvaluator the attribute evaluator to guide the search
   * @param data the training instances.
   * @return an array (not necessarily ordered) of selected attribute indexes
   * @exception Exception if the search can't be completed
   */
  public int[] search (ASEvaluation ASEval, Instances data)
    throws Exception {
    int i, j;

    m_data = data;
    this.m_classificationResults = "";
    if (!(ASEval instanceof AttributeEvaluator)) {
      throw  new Exception(ASEval.getClass().getName()
			   + " is not a"
			   + "Attribute evaluator!");
    }

    if (ASEval instanceof AttributeTransformer) {
      data = ((AttributeTransformer)ASEval).transformedHeader();
    }

    m_numAttribs = data.numAttributes();

    if (ASEval instanceof UnsupervisedAttributeEvaluator) {
      m_hasClass = false;
    }
    else {
      m_hasClass = true;
      m_classIndex = data.classIndex();
    }


    m_startRange.setUpper(m_numAttribs - 1);
    if (!(getStartSet().equals(""))) {
      m_starting = m_startRange.getSelection();
    }

    int sl=0;
    if (m_starting != null) {
      sl = m_starting.length;
    }
    if ((m_starting != null) && (m_hasClass == true)) {
      // see if the supplied list contains the class index
      boolean ok = false;
      for (i = 0; i < sl; i++) {
	if (m_starting[i] == m_classIndex) {
	  ok = true;
	  break;
	}
      }

      if (ok == false) {
	sl++;
      }
    }
    else {
      if (m_hasClass == true) {
	sl++;
      }
    }


    m_attributeList = new int[m_numAttribs - sl];
    m_attributeMerit = new double[m_numAttribs - sl];

    // add in those attributes not in the starting (omit list)
    for (i = 0, j = 0; i < m_numAttribs; i++) {
      if (!inStarting(i)) {
	m_attributeList[j++] = i;
      }
    }

    AttributeEvaluator ASEvaluator = (AttributeEvaluator)ASEval;

    for (i = 0; i < m_attributeList.length; i++) {
      m_attributeMerit[i] = ASEvaluator.evaluateAttribute(m_attributeList[i]);
    }

    ranking = rankedAttributes();
    //int[] rankedAttributes = new int[m_attributeList.length];
    int[] rankedAttributes = new int[m_calculatedNumToSelect];
    //for (i = 0; i < m_attributeList.length; i++) {
    for (i = 0; i < m_calculatedNumToSelect; i++) {
      rankedAttributes[i] = (int)ranking[i][0];
    }
    return  rankedAttributes;
  }


  /**
   * Sorts the evaluated attribute list
   *
   * @return an array of sorted (highest eval to lowest) attribute indexes
   * @exception Exception of sorting can't be done.
   */
  public double[][] rankedAttributes ()
    throws Exception {
    int i, j;

    if (m_attributeList == null || m_attributeMerit == null) {
      throw  new Exception("Search must be performed before a ranked "
			   + "attribute list can be obtained");
    }

    int[] ranked = Utils.sort(m_attributeMerit);
    // reverse the order of the ranked indexes
    double[][] bestToWorst = new double[ranked.length][2];

    for (i = ranked.length - 1, j = 0; i >= 0; i--) {
      bestToWorst[j++][0] = ranked[i];
    }

    // convert the indexes to attribute indexes
    for (i = 0; i < bestToWorst.length; i++) {
      int temp = ((int)bestToWorst[i][0]);
      bestToWorst[i][0] = m_attributeList[temp];
      bestToWorst[i][1] = m_attributeMerit[temp];
    }

    //===========modifed by zexuan=============================
    if (m_optimizeFeatureNum){
      optimizeFeatureNum(bestToWorst);
    }else if (m_numToSelect > bestToWorst.length) {
      throw new Exception("More attributes requested than exist in the data");
    }else if (m_numToSelect <= 0) {
      if (m_threshold == -Double.MAX_VALUE) {
	m_calculatedNumToSelect = bestToWorst.length;
      } else {
	determineNumToSelectFromThreshold(bestToWorst);
      }
    }else{
        m_calculatedNumToSelect = m_numToSelect;
    }
    //=======================================================================
    /*    if (m_numToSelect > 0) {
      determineThreshFromNumToSelect(bestToWorst);
      } */

    return  bestToWorst;
  }
  //=====================added by zexuan================================
  private void optimizeFeatureNum(double [][]ranking)throws Exception{
   double fitness = Double.MAX_VALUE;
   Instances datacopy;
   Remove delTransform = new Remove();
   delTransform.setInvertSelection(true);
   Evaluation ev;
   int maxNumToSelection = ranking.length;
   if(m_numToSelect!=-1){
     maxNumToSelection = ranking.length > m_numToSelect ? m_numToSelect : ranking.length;
   }
   for(int i=0;i<maxNumToSelection;i++){

     datacopy = new Instances(m_data);
     int[] featArray = new int[i+2];
     int j = 0;
     for (; j < i+1; j++) {
       featArray[j] = (int)ranking[j][0];
     }
     featArray[j] = m_data.classIndex();
     delTransform.setAttributeIndicesArray(featArray);
     delTransform.setInputFormat(datacopy);
     datacopy = Filter.useFilter(datacopy, delTransform);
     double error = 1.0;
     if(m_fitnessType == ER || m_fitnessType == R || m_fitnessType == P || m_fitnessType == FM){
       ev = new Evaluation(datacopy);
       int fold = m_folds;
       if (m_folds == -1) {
         fold = m_data.numInstances();
       }
       ev.crossValidateModel(m_classifier, datacopy, fold, new Random());
       if(m_fitnessType == ER){
           error = ev.errorRate();
       }else if(m_fitnessType == R){
           error = ev.recall(1);
         }else if(m_fitnessType == P){
           error = ev.precision(1);
         }else{
           error = ev.fMeasure(1);
         }
     }
     if(m_fitnessType == SVC || m_fitnessType==JHB || m_fitnessType == RMB){
       if(m_classifier instanceof SMO){
            m_classifier.buildClassifier(datacopy);
            if(m_fitnessType == SVC){
              SMO smo = (SMO)m_classifier;
              error = smo.getSupportVectorCount();
            }else if(m_fitnessType == JHB){
              SMO smo = (SMO)m_classifier;
              error = smo.getJaakkolaHausslerBound();
            }else{
              SMO smo = (SMO)m_classifier;
              error = smo.getRadiusMarginBound();
           }
        }else{
            throw new Exception("Fitness type apply only to support vector machine(SMO)");
        }
     }
     if (error < fitness) {
         fitness = error;
         m_calculatedNumToSelect = i + 1;
       }

     System.out.println(ranking[i][0]);
     m_classificationResults += "Selected number: "+(i+1)+"\tFitness:"+fitness+"\n";
     System.out.println("Selected number: "+(i+1)+"\tFitness:"+fitness);
   }
  }
  //====================================================================
  private void determineNumToSelectFromThreshold(double [][] ranking) {
    int count = 0;
    for (int i = 0; i < ranking.length; i++) {
      if (ranking[i][1] > m_threshold) {
	count++;
      }
    }
    m_calculatedNumToSelect = count;
  }

  private void determineThreshFromNumToSelect(double [][] ranking)
    throws Exception {
    if (m_numToSelect > ranking.length) {
      throw new Exception("More attributes requested than exist in the data");
    }

    if (m_numToSelect == ranking.length) {
      return;
    }

    m_threshold = (ranking[m_numToSelect-1][1] +
		   ranking[m_numToSelect][1]) / 2.0;
  }

  /**
   * returns a description of the search as a String
   * @return a description of the search
   */
  public String toString () {
    StringBuffer BfString = new StringBuffer();
    BfString.append("\tAttribute ranking.\n");

    if (m_starting != null) {
      BfString.append("\tIgnored attributes: ");

      BfString.append(startSetToString());
      BfString.append("\n");
    }

    if (m_threshold != -Double.MAX_VALUE) {
      BfString.append("\tThreshold for discarding attributes: "
		      + Utils.doubleToString(m_threshold,8,4)+"\n");
    }

    return BfString.toString();
  }


  /**
   * Resets stuff to default values
   */
  protected void resetOptions () {
    m_starting = null;
    m_startRange = new Range();
    m_attributeList = null;
    m_attributeMerit = null;
    m_threshold = -Double.MAX_VALUE;
    m_optimizeFeatureNum = false;
    m_classifier = new ZeroR();
    m_folds = -1;
    m_classificationResults = "";
    m_numToSelect = -1;
    m_calculatedNumToSelect = -1;
  }


  private boolean inStarting (int feat) {
    // omit the class from the evaluation
    if ((m_hasClass == true) && (feat == m_classIndex)) {
      return  true;
    }

    if (m_starting == null) {
      return  false;
    }

    for (int i = 0; i < m_starting.length; i++) {
      if (m_starting[i] == feat) {
	return  true;
      }
    }

    return  false;
  }

  public static void main(String [] args) throws Exception{
    File selected = new File("vehicle.arff");
    FileReader fr = new FileReader(selected);
    Instances instances = new Instances(fr);
    instances.setClassIndex(instances.numAttributes()-1);
    Random r = new Random();
    Evaluation ev = new Evaluation(instances);
    IB1 ib1 = new IB1();
    ev.crossValidateModel(ib1,instances,instances.numInstances(),r);
    //ev.crossValidateModel(ib1,instances,3,r);
    System.out.println(ev.errorRate());
  }

}

