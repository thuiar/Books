/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 *    AttributeSelection.java
 *    Copyright (C) 1999 Mark Hall
 *
 */

package  weka.attributeSelection;

import java.beans.*;
import java.io.*;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Random;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.core.*;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;
import weka.classifiers.meta.MultiClassClassifier;
import weka.classifiers.meta.Vote;
import java.util.BitSet;


/**
 * Attribute selection class. Takes the name of a search class and
 * an evaluation class on the command line. <p>
 *
 * Valid options are: <p>
 *
 * -h <br>
 * Display help. <p>
 *
 * -I <name of input file> <br>
 * Specify the training arff file. <p>
 *
 * -C <class index> <br>
 * The index of the attribute to use as the class. <p>
 *
 * -S <search method> <br>
 * The full class name of the search method followed by search method options
 * (if any).<br>
 * Eg. -S "weka.attributeSelection.BestFirst -N 10" <p>
 *
 * -X <number of folds> <br>
 * Perform a cross validation. <p>
 *
 * -N <random number seed> <br>
 * Specify a random number seed. Use in conjuction with -X. (Default = 1). <p>
 *
 * ------------------------------------------------------------------------ <p>
 *
 * Example usage as the main of an attribute evaluator (called FunkyEvaluator):
 * <code> <pre>
 * public static void main(String [] args) {
 *   try {
 *     ASEvaluator eval = new FunkyEvaluator();
 *     System.out.println(SelectAttributes(Evaluator, args));
 *   } catch (Exception e) {
 *     System.err.println(e.getMessage());
 *   }
 * }
 * </code> </pre>
 * <p>
 *
 * ------------------------------------------------------------------------ <p>
 *
 * @author   Mark Hall (mhall@cs.waikato.ac.nz)
 * @version  $Revision: 1.31 $
 */
public class AttributeSelection implements Serializable {

  /** the instances to select attributes from */
  private Instances m_trainInstances;

  /** the attribute/subset evaluator */
  private ASEvaluation m_ASEvaluator;

  /** the search method */
  private ASSearch m_searchMethod;

  /** the number of folds to use for cross validation */
  private int m_numFolds;

  /** holds a string describing the results of the attribute selection */
  private StringBuffer m_selectionResults;
  private StringBuffer m_rankedResults;
  /** rank features (if allowed by the search method) */
  private boolean m_doRank;

  /** do cross validation */
  private boolean m_doXval;

  /** seed used to randomly shuffle instances for cross validation */
  private int m_seed;

  /** cutoff value by which to select attributes for ranked results */
  private double m_threshold;

  /** number of attributes requested from ranked results */
  private int m_numToSelect;

  /** the selected attributes */
  private int [] m_selectedAttributeSet;

  /** the attribute indexes and associated merits if a ranking is produced */
  private double [][] m_attributeRanking;

  /** if a feature selection run involves an attribute transformer */
  private AttributeTransformer m_transformer = null;

  /** the attribute filter for processing instances with respect to
      the most recent feature selection run */
  private Remove m_attributeFilter = null;

  /** hold statistics for repeated feature selection, such as
      under cross validation */
  private double [][] m_rankResults = null;
  private double [] m_subsetResults = null;
  private int m_trials = 0;

  ///////////////////////added by zexuan//////////////////////
  private StringBuffer splitResults = new StringBuffer();
  private int fold = 0;
  private double testingError[][];
  private double nsga2TestingError[];
  private double numFeatures[][];
  private double rci[][];
  private double nsga2NumFeatures[];
  private int[] attributeSet;
  public double averageError[], averageNumFeature[], averageRCI[];
  public int numStr = NSGAII.ALL;
  public String[] strName;
  public ASEvaluation getASEvaluator(){
    return m_ASEvaluator;
  }
  /////////////////////////////////////////////////////////////////

  /**
   * Return the number of attributes selected from the most recent
   * run of attribute selection
   * @return the number of attributes selected
   */
  public int numberAttributesSelected() throws Exception {
    int [] att = selectedAttributes();
    return att.length-1;
  }

  /**
   * get the final selected set of attributes.
   * @return an array of attribute indexes
   * @exception Exception if attribute selection has not been performed yet
   */
  public int [] selectedAttributes () throws Exception {
    if (m_selectedAttributeSet == null) {
      throw new Exception("Attribute selection has not been performed yet!");
    }
    return m_selectedAttributeSet;
  }

  /**
   * get the final ranking of the attributes.
   * @return a two dimensional array of ranked attribute indexes and their
   * associated merit scores as doubles.
   * @exception Exception if a ranking has not been produced
   */
  public double [][] rankedAttributes () throws Exception {
    if (m_attributeRanking == null) {
      throw new Exception("Ranking has not been performed");
    }
    return m_attributeRanking;
  }

  /**
   * set the attribute/subset evaluator
   * @param evaluator the evaluator to use
   */
  public void setEvaluator (ASEvaluation evaluator) {
    m_ASEvaluator = evaluator;
  }

  /**
   * set the search method
   * @param search the search method to use
   */
  public void setSearch (ASSearch search) {
    m_searchMethod = search;

    if (m_searchMethod instanceof RankedOutputSearch) {
      setRanking(((RankedOutputSearch)m_searchMethod).getGenerateRanking());
    }
  }

  /**
   * set the number of folds for cross validation
   * @param folds the number of folds
   */
  public void setFolds (int folds) {
    m_numFolds = folds;
    testingError = new double[numStr][folds];
    numFeatures = new double[numStr][folds];
    nsga2TestingError = new double[folds];
    nsga2NumFeatures = new double[folds];
    rci = new double[numStr][folds];
  }

  /**
   * produce a ranking (if possible with the set search and evaluator)
   * @param r true if a ranking is to be produced
   */
  public void setRanking (boolean r) {
    m_doRank = r;
  }

  /**
   * do a cross validation
   * @param x true if a cross validation is to be performed
   */
  public void setXval (boolean x) {
    m_doXval = x;
  }

  /**
   * set the seed for use in cross validation
   * @param s the seed
   */
  public void setSeed (int s) {
    m_seed = s;
  }

  /**
   * set the threshold by which to select features from a ranked list
   * @param t the threshold
   */
  public void setThreshold (double t) {
    m_threshold = t;
  }

  /**
   * get a description of the attribute selection
   * @return a String describing the results of attribute selection
   */
  public String toResultsString() {
    return m_selectionResults.toString();
  }

  public String toRankedString(){
      return m_rankedResults.toString();
  }

  /**
   * reduce the dimensionality of a set of instances to include only those
   * attributes chosen by the last run of attribute selection.
   * @param in the instances to be reduced
   * @return a dimensionality reduced set of instances
   * @exception Exception if the instances can't be reduced
   */
  public Instances reduceDimensionality(Instances in) throws Exception {
    if (m_attributeFilter == null) {
      throw new Exception("No feature selection has been performed yet!");
    }

    if (m_transformer != null) {
      Instances transformed = new Instances(m_transformer.transformedHeader(),
					    in.numInstances());
      for (int i=0;i<in.numInstances();i++) {
	transformed.add(m_transformer.convertInstance(in.instance(i)));
      }
      return Filter.useFilter(transformed, m_attributeFilter);
    }

    return Filter.useFilter(in, m_attributeFilter);
  }

  /**
   * reduce the dimensionality of a single instance to include only those
   * attributes chosen by the last run of attribute selection.
   * @param in the instance to be reduced
   * @return a dimensionality reduced instance
   * @exception Exception if the instance can't be reduced
   */
  public Instance reduceDimensionality(Instance in) throws Exception {
    if (m_attributeFilter == null) {
      throw new Exception("No feature selection has been performed yet!");
    }
    if (m_transformer != null) {
      in = m_transformer.convertInstance(in);
    }
    m_attributeFilter.input(in);
    m_attributeFilter.batchFinished();
    Instance result = m_attributeFilter.output();
    return result;
  }

  /**
   * constructor. Sets defaults for each member varaible. Default
   * attribute evaluator is CfsSubsetEval; default search method is
   * BestFirst.
   */
  public AttributeSelection () {
    setFolds(10);
    setRanking(false);
    setXval(false);
    setSeed(1);
    //    m_threshold = -Double.MAX_VALUE;
    setEvaluator(new CfsSubsetEval());
    setSearch(new ForwardSelection());
    m_selectionResults = new StringBuffer();
    m_rankedResults = new StringBuffer();
    m_selectedAttributeSet = null;
    m_attributeRanking = null;
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

  /**
   * Perform attribute selection with a particular evaluator and
   * a set of options specifying search method and input file etc.
   *
   * @param ASEvaluator an evaluator object
   * @param options an array of options, not only for the evaluator
   * but also the search method (if any) and an input data file
   * @return the results of attribute selection as a String
   * @exception Exception if no training file is set
   */
  public static String SelectAttributes (ASEvaluation ASEvaluator,
					 String[] options)
    throws Exception {
    String trainFileName, searchName;
    Instances train = null;
    ASSearch searchMethod = null;

    try {
      // get basic options (options the same for all attribute selectors
      trainFileName = Utils.getOption('I', options);

      if (trainFileName.length() == 0) {
        searchName = Utils.getOption('S', options);

        if (searchName.length() != 0) {
          searchMethod = (ASSearch)Class.forName(searchName).newInstance();
        }

        throw  new Exception("No training file given.");
      }
    }
    catch (Exception e) {
      throw  new Exception('\n' + e.getMessage()
			   + makeOptionString(ASEvaluator, searchMethod));
    }

    train = new Instances(new FileReader(trainFileName));
    return  SelectAttributes(ASEvaluator, options, train);
  }

  /**
   * returns a string summarizing the results of repeated attribute
   * selection runs on splits of a dataset.
   * @return a summary of attribute selection results
   * @exception Exception if no attribute selection has been performed.
   */
  public String splitResultsString () throws Exception {
    StringBuffer CvString = new StringBuffer();

    if ((m_subsetResults == null && m_rankResults == null) ||
	( m_trainInstances == null)) {
      throw new Exception("Attribute selection has not been performed yet!");
    }

    int fieldWidth = (int)(Math.log(m_trainInstances.numAttributes()) +1.0);

    CvString.append("\n\n=== Attribute selection " + m_numFolds
		    + " fold cross-validation/replicates bootstrap/replicates percentage split ");

    if (!(m_ASEvaluator instanceof UnsupervisedSubsetEvaluator) &&
	!(m_ASEvaluator instanceof UnsupervisedAttributeEvaluator) &&
	(m_trainInstances.classAttribute().isNominal())) {
	CvString.append("(stratified), seed: ");
	CvString.append(m_seed+" ===\n\n");
    }
    else {
      CvString.append("seed: "+m_seed+" ===\n\n");
    }

    if ((m_searchMethod instanceof RankedOutputSearch) && (m_doRank == true)) {
      CvString.append("average merit      average rank  attribute\n");

      // calcualte means and std devs
      for (int i = 0; i < m_rankResults[0].length; i++) {
	m_rankResults[0][i] /= m_numFolds; // mean merit
	double var = m_rankResults[0][i]*m_rankResults[0][i]*m_numFolds;
	var = (m_rankResults[2][i] - var);
	var /= m_numFolds;

	if (var <= 0.0) {
	  var = 0.0;
	  m_rankResults[2][i] = 0;
	}
	else {
	  m_rankResults[2][i] = Math.sqrt(var);
	}

	m_rankResults[1][i] /= m_numFolds; // mean rank
	var = m_rankResults[1][i]*m_rankResults[1][i]*m_numFolds;
	var = (m_rankResults[3][i] - var);
	var /= m_numFolds;

	if (var <= 0.0) {
	  var = 0.0;
	  m_rankResults[3][i] = 0;
	}
	else {
	  m_rankResults[3][i] = Math.sqrt(var);
	}
      }

      // now sort them by mean rank
      int[] s = Utils.sort(m_rankResults[1]);
      for (int i=0; i<s.length; i++) {
	if (m_rankResults[1][s[i]] > 0) {
	  CvString.append(Utils.doubleToString(Math.
					       abs(m_rankResults[0][s[i]]),
					       6, 3)
			  + " +-"
			  + Utils.doubleToString(m_rankResults[2][s[i]], 6, 3)
			  + "   "
			  + Utils.doubleToString(m_rankResults[1][s[i]],
						 fieldWidth+2, 1)
			  + " +-"
			  + Utils.doubleToString(m_rankResults[3][s[i]], 5, 2)
			+"  "
			  + Utils.doubleToString(((double)(s[i] + 1)),
						 fieldWidth, 0)
			  + " "
			  + m_trainInstances.attribute(s[i]).name()
			  + "\n");
	}
      }
    }
    else {
      CvString.append("number of folds (%)  attribute\n");

      for (int i = 0; i < m_subsetResults.length; i++) {
	if ((m_ASEvaluator instanceof UnsupervisedSubsetEvaluator) ||
	    (i != m_trainInstances.classIndex())) {
	  CvString.append(Utils.doubleToString(m_subsetResults[i], 12, 0)
			  + "("
			  + Utils.doubleToString((m_subsetResults[i] /
						  m_numFolds * 100.0)
						 , 3, 0)
			  + " %)  "
			  + Utils.doubleToString(((double)(i + 1)),
						 fieldWidth, 0)
			  + " "
			  + m_trainInstances.attribute(i).name()
			  + "\n");
	}
      }
    }
    //////////////modified by zexuan////////////////////////
    averageError = new double[strName.length];
    averageNumFeature  = new double[strName.length];
    averageRCI = new double[strName.length];
    String tmp = CvString.toString()+"\n"+splitResults.toString();
    for (int i = 0; i < strName.length; i++) {
        averageError[i] = Utils.mean(testingError[i]);
        averageNumFeature[i] = Utils.mean(numFeatures[i]);
        averageRCI[i] = Utils.mean(rci[i]);
        tmp = tmp+"\nAverage "+strName[i]+" testing error: "+averageError[i]+" +/- "+Math.sqrt(Utils.variance(testingError[i]))+
                     "\nAverage "+strName[i]+" Features Selected: "+averageNumFeature[i]+" +/- "+Math.sqrt(Utils.variance(numFeatures[i]))+
                     "\nAverage "+strName[i]+" RCI: "+averageRCI[i]+" =/- "+Math.sqrt(Utils.variance(rci[i]));

    }


//    if(m_searchMethod instanceof NSGAII){
//        if(((NSGAII)m_searchMethod).m_multiClass>0){
//            averageError = Utils.mean(nsga2TestingError);
//            averageNumFeature = Utils.mean(nsga2NumFeatures);
//            tmp = tmp+"\nAverage Meta-feature multiclass testing error: "+averageError+" +/- "+Math.sqrt(Utils.variance(nsga2TestingError))+
//            "\nAverage Meta-feature multiclass Features Selected: "+averageNumFeature+" +/- "+Math.sqrt(Utils.variance(nsga2NumFeatures));
//        }
//    }

    return tmp;

    ////////////////////////////////////////////////////////
  }

  /**
   * Select attributes for a split of the data. Calling this function
   * updates the statistics on attribute selection. CVResultsString()
   * returns a string summarizing the results of repeated calls to
   * this function. Assumes that splits are from the same dataset---
   * ie. have the same number and types of attributes as previous
   * splits.
   *
   * @param split the instances to select attributes from
   * @exception Exception if an error occurs
   */
  public void selectAttributesSplit(Instances split) throws Exception {
    double[][] attributeRanking = null;

    // if the train instances are null then set equal to this split.
    // If this is the case then this function is more than likely being
    // called from outside this class in order to obtain CV statistics
    // and all we need m_trainIstances for is to get at attribute names
    // and types etc.
    File tempFile = null;
    if (m_trainInstances == null) {
      m_trainInstances = split;

      ////////////added by zexuan////////////////////////////////
      //tempFile = new File("temp.arff");
      //saveInstancesToFile(tempFile,m_trainInstances);
      ///////////////////////////////////////////////////
    }

    // create space to hold statistics
    if (m_rankResults == null && m_subsetResults == null) {
      m_subsetResults = new double[split.numAttributes()];
      m_rankResults = new double[4][split.numAttributes()];
    }

    m_ASEvaluator.buildEvaluator(split);
    // Do the search
    attributeSet = m_searchMethod.search(m_ASEvaluator,split);

    String selectedAttributes = "";
    for (int i = 0; i < attributeSet.length; i++) {
      selectedAttributes += (attributeSet[i]+1)+" ";
    }
//////////////////////added by zexuan////////////////////////////
    splitResults.append("===============fold/replicates "+(++fold)+"===============\n"
                        +m_searchMethod.toString()+"\nSelected features: "
                        +selectedAttributes+"\n"+"Number of selected features: "+attributeSet.length+"\n");
////////////////////////////////////////////////////////////////////

    // Do any postprocessing that a attribute selection method might
    // require
    attributeSet = m_ASEvaluator.postProcess(attributeSet);

    if ((m_searchMethod instanceof RankedOutputSearch) &&
	(m_doRank == true)) {
      attributeRanking = ((RankedOutputSearch)m_searchMethod).getRankedAttributes();

      // System.out.println(attributeRanking[0][1]);
      for (int j = 0; j < attributeRanking.length; j++) {
	// merit
	m_rankResults[0][(int)attributeRanking[j][0]] +=
	  attributeRanking[j][1];
	// squared merit
	m_rankResults[2][(int)attributeRanking[j][0]] +=
	  (attributeRanking[j][1]*attributeRanking[j][1]);
	// rank
	m_rankResults[1][(int)attributeRanking[j][0]] += (j + 1);
	// squared rank
	m_rankResults[3][(int)attributeRanking[j][0]] += (j + 1)*(j + 1);
	// += (attributeRanking[j][0] * attributeRanking[j][0]);
      }
      if(m_searchMethod instanceof Ranker){
        this.splitResults.append(((Ranker)m_searchMethod).getClassificationResutls());
      }

    } else {
      for (int j = 0; j < attributeSet.length; j++) {
	m_subsetResults[attributeSet[j]]++;
      }
    }

    /////////////////added by zexuan//////////////////////
//    if(tempFile != null){
//        tempFile.delete();
//    }
    /////////////////////////////////////////////////////

    m_trials++;
  }
///////////////////////////////////added by zexuan//////////////////////////////
  public void selectedAttributesTestSplit(Instances instCopy, Instances instTest,Classifier classifier,int testmode)throws Exception{

 //   boolean ori = false;
//      if(classifier instanceof MultiClassClassifier){
//        MultiClassClassifier mc = (MultiClassClassifier)classifier;
//        Classifier cc = mc.getClassifier();
//        if(cc instanceof SMO){
//            ori = ((SMO)cc).getBuildLogisticModels();
//            ((SMO)cc).setBuildLogisticModels(true);
//        }
//        if(cc instanceof LibSVM){
//            ori = ((LibSVM)cc).getPredictProbability();
//            ((LibSVM)cc).setPredictProbability(true);
//        }
//
//    }
    if(m_searchMethod instanceof NSGAII){
        NSGAII nsga2 = (NSGAII)m_searchMethod;
        if(nsga2.m_multiClass>0){//NSGAII multiclass
            int[][] bestAtts = nsga2.bestAttributesMulticlass;
            //int[][] bestAtts = nsga2.bestAttributes;
            splitResults.append("#=======================================================#\n");
            double numf[];
            Classifier[] vc;
            Evaluation evaluation [];
            Instances testCopy = new Instances(instTest);
            Instances trainCopy = new Instances(instCopy);
            Instances conTest,conTrain;
            if(nsga2.m_ensembleStrategy == NSGAII.OFO){
                vc =  new Classifier[]{Classifier.makeCopy(classifier)};
                strName = new String[]{"OFO"};
                numf = new double[]{0};
                ((MultiClassClassifier)vc[0]).m_metaFeature = true;
                ((MultiClassClassifier)vc[0]).setBestAtts(bestAtts);
                for (int i = 0; i < bestAtts.length; i++) {
                    numf[0] += bestAtts[i].length;
                }
                numf[0] /= bestAtts.length;

                evaluation = new Evaluation[]{new Evaluation(trainCopy)};
                vc[0].buildClassifier(trainCopy);
                evalationCVB(testmode,evaluation[0],vc[0],trainCopy,testCopy,0,numf[0]);
            }else if(nsga2.m_ensembleStrategy == NSGAII.ENSEMBLE){
                vc = new Classifier[]{new Vote()};
                strName = new String[]{"Ensemble"};
                numf = new double[]{0};
                for (int i = 0; i < bestAtts.length; i++) {
                    numf[0] += bestAtts[i].length;
                    if (i == 0) {
                        ((Vote)vc[0]).firstClassifier(Classifier.makeCopy(classifier));
                    } else {
                        Classifier tmp = Classifier.makeCopy(classifier);
                        ((Vote)vc[0]).addClassifier(tmp);
                    }
                }
                numf[0] /= bestAtts.length;
                ((Vote)vc[0]).m_metaFeature = true;
                ((Vote)vc[0]).setBestAtts(bestAtts);

                evaluation = new Evaluation[]{new Evaluation(trainCopy)};
                vc[0].buildClassifier(trainCopy);
                evalationCVB(testmode,evaluation[0],vc[0],trainCopy,testCopy,0,numf[0]);
            }else if(nsga2.m_ensembleStrategy == NSGAII.CONJUNCTION){
                numf = new double[]{0};
                strName = new String[]{"Conjunction"};
                conTest = filter(testCopy,nsga2.outputSolution.m_chromosome);
                conTrain = filter(trainCopy,nsga2.outputSolution.m_chromosome);
                numf[0] = nsga2.outputSolution.m_chromosome.cardinality();
                vc = new Classifier[]{Classifier.makeCopy(classifier)};

                evaluation = new Evaluation[]{new Evaluation(conTrain)};
                vc[0].buildClassifier(conTrain);
                evalationCVB(testmode,evaluation[0],vc[0],conTrain,conTest,0,numf[0]);
            }else{//all strategies
                vc = new Classifier[]{Classifier.makeCopy(classifier),new Vote(),Classifier.makeCopy(classifier)};
                evaluation = new Evaluation[numStr];
                strName = new String[numStr];
                numf = new double[3];
                ((MultiClassClassifier)vc[0]).m_metaFeature = true;
                ((MultiClassClassifier)vc[0]).setBestAtts(bestAtts);
                for (int i = 0; i < bestAtts.length; i++) {
                    numf[0] += bestAtts[i].length;
                }
                numf[0] /= bestAtts.length;
                evaluation[0] = new Evaluation(trainCopy);
                vc[0].buildClassifier(trainCopy);
                strName[0] = "OFO";
                evalationCVB(testmode,evaluation[0],vc[0],trainCopy,testCopy,0,numf[0]);



                for (int i = 0; i < bestAtts.length; i++) {
                    numf[1] += bestAtts[i].length;
                    if (i == 0) {
                        ((Vote)vc[1]).firstClassifier(Classifier.makeCopy(classifier));
                    } else {
                        Classifier tmp = Classifier.makeCopy(classifier);
                        ((Vote)vc[1]).addClassifier(tmp);
                    }
                }
                numf[1] /= bestAtts.length;
                ((Vote)vc[1]).m_metaFeature = true;
                ((Vote)vc[1]).setBestAtts(bestAtts);
                evaluation[1] = new Evaluation(trainCopy);
                vc[1].buildClassifier(trainCopy);
                strName[1] = "Ensemble";
                evalationCVB(testmode,evaluation[1],vc[1],trainCopy,testCopy,1,numf[1]);


                conTest = filter(testCopy,nsga2.outputSolution.m_chromosome);
                conTrain = filter(trainCopy,nsga2.outputSolution.m_chromosome);
                numf[2] = nsga2.outputSolution.m_chromosome.cardinality();
                evaluation[2] = new Evaluation(conTrain);
                vc[2].buildClassifier(conTrain);
                strName[2] = "Conjunction";
                evalationCVB(testmode,evaluation[2],vc[2],conTrain,conTest,2,numf[2]);

            }
            //Classifier classifier = wrapper.getClassifier();
            splitResults.append("#=======================================================#\n");
        }else{//NSGAII no multiclass
            int[][] bestAtts = nsga2.bestAttributes;
            strName = new String[bestAtts.length];
            splitResults.append("#=======================================================#\n");
            for (int i = 0; i < bestAtts.length && bestAtts[i] != null; i++) {
                Remove delTransform = new Remove();
                strName[i] = "The " + (i + 1) + " best solution (" + bestAtts[i].length + "f)";
                delTransform.setInvertSelection(true);
                //WrapperSubsetEval wrapper = (WrapperSubsetEval)getASEvaluator();
                // copy the instances
                Instances testCopy = new Instances(instTest);
                Instances trainCopy = new Instances(instCopy);
                // set up an array of attribute indexes for the filter (+1 for the class)
                int[] featArray = new int[bestAtts[i].length + 1];

                System.arraycopy(bestAtts[i], 0, featArray, 0, bestAtts[i].length);

                featArray[bestAtts[i].length] = instTest.classIndex();
                delTransform.setAttributeIndicesArray(featArray);
                delTransform.setInputFormat(testCopy);
                testCopy = Filter.useFilter(testCopy, delTransform);
                trainCopy = Filter.useFilter(trainCopy, delTransform);

                //Classifier classifier = wrapper.getClassifier();
                //evaluation = new Evaluation(trainCopy,cm);
                Evaluation evaluation = new Evaluation(trainCopy);
                classifier.buildClassifier(trainCopy);
                evalationCVB(testmode,evaluation,classifier,trainCopy,testCopy,i,trainCopy.numAttributes() - 1);

            }
            splitResults.append("#=======================================================#\n");
        }

    }else{// not NSGAII

        // copy the instances
        Instances testCopy = new Instances(instTest);
        Instances trainCopy = new Instances(instCopy);
        strName = new String[]{""};
        // set up an array of attribute indexes for the filter (+1 for the class)
        Remove delTransform = new Remove();
        delTransform.setInvertSelection(true);
        int[] featArray = new int[attributeSet.length + 1];
        System.arraycopy(attributeSet, 0, featArray, 0, attributeSet.length);

        featArray[attributeSet.length] = instTest.classIndex();
        delTransform.setAttributeIndicesArray(featArray);
        delTransform.setInputFormat(testCopy);
        testCopy = Filter.useFilter(testCopy, delTransform);
        trainCopy = Filter.useFilter(trainCopy, delTransform);

        //Classifier classifier = wrapper.getClassifier();
        //evaluation = new Evaluation(trainCopy,cm);
        Evaluation evaluation = new Evaluation(trainCopy);
        classifier.buildClassifier(trainCopy);
        evalationCVB(testmode,evaluation,classifier,trainCopy,testCopy,0,trainCopy.numAttributes() - 1);
    }
//    if(classifier instanceof MultiClassClassifier){
//        MultiClassClassifier mc = (MultiClassClassifier)classifier;
//        Classifier cc = mc.getClassifier();
//        if(cc instanceof SMO){
//            ((SMO)cc).setBuildLogisticModels(ori);
//        }
//        if(cc instanceof LibSVM){
//            ((LibSVM)cc).setPredictProbability(ori);
//        }
//
//    }

}
////////////////////////////////////////////////////////////////////////////////

public void evalationCVB(int testmode,Evaluation evaluation, Classifier classifier,Instances trainCopy, Instances testCopy, int iStr, double numf)throws Exception{
    if (testmode == 1) { //crossvalidation, percentage split
        evaluation.evaluateModel(classifier, testCopy);
//        splitResults.append(evaluation.toMatrixString() + "\n" +
//                                evaluation.toClassDetailsString() + "\n");
        testingError[iStr][m_trials - 1] = evaluation.errorRate();
        if(trainCopy.classAttribute().isNominal()){
        	rci[iStr][m_trials-1] = evaluation.relativeClassifierInformation();
        }else{
        	rci[iStr][m_trials-1] = 0;
        }
        numFeatures[iStr][m_trials - 1] = numf;
        splitResults.append("Trail "+m_trials+" "+strName[iStr]+" testingError: " + evaluation.errorRate() + " using "+numf+"features \n");
        System.out.println("Trails: " + m_trials + " "+strName[iStr]+" testingError: " + evaluation.errorRate());
    } else if (testmode == 2) { //bootstrap
            evaluation.evaluateModel(classifier, trainCopy);
            double trainE = evaluation.errorRate();
            evaluation = new Evaluation(trainCopy);
            evaluation.evaluateModel(classifier, testCopy);
            double testE = evaluation.errorRate();
            testingError[iStr][m_trials - 1] = (0.632 * testE + 0.368 * trainE);
            numFeatures[iStr][m_trials - 1] = numf;
            if(trainCopy.classAttribute().isNominal()){
            	rci[iStr][m_trials-1] = evaluation.relativeClassifierInformation();
            }else{
            	rci[iStr][m_trials-1] = 0;
            }
            splitResults.append("0.632 Bootstrap "+strName[iStr]+" Training Error: " + trainE +
                                " on " + trainCopy.numInstances() +
                                " training samples(with duplicates)\n" +
                                "0.632 Bootstrap "+strName[iStr]+" Test Error: " + testE + " on " +
                                testCopy.numInstances() + " test samples\n" +
                                "0.632 Bootstrap "+strName[iStr]+" Error: " +
                                (0.632 * testE + 0.368 * trainE) + "\n");
            System.out.println("Trails: " + m_trials + " "+strName[iStr]+" bootstrap error: " +
                               (0.632 * testE + 0.368 * trainE));
        }

}




/**
   * Perform a cross validation for attribute selection. With subset
   * evaluators the number of times each attribute is selected over
   * the cross validation is reported. For attribute evaluators, the
   * average merit and average ranking + std deviation is reported for
   * each attribute.
   *
   * @return the results of cross validation as a String
   * @exception Exception if an error occurs during cross validation
   */
  public String CrossValidateAttributes () throws Exception {
    Instances cvData = new Instances(m_trainInstances);
    Instances train;
    double[][] rankResults;
    double[] subsetResults;
    double[][] attributeRanking = null;

    Random random = new Random(m_seed);
    cvData.randomize(random);

    if (!(m_ASEvaluator instanceof UnsupervisedSubsetEvaluator) &&
	!(m_ASEvaluator instanceof UnsupervisedAttributeEvaluator)) {
      if (cvData.classAttribute().isNominal()) {
	cvData.stratify(m_numFolds);
      }

    }

    for (int i = 0; i < m_numFolds; i++) {
      // Perform attribute selection
      train = cvData.trainCV(m_numFolds, i, random);
      selectAttributesSplit(train);
    }

    return  splitResultsString();
  }

  /**
   * Perform attribute selection on the supplied training instances.
   *
   * @param data the instances to select attributes from
   * @exception Exception if there is a problem during selection
   */
  public void SelectAttributes (Instances data) throws Exception {
    int [] attributeSet;

    m_transformer = null;
    m_attributeFilter = null;
    m_trainInstances = data;

    if (m_doXval == true && (m_ASEvaluator instanceof AttributeTransformer)) {
      throw new Exception("Can't cross validate an attribute transformer.");
    }

    if (m_ASEvaluator instanceof SubsetEvaluator &&
	m_searchMethod instanceof Ranker) {
      throw new Exception(m_ASEvaluator.getClass().getName()
			  +" must use a search method other than Ranker");
    }

    if (m_ASEvaluator instanceof AttributeEvaluator &&
	!((m_searchMethod instanceof Ranker) || (m_searchMethod instanceof RankSearch))) {
      //      System.err.println("AttributeEvaluators must use a Ranker search "
      //			 +"method. Switching to Ranker...");
      //      m_searchMethod = new Ranker();
      throw new Exception("AttributeEvaluators must use the Ranker search "
			  + "method");
    }

    if (m_searchMethod instanceof RankedOutputSearch) {
      m_doRank = ((RankedOutputSearch)m_searchMethod).getGenerateRanking();
    }

    if (m_ASEvaluator instanceof UnsupervisedAttributeEvaluator ||
	m_ASEvaluator instanceof UnsupervisedSubsetEvaluator) {
      // unset the class index
      //      m_trainInstances.setClassIndex(-1);
    } else {
      // check that a class index has been set
      if (m_trainInstances.classIndex() < 0) {
	m_trainInstances.setClassIndex(m_trainInstances.numAttributes()-1);
      }
    }

    // Initialize the attribute evaluator
    m_ASEvaluator.buildEvaluator(m_trainInstances);
    if (m_ASEvaluator instanceof AttributeTransformer) {
      m_trainInstances =
	((AttributeTransformer)m_ASEvaluator).transformedHeader();
      m_transformer = (AttributeTransformer)m_ASEvaluator;
    }
    int fieldWidth = (int)(Math.log(m_trainInstances.numAttributes()) +1.0);

    // Do the search
    attributeSet = m_searchMethod.search(m_ASEvaluator,
					 m_trainInstances);
    // try and determine if the search method uses an attribute transformer---
    // this is a bit of a hack to make things work properly with RankSearch
    // using PrincipalComponents as its attribute ranker
     try {
       BeanInfo bi = Introspector.getBeanInfo(m_searchMethod.getClass());
       PropertyDescriptor properties[];
       MethodDescriptor methods[];
       //       methods = bi.getMethodDescriptors();
       properties = bi.getPropertyDescriptors();
       for (int i=0;i<properties.length;i++) {
	 String name = properties[i].getDisplayName();
	 Method meth = properties[i].getReadMethod();
	 Object retType = meth.getReturnType();
	 if (retType.equals(ASEvaluation.class)) {
	   Class args [] = { };
	   ASEvaluation tempEval = (ASEvaluation)(meth.invoke(m_searchMethod,args));
	   if (tempEval instanceof AttributeTransformer) {
	     // grab the transformed data header
	     m_trainInstances =
	       ((AttributeTransformer)tempEval).transformedHeader();
	     m_transformer = (AttributeTransformer)tempEval;
	   }
	 }
       }
     } catch (IntrospectionException ex) {
       System.err.println("AttributeSelection: Couldn't "
			  +"introspect");
     }


     // Do any postprocessing that a attribute selection method might require
     attributeSet = m_ASEvaluator.postProcess(attributeSet);
     if (!m_doRank) {
       m_selectionResults.append(printSelectionResults());
     }

    if ((m_searchMethod instanceof RankedOutputSearch) && m_doRank == true) {
      m_attributeRanking =
	((RankedOutputSearch)m_searchMethod).getRankedAttributes();
      m_selectionResults.append(printSelectionResults());
      m_selectionResults.append("Ranked attributes:\n");

      // retrieve the number of attributes to retain
      m_numToSelect =
	((RankedOutputSearch)m_searchMethod).getCalculatedNumToSelect();

      // determine fieldwidth for merit
      int f_p=0;
      int w_p=0;

      for (int i = 0; i < m_numToSelect; i++) {
	double precision = (Math.abs(m_attributeRanking[i][1]) -
			    (int)(Math.abs(m_attributeRanking[i][1])));

	if (precision > 0) {
	  precision = Math.abs((Math.log(Math.abs(precision)) /
				Math.log(10)))+3;
	}
	if (precision > f_p) {
	  f_p = (int)precision;
	}
	if ((Math.abs((Math.log(Math.abs(m_attributeRanking[i][1]))
		       / Math.log(10)))+1) > w_p) {
	  if (m_attributeRanking[i][1] > 0) {
	    w_p = (int)Math.abs((Math.log(Math.abs(m_attributeRanking[i][1]))
				 / Math.log(10)))+1;
	  }
	}
      }

      for (int i = 0; i < m_numToSelect; i++) {
	m_selectionResults.
	  append(Utils.doubleToString(m_attributeRanking[i][1],
				      f_p+w_p+1,f_p)
		 + Utils.doubleToString((m_attributeRanking[i][0] + 1),
					fieldWidth+1,0)
		 + " "
		 + m_trainInstances.
		 attribute((int)m_attributeRanking[i][0]).name()
		 + "\n");
        m_rankedResults.
          append(Utils.doubleToString(m_attributeRanking[i][1],
                                      f_p+w_p+1,f_p)
                 + Utils.doubleToString((m_attributeRanking[i][0] + 1),
                                        fieldWidth+1,0)
                 + "\n");
      }

      // set up the selected attributes array - usable by a filter or
      // whatever
      if (!(m_ASEvaluator instanceof UnsupervisedSubsetEvaluator)
	  && !(m_ASEvaluator instanceof UnsupervisedAttributeEvaluator))
	{
	  // one more for the class
	  m_selectedAttributeSet = new int[m_numToSelect + 1];
	  m_selectedAttributeSet[m_numToSelect] =
	    m_trainInstances.classIndex();
	}
      else {
	m_selectedAttributeSet = new int[m_numToSelect];
      }

      m_selectionResults.append("\nSelected attributes: ");

      for (int i = 0; i < m_numToSelect; i++) {
	m_selectedAttributeSet[i] = (int)m_attributeRanking[i][0];

	if (i == m_numToSelect - 1) {
	  m_selectionResults.append(((int)m_attributeRanking[i][0] + 1)
				    + " : "
				    + (i + 1)
				    + "\n");
	}
	else {
	  m_selectionResults.append(((int)m_attributeRanking[i][0] + 1));
	  m_selectionResults.append(",");
	}
      }
      //======================added by zexuan===================================
      if(m_searchMethod instanceof Ranker){
        this.m_selectionResults.append(((Ranker)m_searchMethod).getClassificationResutls());
      }
      //=========================================================================
    } else {
      // set up the selected attributes array - usable by a filter or
      // whatever
      if (!(m_ASEvaluator instanceof UnsupervisedSubsetEvaluator)
	  && !(m_ASEvaluator instanceof UnsupervisedAttributeEvaluator))
	// one more for the class
	{
	  m_selectedAttributeSet = new int[attributeSet.length + 1];
	  m_selectedAttributeSet[attributeSet.length] =
	    m_trainInstances.classIndex();
	}
      else {
	m_selectedAttributeSet = new int[attributeSet.length];
      }

      for (int i = 0; i < attributeSet.length; i++) {
	m_selectedAttributeSet[i] = attributeSet[i];
      }

      m_selectionResults.append("Selected attributes: ");

      for (int i = 0; i < attributeSet.length; i++) {
	if (i == (attributeSet.length - 1)) {
	  m_selectionResults.append((attributeSet[i] + 1)
				    + " : "
				    + attributeSet.length
				    + "\n");
	}
	else {
	  m_selectionResults.append((attributeSet[i] + 1) + ",");
	}
      }

      for (int i=0;i<attributeSet.length;i++) {
	m_selectionResults.append("                     "
				  +m_trainInstances
				  .attribute(attributeSet[i]).name()
				  +"\n");
      }
    }

    // Cross validation should be called from here
    if (m_doXval == true) {
      m_selectionResults.append(CrossValidateAttributes());
    }

    // set up the attribute filter with the selected attributes
    if (m_selectedAttributeSet != null && !m_doXval) {
      m_attributeFilter = new Remove();
      m_attributeFilter.setAttributeIndicesArray(m_selectedAttributeSet);
      m_attributeFilter.setInvertSelection(true);
      m_attributeFilter.setInputFormat(m_trainInstances);
    }

    // Save space
    m_trainInstances = new Instances(m_trainInstances, 0);
  }

  /**
   * Perform attribute selection with a particular evaluator and
   * a set of options specifying search method and options for the
   * search method and evaluator.
   *
   * @param ASEvaluator an evaluator object
   * @param options an array of options, not only for the evaluator
   * but also the search method (if any) and an input data file
   * @param outAttributes index 0 will contain the array of selected
   * attribute indices
   * @param train the input instances
   * @return the results of attribute selection as a String
   * @exception Exception if incorrect options are supplied
   */
  public static String SelectAttributes (ASEvaluation ASEvaluator,
					 String[] options,
					 Instances train)
    throws Exception {
    int seed = 1, folds = 10;
    String cutString, foldsString, seedString, searchName;
    String classString;
    String searchClassName;
    String[] searchOptions = null; //new String [1];
    Random random;
    ASSearch searchMethod = null;
    boolean doCrossVal = false;
    Range initialRange;
    int classIndex = -1;
    int[] selectedAttributes;
    double cutoff = -Double.MAX_VALUE;
    boolean helpRequested = false;
    StringBuffer text = new StringBuffer();
    initialRange = new Range();
    AttributeSelection trainSelector = new AttributeSelection();

    try {
      if (Utils.getFlag('h', options)) {
	helpRequested = true;
      }

      // get basic options (options the same for all attribute selectors
      classString = Utils.getOption('C', options);

      if (classString.length() != 0) {
	if (classString.equals("first")) {
	  classIndex = 1;
	} else if (classString.equals("last")) {
	  classIndex = train.numAttributes();
	} else {
	  classIndex = Integer.parseInt(classString);
	}
      }

      if ((classIndex != -1) &&
	  ((classIndex == 0) || (classIndex > train.numAttributes()))) {
	throw  new Exception("Class index out of range.");
      }

      if (classIndex != -1) {
	train.setClassIndex(classIndex - 1);
      }
      else {
	//	classIndex = train.numAttributes();
	//	train.setClassIndex(classIndex - 1);
      }

      foldsString = Utils.getOption('X', options);

      if (foldsString.length() != 0) {
	folds = Integer.parseInt(foldsString);
	doCrossVal = true;
      }

      trainSelector.setFolds(folds);
      trainSelector.setXval(doCrossVal);

      seedString = Utils.getOption('N', options);

      if (seedString.length() != 0) {
	seed = Integer.parseInt(seedString);
      }

      trainSelector.setSeed(seed);

      searchName = Utils.getOption('S', options);

      if ((searchName.length() == 0) &&
	  (!(ASEvaluator instanceof AttributeEvaluator))) {
	throw  new Exception("No search method given.");
      }

      if (searchName.length() != 0) {
	searchName = searchName.trim();
	// split off any search options
	int breakLoc = searchName.indexOf(' ');
	searchClassName = searchName;
	String searchOptionsString = "";

	if (breakLoc != -1) {
	  searchClassName = searchName.substring(0, breakLoc);
	  searchOptionsString = searchName.substring(breakLoc).trim();
	  searchOptions = Utils.splitOptions(searchOptionsString);
	}
      }
      else {
	try {
	  searchClassName = new String("weka.attributeSelection.Ranker");
	  searchMethod = (ASSearch)Class.
	    forName(searchClassName).newInstance();
	}
	catch (Exception e) {
	  throw  new Exception("Can't create Ranker object");
	}
      }

      // if evaluator is a subset evaluator
      // create search method and set its options (if any)
      if (searchMethod == null) {
	searchMethod = ASSearch.forName(searchClassName, searchOptions);
      }

      // set the search method
      trainSelector.setSearch(searchMethod);
    }
    catch (Exception e) {
      throw  new Exception('\n' + e.getMessage()
			   + makeOptionString(ASEvaluator, searchMethod));
    }

    try {
      // Set options for ASEvaluator
      if (ASEvaluator instanceof OptionHandler) {
	((OptionHandler)ASEvaluator).setOptions(options);
      }

      /* // Set options for Search method
	 if (searchMethod instanceof OptionHandler)
	 {
	 if (searchOptions != null)
	 {
	 ((OptionHandler)searchMethod).setOptions(searchOptions);
	 }
	 }
	 Utils.checkForRemainingOptions(searchOptions); */
    }
    catch (Exception e) {
      throw  new Exception("\n" + e.getMessage()
			   + makeOptionString(ASEvaluator, searchMethod));
    }

    try {
      Utils.checkForRemainingOptions(options);
    }
    catch (Exception e) {
      throw  new Exception('\n' + e.getMessage()
			   + makeOptionString(ASEvaluator, searchMethod));
    }

    if (helpRequested) {
      System.out.println(makeOptionString(ASEvaluator, searchMethod));
      System.exit(0);
    }

    // set the attribute evaluator
    trainSelector.setEvaluator(ASEvaluator);

    // do the attribute selection
    trainSelector.SelectAttributes(train);

    // return the results string
    return trainSelector.toResultsString();
  }


  /**
   * Assembles a text description of the attribute selection results.
   *
   * @return a string describing the results of attribute selection.
   */
  private String printSelectionResults () {
    StringBuffer text = new StringBuffer();
    text.append("\n\n=== Attribute Selection on all input data ===\n\n"
		+ "Search Method:\n");
    text.append(m_searchMethod.toString());
    text.append("\nAttribute ");

    if (m_ASEvaluator instanceof SubsetEvaluator) {
      text.append("Subset Evaluator (");
    }
    else {
      text.append("Evaluator (");
    }

    if (!(m_ASEvaluator instanceof UnsupervisedSubsetEvaluator)
	&& !(m_ASEvaluator instanceof UnsupervisedAttributeEvaluator)) {
      text.append("supervised, ");
      text.append("Class (");

      if (m_trainInstances.attribute(m_trainInstances.classIndex())
	  .isNumeric()) {
	text.append("numeric): ");
      }
      else {
	text.append("nominal): ");
      }

      text.append((m_trainInstances.classIndex() + 1)
		  + " "
		  + m_trainInstances.attribute(m_trainInstances
					       .classIndex()).name()
		  + "):\n");
    }
    else {
      text.append("unsupervised):\n");
    }

    text.append(m_ASEvaluator.toString() + "\n");
    return  text.toString();
  }


  /**
   * Make up the help string giving all the command line options
   *
   * @param ASEvaluator the attribute evaluator to include options for
   * @param searchMethod the search method to include options for
   * @return a string detailing the valid command line options
   */
  private static String makeOptionString (ASEvaluation ASEvaluator,
					  ASSearch searchMethod)
    throws Exception {
    StringBuffer optionsText = new StringBuffer("");
    // General options
    optionsText.append("\n\nGeneral options:\n\n");
    optionsText.append("-h display this help\n");
    optionsText.append("-I <name of input file>\n");
    optionsText.append("\tSets training file.\n");
    optionsText.append("-C <class index>\n");
    optionsText.append("\tSets the class index for supervised attribute\n");
    optionsText.append("\tselection. Default=last column.\n");
    optionsText.append("-S <Class name>\n");
    optionsText.append("\tSets search method for subset evaluators.\n");
    optionsText.append("-X <number of folds>\n");
    optionsText.append("\tPerform a cross validation.\n");
    optionsText.append("-N <random number seed>\n");
    optionsText.append("\tUse in conjunction with -X.\n");

    // Get attribute evaluator-specific options
    if (ASEvaluator instanceof OptionHandler) {
      optionsText.append("\nOptions specific to "
			 + ASEvaluator.getClass().getName()
			 + ":\n\n");
      Enumeration enumer = ((OptionHandler)ASEvaluator).listOptions();

      while (enumer.hasMoreElements()) {
	Option option = (Option)enumer.nextElement();
	optionsText.append(option.synopsis() + '\n');
	optionsText.append(option.description() + "\n");
      }
    }

    if (searchMethod != null) {
      if (searchMethod instanceof OptionHandler) {
	optionsText.append("\nOptions specific to "
			   + searchMethod.getClass().getName()
			   + ":\n\n");
	Enumeration enumer = ((OptionHandler)searchMethod).listOptions();

	while (enumer.hasMoreElements()) {
	  Option option = (Option)enumer.nextElement();
	  optionsText.append(option.synopsis() + '\n');
	  optionsText.append(option.description() + "\n");
	}
      }
    }
    else {
      if (ASEvaluator instanceof SubsetEvaluator) {
	System.out.println("No search method given.");
      }
    }

    return  optionsText.toString();
  }
/////////////////////////////////////////////////////////////////////////
  static void saveInstancesToFile(File f, Instances inst) {
      try {
          Writer w = new BufferedWriter(new FileWriter(f));
          Instances h = new Instances(inst, 0);
          w.write(h.toString());
          w.write("\n");
          for (int i = 0; i < inst.numInstances(); i++) {
              w.write(inst.instance(i).toString());
              w.write("\n");
          }
          w.close();
      } catch (Exception ex) {
          ex.printStackTrace();
      }

  }
/////////////////////////////////////////////////////////////////////////////
  /**
   * Main method for testing this class.
   *
   * @param args the options
   */
  public static void main (String[] args) {
    try {
      if (args.length == 0) {
	throw  new Exception("The first argument must be the name of an "
			     + "attribute/subset evaluator");
      }

      String EvaluatorName = args[0];
      args[0] = "";
      ASEvaluation newEval = ASEvaluation.forName(EvaluatorName, null);
      System.out.println(SelectAttributes(newEval, args));
    }
    catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }

    private void jbInit() throws Exception {
    }

    public Instances filter(Instances data, BitSet gab)throws Exception{


        Remove delTransform = new Remove();
        delTransform.setInvertSelection(true);
        // copy the instances
        Instances trainCopy = new Instances(data);

        // set up an array of attribute indexes for the filter (+1 for the class)
        int[] featArray = new int[gab.cardinality() + 1];
        int i,j;
        for (i = 0, j = 0; i < trainCopy.numAttributes(); i++) {
            if (gab.get(i)) {
                featArray[j++] = i;
            }
        }

        featArray[j] = trainCopy.classIndex();
        delTransform.setAttributeIndicesArray(featArray);
        delTransform.setInputFormat(trainCopy);
        return Filter.useFilter(trainCopy, delTransform);

    }


}

