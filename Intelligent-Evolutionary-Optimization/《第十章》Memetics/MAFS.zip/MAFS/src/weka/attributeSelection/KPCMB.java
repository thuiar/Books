package weka.attributeSelection;

import weka.core.Instances;
import weka.core.OptionHandler;
import weka.core.Utils;
import java.util.Vector;
import weka.core.Option;
import java.util.Enumeration;
import java.io.File;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.Filter;
import weka.core.Optimization;
import weka.classifiers.functions.supportVector.PolyKernel;
import weka.classifiers.functions.supportVector.RBFKernel;
import weka.classifiers.functions.supportVector.CachedKernel;
import weka.core.Instance;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class KPCMB extends AttributeEvaluator implements OptionHandler{
    public KPCMB() {
    }
    private double m_coverVariance = 0.95;
    protected double m_exponent = 1.0;
    protected boolean m_lowerOrder = false;
    protected double m_gamma = 0.01;
    protected boolean m_useRBF = false;
    private double m_Cthreshold = -Double.MAX_VALUE;
    private int m_numToSelect = -1;
    private double scale[];
    private double selectedKSF[];
    private Instances oriData, transData;
    private int numInstances, numAttributeOri, numAttributeTrans;
    private PrincipalComponents kpc;
    private double [][] m_eigenvectors;
    private double [] m_eigenvalues;
    private int [] m_sortedEigens;
    protected double m_stepsize = 0.1;

    public double getStepSize() {
        return m_stepsize;
    }
    public void setStepSize(double m){
        m_stepsize = m;
    }

    public double getExponent() {
        return m_exponent;
    }

    public void setExponent(double v) {
        if (v == 1.0) {
            m_lowerOrder = false;
        }
        m_exponent = v;
    }

    public double getGamma() {
        return m_gamma;
    }
    public void setGamma(double v) {
        m_gamma = v;
    }

    public boolean getLowerOrderTerms() {
        return m_lowerOrder;
    }
    public void setLowerOrderTerms(boolean v) {

        if (m_exponent == 1.0 || m_useRBF) {
            m_lowerOrder = false;
        } else {
            m_lowerOrder = v;
        }
    }
    public boolean getUseRBF() {
        return m_useRBF;
    }
    public void setUseRBF(boolean v) {
        if (v) {
            m_lowerOrder = false;
        }
        m_useRBF = v;
    }
    public void setVarianceCovered(double vc) {
        m_coverVariance = vc;
    }

    public double getVarianceCovered() {
        return m_coverVariance;
    }
    public void setCThreshold(double threshold) {
        m_Cthreshold = threshold;
    }
    public double getCThreshold() {
        return m_Cthreshold;
    }

    public void setNumToSelect(int n) {
        m_numToSelect = n;
    }

    public int getNumToSelect() {
        return m_numToSelect;
    }

    /**
   * Gets the current settings of PrincipalComponents
   *
   * @return an array of strings suitable for passing to setOptions()
   */


    public String[] getOptions () {

        String[] options = new String[16];
        int current = 0;


        options[current++] = "-R"; options[current++] = "" +getVarianceCovered();
        options[current++] = "-E"; options[current++] = "" + m_exponent;
        options[current++] = "-G"; options[current++] = "" + m_gamma;
        options[current++] = "-T"; options[current++] = "" + getCThreshold();
        options[current++] = "-N"; options[current++] = ""+getNumToSelect();
        options[current++] = "-P";
        options[current++] = "" + getStepSize();
        if (m_lowerOrder) {
            options[current++] = "-L";
        }
        if (m_useRBF) {
            options[current++] = "-B";
        }
        while (current < options.length) {
            options[current++] = "";
        }

        return  options;
    }

    /**
   * Parses a given list of options.
   *
   * @param options the list of options as an array of strings
   * @exception Exception if an option is not supported
   */
  public void setOptions (String[] options) throws Exception {
      String optionString;

      optionString = Utils.getOption('R', options);
      if (optionString.length() != 0) {
          Double temp;
          temp = Double.valueOf(optionString);
          setVarianceCovered(temp.doubleValue());
      }
      optionString = Utils.getOption('P', options);
      if (optionString.length() != 0) {
          setStepSize(Double.parseDouble(optionString));
      }

      String exponentsString = Utils.getOption('E', options);
      if (exponentsString.length() != 0) {
          m_exponent = (new Double(exponentsString)).doubleValue();
      } else {
          m_exponent = 1.0;
      }

      String gammaString = Utils.getOption('G', options);
      if (gammaString.length() != 0) {
          m_gamma = (new Double(gammaString)).doubleValue();
      } else {
          m_gamma = 0.01;
      }
      m_useRBF = Utils.getFlag('B', options);
      m_lowerOrder = Utils.getFlag('L', options);
      optionString = Utils.getOption('T', options);
      if (optionString.length() != 0) {
          Double temp;
          temp = Double.valueOf(optionString);
          setCThreshold(temp.doubleValue());
      }

      optionString = Utils.getOption('N', options);
      if (optionString.length() != 0) {
          setNumToSelect(Integer.parseInt(optionString));
      }
  }

  /**
   * Returns an enumeration describing the available options. <p>
   *
   * @return an enumeration of all the available options.
   **/
  public Enumeration listOptions () {
    Vector newVector = new Vector(8);
    newVector.addElement(new Option("\tRetain enough PC attributes to account "
                                    +"\n\tfor this proportion of variance in "
                                    +"the original data. (default = 0.95)",
                                    "R",1,"-R"));

    newVector.addElement(new Option("\tThe exponent for the "
                                    + "polynomial kernel. (default 1)",
                                    "E", 1, "-E <double>"));
    newVector.addElement(new Option("\tGamma for the RBF kernel. (default 0.01)",
                                    "G", 1, "-G <double>"));
    newVector.addElement(new Option("\tUse lower-order terms (only for non-linear\n" +
                                    "\tpolynomial kernels).",
                                    "L", 0, "-L"));
    newVector.addElement(new Option("\tUse RBF kernel. " +
                                    "(default poly)",
                                    "B", 0, "-B"));
    newVector.addElement(new Option("\tSpecify a theshold by which attributes"
                             + "\tmay be discarded from the ranking.","T",1
                             , "-T <threshold>"));
    newVector.addElement(new Option("\tSpecify number of attributes to select"
                             ,"N",1
                             , "-N <num to select>"));
    newVector.addElement(new Option("\tSpecify the number of Step Size.","P",1,"-P <number>"));
    return  newVector.elements();
  }



    /**
     * Generates a attribute evaluator.
     *
     * @param data set of instances serving as training data
     * @throws Exception if the evaluator has not been generated successfully
     * @todo Implement this weka.attributeSelection.ASEvaluation method
     */
    public void buildEvaluator(Instances data) throws Exception {
        numInstances = data.numInstances();
        numAttributeOri = data.numAttributes();
        oriData = data;
        kpc = new PrincipalComponents();
        kpc.setExponent(m_exponent);
        kpc.setGamma(m_gamma);
        kpc.setUseKernel(true);
        kpc.setVarianceCovered(m_coverVariance);
        kpc.setLowerOrderTerms(m_lowerOrder);
        kpc.setUseRBF(m_useRBF);
        kpc.buildEvaluator(data);
        transData = kpc.transformedData();
        m_eigenvalues = kpc.m_eigenvalues;
        m_eigenvectors = kpc.m_eigenvectors;
        m_sortedEigens = kpc.m_sortedEigens;
        numAttributeTrans = transData.numAttributes();
        FCBFSearch fcbf = new FCBFSearch();
        SymmetricalUncertAttributeSetEval suase = new SymmetricalUncertAttributeSetEval();
        suase.buildEvaluator(transData);
        fcbf.setNumToSelect(m_numToSelect);
        fcbf.setThreshold(m_Cthreshold);
        int tmp[] = fcbf.search(suase,transData);
        selectedKSF = new double[numAttributeTrans];
        for (int i = 0; i < tmp.length; i++) {
            selectedKSF[tmp[i]] = 1.0;
        }
        System.out.println(selectedKSF.length+" "+m_eigenvalues.length);
//        int[] featArray = new int[selectedKSF.length + 1];
//        System.arraycopy(selectedKSF,0,featArray,0,selectedKSF.length);
//        featArray[featArray.length-1] = kernelSpaceData.classIndex();
//        Remove delTransform = new Remove();
//        delTransform.setInvertSelection(true);
//        delTransform.setAttributeIndicesArray(featArray);
//        delTransform.setInputFormat(kernelSpaceData);
//        Instances selectedData = Filter.useFilter(kernelSpaceData, delTransform);
//        Utils.printArray("SelectedKSF=",selectedKSF);
//        kernelSpaceData.saveToFile(new File("ksd.arff"));
//        selectedData.saveToFile(new File("sksd.arff"));
        scale = new double[data.numAttributes()-1];
        java.util.Arrays.fill(scale,1.0);
        MyOpt solver = new MyOpt();
        double[][] constraints = new double[2][scale.length];
        java.util.Arrays.fill(constraints[0],-Double.MAX_VALUE);
        java.util.Arrays.fill(constraints[1],Double.MAX_VALUE);
        solver.setMaxIteration(200);
        solver.setMaxStepLength(m_stepsize);
        solver.setTOLX(1e-3);
        solver.setConvergeSolution(true);
        scale = solver.findArgmin(scale, constraints);
        while(scale==null){
            scale = solver.getVarbValues();
            scale = solver.findArgmin(scale, constraints);
        }

        for (int i = 0; i < scale.length; i++) {
            scale[i] = Math.abs(scale[i]);
        }




    }

    /**
     *
     * @param attribute the index of the attribute to be evaluated
     * @return the "merit" of the attribute
     * @throws Exception if the attribute could not be evaluated
     * @todo Implement this weka.attributeSelection.AttributeEvaluator method
     */
    public double evaluateAttribute(int attribute) throws Exception {
        return scale[attribute];
    }


    class MyOpt extends Optimization{
        protected double objectiveFunction(double[] x){
            double result = 0;
            try{
                Instances scalecopy = oriData.scaleData(x);
                CachedKernel m_kernel;
                if(m_useRBF) {
                    m_kernel = new RBFKernel(scalecopy, 0, m_gamma);
                } else {
                    m_kernel = new PolyKernel(scalecopy, 0, m_exponent, m_lowerOrder);
                }
                for (int i = 0; i < numInstances; i++) {
                    Instance sxi = scalecopy.instance(i);
                    for (int k = 0; k < numAttributeTrans-1; k++) {
                        double sum = 0;
                        for (int j = 0; j < m_eigenvalues.length; j++) {
                            Instance xj = oriData.instance(j);
                            //double t1 = m_eigenvectors[j][m_sortedEigens[k]];
                            //double t2 = m_kernel.eval2i(sxi,xj);
                            sum += m_eigenvectors[j][m_sortedEigens[m_eigenvalues.length-k-1]]*m_kernel.eval2i(sxi,xj);
                        }
                        result += sum*sum;
                        //System.out.println("r="+result);
                        if(selectedKSF[k]==1.0){
                            result -= 2*transData.instance(i).value(k)*sum;
                        }
                        //System.out.println("r="+result);
                    }
                }
            }catch(Exception e){
                e.printStackTrace();
            }
            Utils.printArray("x=",x);
            System.out.println("objF= " + result);

            return result;
        }

        protected double[] evaluateGradient(double[] x){
            double gp[] = new double[x.length];
            Instances scalecopy = oriData.scaleData(x);
            for (int g = 0; g < x.length; g++) {
                try{
                    double result = 0;
                    for (int i = 0; i < numInstances; i++) {
                        Instance xi=oriData.instance(i), sxi= scalecopy.instance(i);
                        for (int k = 0; k < numAttributeTrans-1; k++) {
                            double sum = 0, sumg = 0;
                            for (int j = 0; j < m_eigenvalues.length; j++) {
                                Instance xj = oriData.instance(j);
                                CachedKernel m_kernel;
                                double kgp = 0;
                                if(m_useRBF){
                                    kgp = 2*m_gamma*(xi.value(g)*xj.value(g)-x[g]*xi.value(g)*xi.value(g))*Math.exp(m_gamma*(2*dotProd(sxi,xj)-dotProd(sxi,sxi)-dotProd(xj,xj)));
                                    m_kernel = new RBFKernel(scalecopy, 0, m_gamma);
                                }else{
                                    kgp = xi.value(g)*xj.value(g)*m_exponent*Math.pow(dotProd(sxi,xj)+(m_lowerOrder?1:0),m_exponent-1);
                                    m_kernel = new PolyKernel(scalecopy, 0, m_exponent, m_lowerOrder);
                                }
                                sum += m_eigenvectors[j][m_sortedEigens[m_eigenvalues.length-k-1]]*m_kernel.eval2i(sxi,xj);
                                sumg += m_eigenvectors[j][m_sortedEigens[m_eigenvalues.length-k-1]]*kgp;
                            }
                            result += 2*sum*sumg;
                            if(selectedKSF[k] == 1.0){
                                result -= 2*transData.instance(i).value(k)*sumg;
                            }
                        }

                    }
                    gp[g] = result;
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
            Utils.printArray("g=",gp);
            return gp;
        }

    }

    double dotProd(Instance inst1, Instance inst2) throws Exception {

        double result = 0;

        // we can do a fast dot product
        int n1 = inst1.numValues();
        int n2 = inst2.numValues();
        int classIndex = oriData.classIndex();
        for (int p1 = 0, p2 = 0; p1 < n1 && p2 < n2;) {
            int ind1 = inst1.index(p1);
            int ind2 = inst2.index(p2);
            if (ind1 == ind2) {
                if (ind1 != classIndex) {
                    result += inst1.valueSparse(p1) * inst2.valueSparse(p2);
                }
                p1++;
                p2++;
            } else if (ind1 > ind2) {
                p2++;
            } else {
                p1++;
            }
        }
        return (result);
    }



}
