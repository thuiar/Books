package weka.attributeSelection;

import java.io.*;
import java.util.*;
import weka.gui.explorer.AttributeSelectionPanel;

public class FitnessThread extends Thread {
  String input;
  String chromBitset;
  int popIndex;
  int cpus;
  String wekaClass;
  String options = "";
  double merit = 1;
  public FitnessThread(String cls,String [] ops,String inputfile,String bitset,int popindex,int n){
    wekaClass = cls;
    for (int ii = 0; ii < ops.length; ii++) {
          options += ops[ii]+" ";
    }
    chromBitset = bitset;
    input = inputfile;
    popIndex = popindex;
    cpus = n;
    start();

  }
  public void run(){
    try {
      Runtime rt = Runtime.getRuntime();
      String command;
      WHILE: while(true){

        if(AttributeSelectionPanel.onAlpha){
          command = "prun -n " + cpus +
                        " java -classpath GALS.jar " +wekaClass+" -f "+input+" -i "+popIndex+" -c "+chromBitset+" "+options;
        }else{
          command = "java -classpath GALS.jar "+wekaClass+" -f "+input+" -i "+popIndex+" -c "+chromBitset+" "+options;
        }
        Process pro = rt.exec(command);
        pro.waitFor();
        int exitVal = pro.exitValue();
        if(exitVal!=0){
          continue WHILE;
        }
        InputStream stdin = pro.getInputStream();
        InputStreamReader isr = new InputStreamReader(stdin);
        BufferedReader br = new BufferedReader(isr);
        InputStream erro = pro.getErrorStream();
        InputStreamReader isrErro = new InputStreamReader(erro);
        BufferedReader brErro = new BufferedReader(isrErro);
        String line = null;
        String resultsinfo = "";
        double sum = 0;
        while ( (line = br.readLine()) != null){
          //System.out.println(line);
          if (line.startsWith("fitness"+popIndex+"=")) {
            double tmp = Double.parseDouble(line.substring(("fitness"+popIndex+"=").length()));
            sum += tmp;
          }else{
            resultsinfo += line+"\n";
          }
        }
        while((line = brErro.readLine()) != null){
          System.out.println(line);
        }
        merit = sum/cpus;
        System.out.println("Chromosome\t" + popIndex + "\t" + merit);
        pro.destroy();
        break WHILE;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }


  public static void main(String[] args) {
    try{
      FitnessThread ft = new FitnessThread("weka.attributeSelection.WrapperSubsetEval", args, "iris.arff","{1,2}", 1, 1);
      ft.join();
      System.out.println(ft.merit);
    }catch(Exception e){
      e.printStackTrace();
    }

  }
}

