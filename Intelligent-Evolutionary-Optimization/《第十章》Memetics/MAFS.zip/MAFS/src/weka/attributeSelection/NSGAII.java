package weka.attributeSelection;

import java.io.*;
import java.util.BitSet;
import weka.core.Utils;
import weka.core.Instances;
import weka.core.OptionHandler;
import java.util.Enumeration;
import java.util.Vector;
import weka.core.Option;
import java.util.Random;
import weka.attributeSelection.GA.GALocalSearch;
import weka.attributeSelection.GA.FilterRanking;
import weka.attributeSelection.GA.GABitSet;
import weka.attributeSelection.GA.GA;
import weka.classifiers.meta.MultiClassClassifier;
import weka.classifiers.functions.SMO;
import java.util.Arrays;
import weka.classifiers.functions.LibSVM;
import weka.core.Tag;
import weka.core.SelectedTag;
import java.util.Hashtable;
import weka.core.FastVector;
import weka.filters.Filter;
import weka.filters.unsupervised.instance.RemoveWithValues;
import weka.filters.unsupervised.attribute.MakeIndicator;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class NSGAII extends GA implements OptionHandler,Serializable{
    //=============================global.h=====================
    static double INF = 1.0e14;
    static double EPS = 1.0e-14;
    static double E = 2.71828182845905;
    static double PI = 3.14159265358979;
    int nreal = 0;
    int nbin = 0;
    int nobj = 2;
    int ncon = 0;
    int popsize = 52;
    double pcross_real = 0;
    double pcross_bin=0.6;
    double pmut_real = 0;
    double pmut_bin=0.1;
    double eta_c = 0;
    double eta_m = 0;
    int ngen = 50;
    int nbinmut = 0;
    int nrealmut = 0;
    int nbincross = 0;
    int nrealcross = 0;
    //int []nbits;
    double []min_realvar;
    double []max_realvar;
    double []min_binvar;
    double []max_binvar;
    int bitlength;
    int m_maxNBin = 50;
    int m_minNBin = 1;
    public SubsetEvaluator ASEvaluator;
    String initials;
    String bests;
    int [][] bestAttributes;
    int [][] bestAttributesMulticlass;
    protected Instances m_data;
    protected int m_localSearchScope = -1;
    protected GALocalSearch m_localSearchMethod = new FilterRanking();
    protected GALocalSearch m_lss[] = null;
    public long m_runningTime;



    protected long m_maxEvaluation = Long.MAX_VALUE;
    protected GABitSet outputSolution = new GABitSet();
    protected int m_multiClass = 0;
    public static final int NONE = 0;
    public static final int OVA = 1;
    public static final int OVA1 = 3;
    public static final int OVO = 2;
    public static final int OVO1 = 4;
    public static final Tag[] TAGS_MULTI = {
       new Tag(NONE, "Two Class"),
       new Tag(OVA, "One Versus All"),
       new Tag(OVA1, "One Versus All(n+1)"),
       new Tag(OVO, "One Versus One"),
       new Tag(OVO, "One Versus One(n+1)")
    };

    public int m_ensembleStrategy = 0;
    public static final int OFO = 0;
    public static final int ENSEMBLE = 1;
    public static final int CONJUNCTION = 2;
    public static final int ALL = 3;
    public static final Tag[] TAGS_ENSEMBLESTRATEGY = {
       new Tag(OFO, "One Set For One OVA/OVO"),
       new Tag(ENSEMBLE, "Ensemble Classifiers"),
       new Tag(CONJUNCTION,"Conjunction Features"),
       new Tag(ALL,"All Strategies")
    };

    protected int m_localSearch = 0;
    public static final int WEIGHT = 1;
    public static final int RANDOM = 2;
    public static final Tag[] TAGS_LOCALSEARCH = {
       new Tag(NONE, "No Local Search"),
       new Tag(WEIGHT, "Random Objective Weights"),
       new Tag(RANDOM, "Random Objective")
    };
  /** the number of entries to cache for lookup */
  private int m_lookupTableSize = 2001;

  /** the lookup table */
  Hashtable m_lookupTable;



    double [] weights;
    int lsObjective;
    class Population{
        GABitSet []ind;
    };

    class List{
        int index;
        List parent;
        List child;
    };

    public int getParallel(){
        return 0;
    }
    //====================================end global=================================
    //====================================rand.c==================================
    double seed;
    double oldrand[] = new double[55];
    int jrand;

    /* Get seed number for random and start it up */
    void randomize(){
        int j1;
        for(j1=0; j1<=54; j1++)
        {
            oldrand[j1] = 0.0;
        }
        jrand=0;
        warmup_random (seed);
        return;
    }

    /* Get randomize off and running */
    void warmup_random (double seed){
        int j1, ii;
        double new_random, prev_random;
        oldrand[54] = seed;
        new_random = 0.000000001;
        prev_random = seed;
        for(j1=1; j1<=54; j1++){
            ii = (21*j1)%54;
            oldrand[ii] = new_random;
            new_random = prev_random-new_random;
            if(new_random<0.0){
                new_random += 1.0;
            }
            prev_random = oldrand[ii];
        }
        advance_random ();
        advance_random ();
        advance_random ();
        jrand = 0;
        return;
    }

    /* Create next batch of 55 random numbers */
    void advance_random (){
        int j1;
        double new_random;
        for(j1=0; j1<24; j1++){
            new_random = oldrand[j1]-oldrand[j1+31];
            if(new_random<0.0){
                new_random = new_random+1.0;
            }
            oldrand[j1] = new_random;
        }
        for(j1=24; j1<55; j1++){
            new_random = oldrand[j1]-oldrand[j1-24];
            if(new_random<0.0){
                new_random = new_random+1.0;
            }
            oldrand[j1] = new_random;
        }
    }

    /* Fetch a single random number between 0.0 and 1.0 */
    double randomperc(){
        jrand++;
        if(jrand>=55){
            jrand = 1;
            advance_random();
        }
        return((double)oldrand[jrand]);
    }

    /* Fetch a single random integer between low and high including the bounds */
    int rnd (int low, int high){
        int res;
        if (low >= high){
            res = low;
        }
        else{
            res = low + (int)(randomperc()*(high-low+1));
            if (res > high){
                res = high;
            }
        }
        return (res);
    }

    /* Fetch a single random real number between low and high including the bounds */
    double rndreal (double low, double high){
        return (low + (high-low)*randomperc());
    }
    //====================================end rand=============================================
    //=====================================allocate===========================================
    /* Function to allocate memory to a Population */
    void allocate_memory_pop (Population pop, int size){
        int i;
        pop.ind = new GABitSet[size];
        for (i=0; i<size; i++){
            pop.ind[i] = new GABitSet();
            allocate_memory_ind (pop.ind[i]);
        }
        return;
    }

    /* Function to allocate memory to an individual */
    void allocate_memory_ind (GABitSet ind){
        int j;
        if (nreal != 0){
            ind.xreal = new double[nreal];
        }
        if (nbin != 0){
            //ind.xbin = new double[nbin];
            ind.m_chromosome = new BitSet();
            //ind.gene = new int[nbin][];
//            for (j=0; j<nbin; j++){
//                ind.gene[j] = new int[nbits[j]];
//            }
        }
        ind.obj = new double[nobj];
        if (ncon != 0){
            ind.constr = new double[ncon];
        }
        return;
    }

    /* Function to deallocate memory to a Population */
    void deallocate_memory_pop (Population pop, int size){
        int i;
        for (i=0; i<size; i++){
            deallocate_memory_ind (pop.ind[i]);
        }
        pop.ind = null;
        return;
    }

    /* Function to deallocate memory to an GABitSet */
    void deallocate_memory_ind (GABitSet ind){
        int j;
        if (nreal != 0){
            ind.xreal=null;
        }
        if (nbin != 0){
            ind.m_chromosome = null;
            //ind.gene = null;
        }
        ind.obj = null;
        if (ncon != 0){
            ind.constr = null;
        }
        return;
    }

    //==================================end allocate======================================================
    //==================================crossover=========================================================
    /* Function to cross two individuals */
    void crossover (GABitSet parent1, GABitSet parent2, GABitSet child1, GABitSet child2){
        if (nreal!=0){
            realcross (parent1, parent2, child1, child2);
        }
        if (nbin!=0){
            bincross (parent1, parent2, child1, child2);
        }
        return;
    }

    /* Routine for real variable SBX crossover */
    void realcross (GABitSet parent1, GABitSet parent2, GABitSet child1, GABitSet child2){
        int i;
        double rand;
        double y1, y2, yl, yu;
        double c1, c2;
        double alpha, beta, betaq;
        if (randomperc() <= pcross_real){
            nrealcross++;
            for (i=0; i<nreal; i++){
                if (randomperc()<=0.5 ){
                    if (Math.abs(parent1.xreal[i]-parent2.xreal[i]) > EPS){
                        if (parent1.xreal[i] < parent2.xreal[i])
                        {
                            y1 = parent1.xreal[i];
                            y2 = parent2.xreal[i];
                        }
                        else
                        {
                            y1 = parent2.xreal[i];
                            y2 = parent1.xreal[i];
                        }
                        yl = min_realvar[i];
                        yu = max_realvar[i];
                        rand = randomperc();
                        beta = 1.0 + (2.0*(y1-yl)/(y2-y1));
                        alpha = 2.0 - Math.pow(beta,-(eta_c+1.0));
                        if (rand <= (1.0/alpha))
                        {
                            betaq = Math.pow ((rand*alpha),(1.0/(eta_c+1.0)));
                        }
                        else
                        {
                            betaq = Math.pow ((1.0/(2.0 - rand*alpha)),(1.0/(eta_c+1.0)));
                        }
                        c1 = 0.5*((y1+y2)-betaq*(y2-y1));
                        beta = 1.0 + (2.0*(yu-y2)/(y2-y1));
                        alpha = 2.0 - Math.pow(beta,-(eta_c+1.0));
                        if (rand <= (1.0/alpha))
                        {
                            betaq = Math.pow ((rand*alpha),(1.0/(eta_c+1.0)));
                        }
                        else
                        {
                            betaq = Math.pow ((1.0/(2.0 - rand*alpha)),(1.0/(eta_c+1.0)));
                        }
                        c2 = 0.5*((y1+y2)+betaq*(y2-y1));
                        if (c1<yl)
                            c1=yl;
                        if (c2<yl)
                            c2=yl;
                        if (c1>yu)
                            c1=yu;
                        if (c2>yu)
                            c2=yu;
                        if (randomperc()<=0.5)
                        {
                            child1.xreal[i] = c2;
                            child2.xreal[i] = c1;
                        }
                        else
                        {
                            child1.xreal[i] = c1;
                            child2.xreal[i] = c2;
                        }
                    }
                    else
                    {
                        child1.xreal[i] = parent1.xreal[i];
                        child2.xreal[i] = parent2.xreal[i];
                    }
                }
                else
                {
                    child1.xreal[i] = parent1.xreal[i];
                    child2.xreal[i] = parent2.xreal[i];
                }
            }
        }
        else
        {
            for (i=0; i<nreal; i++)
            {
                child1.xreal[i] = parent1.xreal[i];
                child2.xreal[i] = parent2.xreal[i];
            }
        }
        return;
    }

    /* Routine for two point binary crossover */
    void bincross (GABitSet parent1, GABitSet parent2, GABitSet child1, GABitSet child2){
        double rand = randomperc();
        if (rand <= pcross_bin){
            nbincross++;
            if(m_maxNBin < nbin || m_minNBin > 1){ //fix length of chromosome
                int p1[] = bitSetToArray(parent1.m_chromosome,m_maxNBin);
                int p2[] = bitSetToArray(parent2.m_chromosome,m_maxNBin);
                int c1[] = new int[m_maxNBin];
                int c2[] = new int[m_maxNBin];
                double xoverr;
                for (int i = 0; i < m_maxNBin; i++) {
                    xoverr = randomperc();
                    if (xoverr < 0.5) {
                        if(!Utils.contain(c1,i,p2[i]) && !Utils.contain(c2,i,p1[i])){
                            c1[i] = p2[i];
                            c2[i] = p1[i];
                        }else{
                            c1[i] = p1[i];
                            c2[i] = p2[i];
                        }
                    }else{
                        if(!Utils.contain(c1,i,p1[i]) && !Utils.contain(c2,i,p2[i])){
                            c1[i] = p1[i];
                            c2[i] = p2[i];
                        }else{
                            c1[i] = p2[i];
                            c2[i] = p1[i];
                        }
                    }
                }
                child1.m_chromosome = arrayToBitSet(c1);
                child2.m_chromosome = arrayToBitSet(c2);
            }else{ //unfix length of chromosome
                double xoverr;
                for (int i = 0; i < nbin; i++) {
                    xoverr = randomperc();
                    if (xoverr < 0.5) {
                        if (parent1.m_chromosome.get(i)) {
                            child2.m_chromosome.set(i);
                        } else {
                            child2.m_chromosome.clear(i);
                        }
                        if (parent2.m_chromosome.get(i)) {
                            child1.m_chromosome.set(i);
                        } else {
                            child1.m_chromosome.clear(i);
                        }
                    }
                }

            }
        }else{
            child1.m_chromosome = parent1.m_chromosome;
            child2.m_chromosome = parent2.m_chromosome;
        }


//        int i, j;
//        double rand;
//        int temp, site1, site2;
//        for (i=0; i<nbin; i++)
//        {
//            rand = randomperc();
//            if (rand <= pcross_bin)
//            {
//                nbincross++;
//                site1 = rnd(0,nbits[i]-1);
//                site2 = rnd(0,nbits[i]-1);
//                if (site1 > site2)
//                {
//                    temp = site1;
//                    site1 = site2;
//                    site2 = temp;
//                }
//                for (j=0; j<site1; j++)
//                {
//                    child1.gene[i][j] = parent1.gene[i][j];
//                    child2.gene[i][j] = parent2.gene[i][j];
//                }
//                for (j=site1; j<site2; j++)
//                {
//                    child1.gene[i][j] = parent2.gene[i][j];
//                    child2.gene[i][j] = parent1.gene[i][j];
//                }
//                for (j=site2; j<nbits[i]; j++)
//                {
//                    child1.gene[i][j] = parent1.gene[i][j];
//                    child2.gene[i][j] = parent2.gene[i][j];
//                }
//            }
//            else
//            {
//                for (j=0; j<nbits[i]; j++)
//                {
//                    child1.gene[i][j] = parent1.gene[i][j];
//                    child2.gene[i][j] = parent2.gene[i][j];
//                }
//            }
//        }
//        return;
//        System.out.println("c1\t"+child1.m_chromosome.cardinality());
//        System.out.println("c2\t"+child2.m_chromosome.cardinality());
//
    }
    //===================================end crossover=====================================================
    //====================================mutation========================================================
    /* Function to perform mutation in a Population */
    void mutation_pop (Population pop)
    {
        int i;
        for (i=0; i<popsize; i++)
        {
            mutation_ind(pop.ind[i]);
        }
        return;
    }

    /* Function to perform mutation of an GABitSet */
    void mutation_ind (GABitSet ind)
    {
        if (nreal!=0)
        {
            real_mutate_ind(ind);
        }
        if (nbin!=0)
        {
            bin_mutate_ind(ind);
        }
        return;
    }

    /* Routine for binary mutation of an GABitSet */
    void bin_mutate_ind (GABitSet ind)
    {
        double r;
        if(m_maxNBin < nbin || m_minNBin > 1){ // fix chromosome length
            //System.out.println("before"+ind.m_chromosome.cardinality());
            int [] a = bitSetToArray(ind.m_chromosome,m_maxNBin);
            for (int i = 0; i < a.length; i++) {
                r = randomperc();
                if (r <=pmut_bin) {
                    nbinmut++;
                    if(a[i]!=-1 && i>=m_minNBin){
                        r = randomperc();
                        if(r<0.5){
                            a[i] = -1;
                        }else{
                            int b = rnd(0,nbin-1);
                            while (Utils.contain(a, a.length, b)) {
                                b = (b+1)%nbin;
                            }
                            a[i] = b;
                        }
                    }else{
                        int b = rnd(0,nbin-1);
                        while (Utils.contain(a, a.length, b)) {
                            b = (b+1)%nbin;
                        }
                        a[i] = b;
                    }
                }
            }
            ind.m_chromosome = arrayToBitSet(a);
            //System.out.println("after"+ind.m_chromosome.cardinality());
        }else{//unfixed chromosome length
            for (int i=0;i<nbin;i++) {
                r = randomperc();
                if (r <=pmut_bin) {
                    nbinmut++;
                    if (ind.m_chromosome.get(i)) {
                        ind.m_chromosome.clear(i);
                    } else {
                        ind.m_chromosome.set(i);
                    }
                }
            }

        }
//        int j, k;
//        double prob;
//        for (j=0; j<nbin; j++)
//        {
//            for (k=0; k<nbits[j]; k++)
//            {
//                prob = randomperc();
//                if (prob <=pmut_bin)
//                {
//                    if (ind.gene[j][k] == 0)
//                    {
//                        ind.gene[j][k] = 1;
//                    }
//                    else
//                    {
//                        ind.gene[j][k] = 0;
//                    }
//                    nbinmut+=1;
//                }
//            }
//        }
//        return;
    }

    /* Routine for real polynomial mutation of an GABitSet */
    void real_mutate_ind (GABitSet ind)
    {
        int j;
        double rnd, delta1, delta2, mut_pow, deltaq;
        double y, yl, yu, val, xy;
        for (j=0; j<nreal; j++)
        {
            if (randomperc() <= pmut_real)
            {
                y = ind.xreal[j];
                yl = min_realvar[j];
                yu = max_realvar[j];
                delta1 = (y-yl)/(yu-yl);
                delta2 = (yu-y)/(yu-yl);
                rnd = randomperc();
                mut_pow = 1.0/(eta_m+1.0);
                if (rnd <= 0.5)
                {
                    xy = 1.0-delta1;
                    val = 2.0*rnd+(1.0-2.0*rnd)*(Math.pow(xy,(eta_m+1.0)));
                    deltaq =  Math.pow(val,mut_pow) - 1.0;
                }
                else
                {
                    xy = 1.0-delta2;
                    val = 2.0*(1.0-rnd)+2.0*(rnd-0.5)*(Math.pow(xy,(eta_m+1.0)));
                    deltaq = 1.0 - (Math.pow(val,mut_pow));
                }
                y = y + deltaq*(yu-yl);
                if (y<yl)
                    y = yl;
                if (y>yu)
                    y = yu;
                ind.xreal[j] = y;
                nrealmut+=1;
            }
        }
        return;
    }

    //====================================end mutation====================================================
    //====================================sort=============================================================
    /* Randomized quick sort routine to sort a Population based on a particular objective chosen */
    void quicksort_front_obj(Population pop, int objcount, int obj_array[], int obj_array_size)
    {
        q_sort_front_obj (pop, objcount, obj_array, 0, obj_array_size-1);
        return;
    }

    /* Actual implementation of the randomized quick sort used to sort a Population based on a particular objective chosen */
    void q_sort_front_obj(Population pop, int objcount, int obj_array[], int left, int right)
    {
        int index;
        int temp;
        int i, j;
        double pivot;
        if (left<right)
        {
            index = rnd (left, right);
            temp = obj_array[right];
            obj_array[right] = obj_array[index];
            obj_array[index] = temp;
            pivot = pop.ind[obj_array[right]].obj[objcount];
            i = left-1;
            for (j=left; j<right; j++)
            {
                if (pop.ind[obj_array[j]].obj[objcount] <= pivot)
                {
                    i+=1;
                    temp = obj_array[j];
                    obj_array[j] = obj_array[i];
                    obj_array[i] = temp;
                }
            }
            index=i+1;
            temp = obj_array[index];
            obj_array[index] = obj_array[right];
            obj_array[right] = temp;
            q_sort_front_obj (pop, objcount, obj_array, left, index-1);
            q_sort_front_obj (pop, objcount, obj_array, index+1, right);
        }
        return;
    }

    /* Randomized quick sort routine to sort a Population based on crowding distance */
    void quicksort_dist(Population pop, int []dist, int front_size)
    {
        q_sort_dist (pop, dist, 0, front_size-1);
        return;
    }

    /* Actual implementation of the randomized quick sort used to sort a Population based on crowding distance */
    void q_sort_dist(Population pop, int []dist, int left, int right)
    {
        int index;
        int temp;
        int i, j;
        double pivot;
        if (left<right)
        {
            index = rnd (left, right);
            temp = dist[right];
            dist[right] = dist[index];
            dist[index] = temp;
            pivot = pop.ind[dist[right]].crowd_dist;
            i = left-1;
            for (j=left; j<right; j++)
            {
                if (pop.ind[dist[j]].crowd_dist <= pivot)
                {
                    i+=1;
                    temp = dist[j];
                    dist[j] = dist[i];
                    dist[i] = temp;
                }
            }
            index=i+1;
            temp = dist[index];
            dist[index] = dist[right];
            dist[right] = temp;
            q_sort_dist (pop, dist, left, index-1);
            q_sort_dist (pop, dist, index+1, right);
        }
        return;
    }

    //====================================end sort=========================================================
    //=====================================crowddist========================================================
    /* Routine to compute crowding distance based on ojbective function values when the Population in in the form of a List */
    void assign_crowding_distance_list (Population pop, List lst, int front_size)
    {
        int [][]obj_array;
        int []dist;
        int i, j;
        List temp;
        temp = lst;
        if (front_size==1)
        {
            pop.ind[lst.index].crowd_dist = INF;
            return;
        }
        if (front_size==2)
        {
            pop.ind[lst.index].crowd_dist = INF;
            pop.ind[lst.child.index].crowd_dist = INF;
            return;
        }
        obj_array = new int[nobj][front_size];
        dist = new int[front_size];
        for (j=0; j<front_size; j++)
        {
            dist[j] = temp.index;
            temp = temp.child;
        }
        assign_crowding_distance (pop, dist, obj_array, front_size);
        dist = null;
        obj_array = null;
        return;
    }

    /* Routine to compute crowding distance based on objective function values when the Population in in the form of an array */
    void assign_crowding_distance_indices (Population pop, int c1, int c2)
    {
        int [][]obj_array;
        int []dist;
        int i, j;
        int front_size;
        front_size = c2-c1+1;
        if (front_size==1)
        {
            pop.ind[c1].crowd_dist = INF;
            return;
        }
        if (front_size==2)
        {
            pop.ind[c1].crowd_dist = INF;
            pop.ind[c2].crowd_dist = INF;
            return;
        }
        obj_array = new int[nobj][front_size];;
        dist = new int[front_size];
        for (j=0; j<front_size; j++)
        {
            dist[j] = c1++;
        }
        assign_crowding_distance (pop, dist, obj_array, front_size);
        dist = null;
        obj_array = null;
        return;
    }

    /* Routine to compute crowding distances */
    void assign_crowding_distance (Population pop, int []dist, int [][]obj_array, int front_size)
    {
        int i, j;
        for (i=0; i<nobj; i++)
        {
            for (j=0; j<front_size; j++)
            {
                obj_array[i][j] = dist[j];
            }
            quicksort_front_obj (pop, i, obj_array[i], front_size);
        }
        for (j=0; j<front_size; j++)
        {
            pop.ind[dist[j]].crowd_dist = 0.0;
        }
        for (i=0; i<nobj; i++)
        {
            pop.ind[obj_array[i][0]].crowd_dist = INF;
        }
        for (i=0; i<nobj; i++)
        {
            for (j=1; j<front_size-1; j++)
            {
                if (pop.ind[obj_array[i][j]].crowd_dist != INF)
                {
                    if (pop.ind[obj_array[i][front_size-1]].obj[i] == pop.ind[obj_array[i][0]].obj[i])
                    {
                        pop.ind[obj_array[i][j]].crowd_dist += 0.0;
                    }
                    else
                    {
                        pop.ind[obj_array[i][j]].crowd_dist += (pop.ind[obj_array[i][j+1]].obj[i] - pop.ind[obj_array[i][j-1]].obj[i])/(pop.ind[obj_array[i][front_size-1]].obj[i] - pop.ind[obj_array[i][0]].obj[i]);
                    }
                }
            }
        }
        for (j=0; j<front_size; j++)
        {
            if (pop.ind[dist[j]].crowd_dist != INF)
            {
                pop.ind[dist[j]].crowd_dist = (pop.ind[dist[j]].crowd_dist)/nobj;
            }
        }
        return;
    }

    //===================================end crowddist=======================================================
    //=======================================decode===================================================
    /* Function to decode a Population to find out the binary variable values based on its bit pattern */
//    void decode_pop (Population pop)
//    {
//        int i;
//        if (nbin!=0)
//        {
//            for (i=0; i<popsize; i++)
//            {
//                decode_ind (pop.ind[i]);
//            }
//        }
//        return;
//    }

    /* Function to decode an GABitSet to find out the binary variable values based on its bit pattern */
//    void decode_ind (GABitSet ind)
//    {
//        int j, k;
//        int sum;
//        if (nbin!=0)
//        {
//            for (j=0; j<nbin; j++)
//            {
//                sum=0;
//                for (k=0; k<nbits[j]; k++)
//                {
//                    if (ind.gene[j][k]==1)
//                    {
//                        sum += Math.pow(2,nbits[j]-1-k);
//                    }
//                }
//                ind.xbin[j] = min_binvar[j] + (double)sum*(max_binvar[j] - min_binvar[j])/(double)(Math.pow(2,nbits[j])-1);
//            }
//        }
//        return;
//    }

    //========================================end decode==============================================
    //=========================================dominance==========================================
    /* Routine for usual non-domination checking
        It will return the following values
        1 if a dominates b
        -1 if b dominates a
        0 if both a and b are non-dominated */

    int check_dominance (GABitSet a, GABitSet b)
    {
        int i;
        int flag1;
        int flag2;
        flag1 = 0;
        flag2 = 0;
        if (a.constr_violation<0 && b.constr_violation<0)
        {
            if (a.constr_violation > b.constr_violation)
            {
                return (1);
            }
            else
            {
                if (a.constr_violation < b.constr_violation)
                {
                    return (-1);
                }
                else
                {
                    return (0);
                }
            }
        }
        else
        {
            if (a.constr_violation < 0 && b.constr_violation == 0)
            {
                return (-1);
            }
            else
            {
                if (a.constr_violation == 0 && b.constr_violation <0)
                {
                    return (1);
                }
                else
                {
                    for (i=0; i<nobj; i++)
                    {
                        if (a.obj[i] < b.obj[i])
                        {
                            flag1 = 1;

                        }
                        else
                        {
                            if (a.obj[i] > b.obj[i])
                            {
                                flag2 = 1;
                            }
                        }
                    }
                    if (flag1==1 && flag2==0)
                    {
                        return (1);
                    }
                    else
                    {
                        if (flag1==0 && flag2==1)
                        {
                            return (-1);
                        }
                        else
                        {
                            return (0);
                        }
                    }
                }
            }
        }
    }

    //=========================================end dominance=====================================
    //========================local search=====================
    //should be called after population sorted
    //apply local search to the front 1 when scope = 0;
    private Population localSearch(Population pop)throws Exception{

        GABitSet bestclone[];
        int numCandidate = 1;
        if(m_localSearchScope <=0 || m_localSearchScope >= pop.ind.length){
            numCandidate = pop.ind.length;
        }else{
            numCandidate = m_localSearchScope;
        }
        bestclone = new GABitSet[numCandidate];
        Population p = new Population();
        int i,j;
        for (i = 0,j=0; i < pop.ind.length && j < numCandidate; i++) {
            if(m_localSearchScope < 0){//apply local search only on front 1
                if(pop.ind[i].rank>-m_localSearchScope) continue;
            }



            Random r = new Random();
            GABitSet tmp;
            if(m_localSearch == 1){//random objective weights
                double sum = 0;
                weights = new double[nobj];
                for (int k = 0; k < nobj; k++) {
                    weights[k] = r.nextDouble();
                    sum += weights[k];
                }
                for (int k = 0; k < nobj; k++) {
                    weights[k] /= sum;
                }
                tmp = m_localSearchMethod.search((GABitSet)(pop.ind[i].clone()));
            }else{//random objective
                //lsObjective = r.nextInt(m_minNBin==m_maxNBin ? nobj : nobj-1);
                lsObjective = r.nextInt(m_multiClass<3 ? nobj : nobj-1);
                tmp = m_lss[lsObjective].search((GABitSet)(pop.ind[i].clone()));
            }


            if(!tmp.getChromosome().equals(pop.ind[i].getChromosome())){
                bestclone[j] = tmp;
                j++;
            }
        }
        p.ind = new GABitSet[j];
        System.arraycopy(bestclone,0,p.ind,0,j);
        return p;
    }
    //========================================================

    //==========================================eval=============================================
    /* Routine to evaluate objective function values and constraints for a Population */
    void evaluate_pop (Population pop) throws Exception
    {
//        int i;
//        for (i=0; i<popsize; i++)
//        {
//            evaluate_ind (pop.ind[i]);
//        }

        calculateFitness(ASEvaluator,pop.ind);
        return;
    }

    public void calculateFitness(SubsetEvaluator eval,GABitSet [] gabs) throws Exception{
        for (int i = 0; i < gabs.length; i++) {
            switch(i%2){
                case 0:
                    System.out.print("-"); break;
                case 1:
                    System.out.print("*"); break;
                default: break;
            }
            if(m_lookupTable.containsKey(gabs[i].getChromosome())==false){
                evaluate_ind (gabs[i], eval);
                m_lookupTable.put(gabs[i].getChromosome(),gabs[i]);
            }else{
                gabs[i] = (GABitSet)m_lookupTable.get(gabs[i].getChromosome());
            }
        }
    }
    /* Routine to evaluate objective function values and constraints for an GABitSet */
    void evaluate_ind (GABitSet ind,SubsetEvaluator eval)
    {
        int j;

        test_problem (ind.xreal, ind.m_chromosome, ind.obj, ind.constr,eval);
        numCallingEvaluator ++;



        if (ncon==0)
        {
            ind.constr_violation = 0.0;
        }
        else
        {
            ind.constr_violation = 0.0;
            for (j=0; j<ncon; j++)
            {
                if (ind.constr[j]<0.0)
                {
                    ind.constr_violation += ind.constr[j];
                }
            }
        }
        return;
    }

    public int compareGABitSet(GABitSet a,GABitSet b){
        if(m_localSearch == 1){
            double suma = 0, sumb = 0;
            for (int i = 0; i < nobj; i++) {
                suma += a.obj[i]*weights[i];
                sumb += b.obj[i]*weights[i];
            }
            if(suma<sumb){
                return 1;
            }else if(suma>sumb){
                return -1;
            }else{
                return 0;
            }
        }else{
            //if(m_minNBin != m_maxNBin && Math.abs(a.obj[lsObjective]-b.obj[lsObjective])<1.0/m_data.numInstances()){
            if(Math.abs(a.obj[lsObjective]-b.obj[lsObjective])<1.0/m_data.numInstances()){
                if(m_multiClass>=3){
                    if(a.obj[nobj-1]<b.obj[nobj-1]){
                        return 1;
                    }else if(a.obj[nobj-1]<b.obj[nobj-1]){
                        return -1;
                    }else{
                        return 0;
                    }
                }else{
                    if(a.getChromosome().cardinality()<b.getChromosome().cardinality()){
                        return 1;
                    }else if(a.getChromosome().cardinality()>b.getChromosome().cardinality()){
                        return -1;
                    }else{
                        return 0;
                    }

                }
            }
            if(a.obj[lsObjective] < b.obj[lsObjective]){
                return 1;
            }else if(a.obj[lsObjective] > b.obj[lsObjective]){
                return -1;
            }else{
                return 0;
            }
        }
    }


    //=========================================end eval==========================================
    //=========================================List=============================================
    /* Insert an element X into the List at location specified by NODE */
    void insert (List node, int x)
    {
        List temp;
        if (node==null)
        {
            System.out.print("\n Error!! asked to enter after a null pointer, hence exiting \n");
            System.exit(1);
        }
        temp = new List();
        temp.index = x;
        temp.child = node.child;
        temp.parent = node;
        if (node.child != null)
        {
            node.child.parent = temp;
        }
        node.child = temp;
        return;
    }

    /* Delete the node NODE from the List */
    List del (List node)
    {
        List temp;
        if (node==null)
        {
            System.out.print("\n Error!! asked to delete a null pointer, hence exiting \n");
            System.exit(1);
        }
        temp = node.parent;
        temp.child = node.child;
        if (temp.child!=null)
        {
            temp.child.parent = temp;
        }
        node=null;
        return (temp);
    }

    //==========================================end List=========================================
    //==========================================merge=========================================
    /* Routine to merge two populations into one */
    void merge(Population pop1, Population pop2, Population pop3)
    {
        int i, k;
        for (i=0; i<pop1.ind.length; i++)
        {
            copy_ind (pop1.ind[i], pop3.ind[i]);
        }
        for (i=0, k=pop1.ind.length; i<pop2.ind.length; i++, k++)
        {
            copy_ind (pop2.ind[i], pop3.ind[k]);
        }
        return;
    }

    /* Routine to copy an GABitSet 'ind1' into another GABitSet 'ind2' */
    void copy_ind (GABitSet ind1, GABitSet ind2)
    {
        int i, j;
        ind2.rank = ind1.rank;
        ind2.constr_violation = ind1.constr_violation;
        ind2.crowd_dist = ind1.crowd_dist;
        if (nreal!=0)
        {
            for (i=0; i<nreal; i++)
            {
                ind2.xreal[i] = ind1.xreal[i];
            }
        }
        if (nbin!=0)
        {
            ind2.m_chromosome = (BitSet)ind1.m_chromosome.clone();
//            for (i=0; i<nbin; i++)
//            {
//                ind2.xbin[i] = ind1.xbin[i];
//                for (j=0; j<nbits[i]; j++)
//                {
//                    ind2.gene[i][j] = ind1.gene[i][j];
//                }
//            }

        }
        for (i=0; i<nobj; i++)
        {
            ind2.obj[i] = ind1.obj[i];
        }
        if (ncon!=0)
        {
            for (i=0; i<ncon; i++)
            {
                ind2.constr[i] = ind1.constr[i];
            }
        }
        return;
    }

    //==========================================end merge=======================================
    //=======================================fillnds=============================================
    /* Routine to perform non-dominated sorting */
    void fill_nondominated_sort (Population mixed_pop, Population new_pop)
    {
        int flag;
        int i, j;
        int end;
        int front_size;
        int archieve_size;
        int rank=1;
        List pool;
        List elite;
        List temp1, temp2;
        pool = new List();
        elite = new List();
        front_size = 0;
        archieve_size=0;
        pool.index = -1;
        pool.parent = null;
        pool.child = null;
        elite.index = -1;
        elite.parent = null;
        elite.child = null;
        temp1 = pool;
        for (i=0; i<mixed_pop.ind.length; i++)
        {
            insert (temp1,i);
            temp1 = temp1.child;
        }
        i=0;
        do
        {
            temp1 = pool.child;
            insert (elite, temp1.index);
            front_size = 1;
            temp2 = elite.child;
            temp1 = del (temp1);
            temp1 = temp1.child;
            do
            {
                temp2 = elite.child;
                if (temp1==null)
                {
                    break;
                }
                do
                {
                    end = 0;
                    flag = check_dominance (mixed_pop.ind[temp1.index], mixed_pop.ind[temp2.index]);
                    if (flag == 1)
                    {
                        insert (pool, temp2.index);
                        temp2 = del (temp2);
                        front_size--;
                        temp2 = temp2.child;
                    }
                    if (flag == 0)
                    {
                        temp2 = temp2.child;
                    }
                    if (flag == -1)
                    {
                        end = 1;
                    }
                }while (end!=1 && temp2!=null);
                if (flag == 0 || flag == 1)
                {
                    insert (elite, temp1.index);
                    front_size++;
                    temp1 = del (temp1);
                }
                temp1 = temp1.child;
            }while (temp1 != null);
            temp2 = elite.child;
            j=i;
            if ( (archieve_size+front_size) <= new_pop.ind.length)
            {
                do
                {
                    copy_ind (mixed_pop.ind[temp2.index], new_pop.ind[i]);
                    new_pop.ind[i].rank = rank;
                    archieve_size+=1;
                    temp2 = temp2.child;
                    i+=1;
                }while (temp2 != null);
                assign_crowding_distance_indices (new_pop, j, i-1);
                rank+=1;
            }else{
                crowding_fill (mixed_pop, new_pop, i, front_size, elite);
                archieve_size = new_pop.ind.length;
                for (j=i; j<new_pop.ind.length; j++)
                {
                    new_pop.ind[j].rank = rank;
                }
            }
            temp2 = elite.child;
            do
            {
                temp2 = del (temp2);
                temp2 = temp2.child;
            }while (elite.child !=null);
        }while (archieve_size < new_pop.ind.length);
        while (pool!=null)
        {
            temp1 = pool;
            pool = pool.child;
            temp1 = null;
        }
        while (elite!=null)
        {
            temp1 = elite;
            elite = elite.child;
            temp1 = null;
        }

    }

    /* Routine to fill a Population with individuals in the decreasing order of crowding distance */
    void crowding_fill (Population mixed_pop, Population new_pop, int count, int front_size, List elite)
    {
        int []dist;
        List temp;
        int i, j;
        assign_crowding_distance_list (mixed_pop, elite.child, front_size);
        dist = new int[front_size];
        temp = elite.child;
        for (j=0; j<front_size; j++)
        {
            dist[j] = temp.index;
            temp = temp.child;
        }
        quicksort_dist(mixed_pop, dist, front_size);

        for (i = count, j = front_size - 1; i < new_pop.ind.length; i++, j--) {
            copy_ind(mixed_pop.ind[dist[j]], new_pop.ind[i]);

        }


        dist = null;
        return;
    }

    //=======================================end fillnds=========================================
    //==========================================initialize=======================================
    /* Function to initialize a Population randomly */
    void initialize_pop (Population pop)
    {
        int i;
        for (i=0; i<popsize; i++)
        {
            initialize_ind (pop.ind[i]);
        }
        return;
    }

    /* Function to initialize an GABitSet randomly */
    void initialize_ind (GABitSet ind)
    {
        int j, k;
        if (nreal!=0)
        {
            for (j=0; j<nreal; j++)
            {
                ind.xreal[j] = rndreal (min_realvar[j], max_realvar[j]);
            }
        }
        if (nbin!=0)
        {
            if(m_maxNBin < nbin || m_minNBin > 1){//limited number of bins
                int num_bit = rnd(m_minNBin,m_maxNBin);
                for (int i = 0; i < num_bit; i++) {
                    int toset = rnd(0,nbin-1);
                    while(ind.m_chromosome.get(toset)){
                        toset = (toset+1)%nbin;
                    }
                    ind.m_chromosome.set(toset);
                }
            }else{
                for (j=0; j<nbin; j++)
                {
//                for (k=0; k<nbits[j]; k++)
//                {
//                    if (randomperc() <= 0.5)
//                    {
//                        ind.gene[j][k] = 0;
//                    }
//                    else
//                    {
//                        ind.gene[j][k] = 1;
//                    }
//                }
                        if(randomperc()<=0.5){
                            ind.m_chromosome.set(j);
                        }
                }


            }

        }

        return;
    }

    //========================================end initialize=====================================
    //=========================================rank================================================
    /* Function to assign rank and crowding distance to a Population of size pop_size*/
    void assign_rank_and_crowding_distance (Population new_pop)
    {
        int flag;
        int i;
        int end;
        int front_size;
        int rank=1;
        List orig;
        List cur;
        List temp1, temp2;
        orig = new List();
        cur = new List();
        front_size = 0;
        orig.index = -1;
        orig.parent = null;
        orig.child = null;
        cur.index = -1;
        cur.parent = null;
        cur.child = null;
        temp1 = orig;
        for (i=0; i<popsize; i++)
        //for (i=0; i<new_pop.ind.length; i++)
        {
            insert (temp1,i);
            temp1 = temp1.child;
        }
        do
        {
            if (orig.child.child == null)
            {
                new_pop.ind[orig.child.index].rank = rank;
                new_pop.ind[orig.child.index].crowd_dist = INF;
                break;
            }
            temp1 = orig.child;
            insert (cur, temp1.index);
            front_size = 1;
            temp2 = cur.child;
            temp1 = del (temp1);
            temp1 = temp1.child;
            do
            {
                temp2 = cur.child;
                do
                {
                    end = 0;
                    flag = check_dominance (new_pop.ind[temp1.index], new_pop.ind[temp2.index]);
                    if (flag == 1)
                    {
                        insert (orig, temp2.index);
                        temp2 = del (temp2);
                        front_size--;
                        temp2 = temp2.child;
                    }
                    if (flag == 0)
                    {
                        temp2 = temp2.child;
                    }
                    if (flag == -1)
                    {
                        end = 1;
                    }
                }while (end!=1 && temp2!=null);
                if (flag == 0 || flag == 1)
                {
                    insert (cur, temp1.index);
                    front_size++;
                    temp1 = del (temp1);
                }
                temp1 = temp1.child;
            }while (temp1 != null);
            temp2 = cur.child;
            do
            {
                new_pop.ind[temp2.index].rank = rank;
                temp2 = temp2.child;
            }while (temp2 != null);
            assign_crowding_distance_list (new_pop, cur.child, front_size);
            temp2 = cur.child;
            do
            {
                temp2 = del (temp2);
                temp2 = temp2.child;
            }while (cur.child !=null);
            rank+=1;
        }while (orig.child!=null);
        orig=null;
        cur=null;
        return;
    }

    //=========================================end rank=============================================
    //===========================================tourselect=========================================
    /* Routine for tournament selection, it creates a new_pop from old_pop by performing tournament selection and the crossover */
    void selection (Population old_pop, Population new_pop)
    {
        int []a1;
        int []a2;
        int temp;
        int i;
        int rand;
        GABitSet parent1, parent2;
        a1 = new int[popsize];
        a2 = new int[popsize];
        for (i=0; i<popsize; i++)
        {
            a1[i] = a2[i] = i;
        }
        for (i=0; i<popsize; i++)
        {
            rand = rnd (i, popsize-1);
            temp = a1[rand];
            a1[rand] = a1[i];
            a1[i] = temp;
            rand = rnd (i, popsize-1);
            temp = a2[rand];
            a2[rand] = a2[i];
            a2[i] = temp;
        }
        for (i=0; i<popsize; i+=4)
        {
            parent1 = tournament (old_pop.ind[a1[i]], old_pop.ind[a1[i+1]]);
            parent2 = tournament (old_pop.ind[a1[i+2]], old_pop.ind[a1[i+3]]);
            crossover (parent1, parent2, new_pop.ind[i], new_pop.ind[i+1]);
            parent1 = tournament (old_pop.ind[a2[i]], old_pop.ind[a2[i+1]]);
            parent2 = tournament (old_pop.ind[a2[i+2]], old_pop.ind[a2[i+3]]);
            crossover (parent1, parent2, new_pop.ind[i+2], new_pop.ind[i+3]);
        }
        a1=null;a2=null;
        return;
    }

    /* Routine for binary tournament */
    GABitSet tournament (GABitSet ind1, GABitSet ind2)
    {
        int flag;
        flag = check_dominance (ind1, ind2);
        if (flag==1)
        {
            return (ind1);
        }
        if (flag==-1)
        {
            return (ind2);
        }
        if (ind1.crowd_dist > ind2.crowd_dist)
        {
            return(ind1);
        }
        if (ind2.crowd_dist > ind1.crowd_dist)
        {
            return(ind2);
        }
        if ((randomperc()) <= 0.5)
        {
            return(ind1);
        }
        else
        {
            return(ind2);
        }
    }

    //==============================================end tourselect=====================================
    //=============================================report==============================================
    /* Function to print the information of a Population in a file */
    public String report_pop (Population pop) throws Exception
    {
        int i, j, k;
        StringBuffer s = new StringBuffer();
        for (i=0; i<popsize; i++)
        {
            for (j=0; j<nobj; j++)
            {
                s.append(Utils.doubleToString(pop.ind[i].obj[j],7,4)+"\t");
            }
            if (ncon!=0)
            {
                for (j=0; j<ncon; j++)
                {
                    s.append(pop.ind[i].constr[j]+"\t");
                }
            }
            s.append(pop.ind[i].constr_violation+"\t");
            s.append(pop.ind[i].rank+"\t");
            s.append(Utils.doubleToString(pop.ind[i].crowd_dist,5)+"\t");

            if (nreal!=0)
            {
                for (j=0; j<nreal; j++)
                {
                    s.append(pop.ind[i].xreal[j]+"\t");
                }
            }
            if (nbin!=0)
            {
                 s.append(pop.ind[i].m_chromosome.toString());
//                for (j=0; j<nbin; j++)
//                {
//                    for (k=0; k<nbits[j]; k++)
//                    {
//                        w.write(pop.ind[i].gene[j][k]+"\t");
//                    }
//                }
            }
             s.append("\n");

        }
        return s.toString();
    }

    /* Function to print the information of feasible and non-dominated Population in a file */
    public String report_feasible (Population pop) throws Exception
    {
        int i, j;
        StringBuffer s = new StringBuffer();
        GABitSet bestSolution = new GABitSet();
        //GABitSet bestSolutionMulticlass[] = new GABitSet[m_minNBin==m_maxNBin ? nobj : nobj-1];
        GABitSet bestSolutionMulticlass[] = new GABitSet[m_multiClass<3 ? nobj : nobj-1];
        bestSolution.obj = new double[]{Double.MAX_VALUE,Double.MAX_VALUE};
        outputSolution.obj = new double[]{Double.MAX_VALUE,Double.MAX_VALUE};
        bestAttributes = new int[popsize][];
        if(m_multiClass>0){
            //bestAttributesMulticlass = new int[m_minNBin==m_maxNBin ? nobj : nobj-1][];
            bestAttributesMulticlass = new int[m_multiClass<3 ? nobj : nobj-1][];
            //for (int k = 0; k < (m_minNBin==m_maxNBin ? nobj : nobj-1); k++) {
            for (int k = 0; k < (m_multiClass<3 ? nobj : nobj-1); k++) {
                bestSolutionMulticlass[k] = new GABitSet();
                bestSolutionMulticlass[k].obj = new double[nobj];
                Arrays.fill(bestSolutionMulticlass[k].obj,Double.MAX_VALUE);
            }
        }

        for (i=0; i<popsize; i++)
        {
            if (pop.ind[i].constr_violation == 0.0 && pop.ind[i].rank==1)
            {
                for (j=0; j<nobj; j++)
                {
                    s.append(Utils.doubleToString(pop.ind[i].obj[j],7,4)+"\t");
                }
                if (ncon!=0)
                {
                    for (j=0; j<ncon; j++)
                    {
                        s.append(pop.ind[i].constr[j]+"\t");
                    }
                }
                s.append(pop.ind[i].constr_violation+"\t");
                s.append(pop.ind[i].rank+"\t");
                s.append(Utils.doubleToString(pop.ind[i].crowd_dist,5)+"\t");

                if (nreal!=0)
                {
                    for (j=0; j<nreal; j++)
                    {
                        s.append(pop.ind[i].xreal[j]+"\t");
                    }
                }
                if (nbin!=0)
                {
                    s.append(pop.ind[i].m_chromosome.toString());
                    bestAttributes[i] = bitSetToArray(pop.ind[i].m_chromosome,pop.ind[i].m_chromosome.cardinality());
                    if(m_multiClass>0){
                        //for (int k = 0; k < (m_minNBin==m_maxNBin ? nobj : nobj-1); k++) {
                        for (int k = 0; k < (m_multiClass<3 ? nobj : nobj-1); k++) {
                            if(pop.ind[i].crowd_dist==INF){
                                if(pop.ind[i].obj[k]<bestSolutionMulticlass[k].obj[k]){
                                    bestSolutionMulticlass[k] = pop.ind[i];
                                //}else if(m_minNBin!=m_maxNBin){
                                }else if(m_multiClass >=3){
                                    if(pop.ind[i].obj[k]==bestSolutionMulticlass[k].obj[k] && pop.ind[i].obj[nobj-1]<bestSolutionMulticlass[k].obj[nobj-1]){
                                        bestSolutionMulticlass[k] = pop.ind[i];
                                    }
                                }
                            }
                        }
                    }else{
                        //if(m_minNBin!=m_maxNBin){
                        if(m_multiClass >=3){
                            if (pop.ind[i].obj[1] > bestSolution.obj[1]) {
                                outputSolution = bestSolution;
                                bestSolution = pop.ind[i];
                            }
                            if (pop.ind[i].obj[1] > outputSolution.obj[1] &&
                                pop.ind[i].obj[1] < bestSolution.obj[1]) {
                                outputSolution = pop.ind[i];
                            }
                        }
                    }
//                    for (j=0; j<nbin; j++)
//                    {
//                        for (k=0; k<nbits[j]; k++)
//                        {
//                            w.write(pop.ind[i].gene[j][k]+"\t");
//                        }
//                    }
                }
                s.append("\n");
            }
        }
        if(m_multiClass>0){
            outputSolution = new GABitSet();
            //for (int k = 0; k < (m_minNBin==m_maxNBin ? nobj : nobj-1); k++) {
            for (int k = 0; k < (m_multiClass<3? nobj : nobj-1); k++) {
                bestAttributesMulticlass[k] = bitSetToArray(bestSolutionMulticlass[k].m_chromosome,bestSolutionMulticlass[k].m_chromosome.cardinality());
                outputSolution.m_chromosome.or(bestSolutionMulticlass[k].m_chromosome);
                s.append("The best solution for class "+(k+1)+" is:"+bestSolutionMulticlass[k].m_chromosome.toString()+"\n");
            }
        }
        return s.toString();
    }

    //=============================================end report===========================================

    //=========================================problemdef========================================
    /*  Test problem ZDT6
         # of real variables = 10
    # of bin variables = 0
    # of objectives = 2
    # of constraints = 0*/
//    void test_problem (double []xreal, BitSet c, double []obj, double []constr)
//    {
//        double f1, f2, g, h;
//        int i;
//        f1 = 1.0 - (Math.exp(-4.0*xreal[0]))*Math.pow((Math.sin(4.0*PI*xreal[0])),6.0);
//        g = 0.0;
//        for (i=1; i<10; i++)
//        {
//            g += xreal[i];
//        }
//        g = g/9.0;
//        g = Math.pow(g,0.25);
//        g = 1.0 + 9.0*g;
//        h = 1.0 - Math.pow((f1/g),2.0);
//        f2 = g*h;
//        obj[0] = f1;
//        obj[1] = f2;
//        return;
//    }
     void test_problem (double []xreal, BitSet c, double []obj, double []constr, SubsetEvaluator eval){
         try {
             if(m_multiClass>0){
                 WrapperSubsetEval wse = (WrapperSubsetEval)eval;
                 wse.evaluateSubset(c);
                 MultiClassClassifier mcc = (MultiClassClassifier)wse.getClassifier();
                 //for (int i = 0; i < (m_minNBin==m_maxNBin ? nobj : nobj-1); i++) {
                 for (int i = 0; i < (m_multiClass<3 ? nobj : nobj-1); i++) {
                     if(wse.m_fitnessType == WrapperSubsetEval.RMB){
                         if(mcc.getClassifiers()[i] instanceof SMO){
                             obj[i] = ((SMO) mcc.getClassifiers()[i]).
                                      getRadiusMarginBound();
                         }else{
                             obj[i] = ((LibSVM) mcc.getClassifiers()[i]).getRMB();
                         }
                     }else if(wse.m_fitnessType == WrapperSubsetEval.P){
                         obj[i] = -wse.m_Evaluation.precision(i);
                     }else if(wse.m_fitnessType == WrapperSubsetEval.R){
                         obj[i] = -wse.m_Evaluation.recall(i);
                     }else if(wse.m_fitnessType == WrapperSubsetEval.FM){
                         obj[i] = -wse.m_Evaluation.fMeasure(i);
                     }else{
                         throw new Exception("This type fitness is not suitable on Multiojectives");
                     }
                 }

             }else{
                 obj[0] = -eval.evaluateSubset(c);
             }
             //if(m_minNBin!=m_maxNBin){
             if(m_multiClass>=3){
                 double sf = m_maxNBin;
                 obj[nobj - 1] = c.cardinality() / sf;
             }
         } catch (Exception ex) {
             System.out.println("objective function not finished yet");
             ex.printStackTrace();
         }
     }


    //=========================================end problemdef====================================



    public NSGAII() {
    }

    public String toString(){
        StringBuffer s = new StringBuffer();
        s.append("\t Population size = "+popsize);
        s.append("\n\t Number of generations = "+ngen);
        s.append("\n\t Number of bit = "+ nbin);
        s.append("\n\t Probability of crossover = " + pcross_bin);
        s.append("\n\t Probability of mutation = " + pmut_bin);
        s.append("\n\t Number of crossover of binary variable = "+nbincross);
        s.append("\n\t Number of mutation of binary variable = "+nbinmut);
        s.append("\n\t Running time = "+m_runningTime);
        s.append("\n\t Num of max 1 bits = "+m_maxNBin);
        s.append("\n\t Num of min 1 bits = "+m_minNBin);
        s.append("\n\t Evaluator = "+ASEvaluator.getClass().getName());
        s.append("\n\t Use Local search = "+m_localSearch);
        s.append("\n\t Max num of Evaluation = "+m_maxEvaluation);
        s.append("\n\t Exact Num of calling classification = "+numCallingEvaluator);
        s.append("# The following is the initialization of Population:\n");
        s.append("# of objectives = "+nobj+"# of constraints = "+ncon+", constr_violation, rank, crowding_distance, # of real_var = "+nreal+", # of bits of bin_var = "+bitlength+"\n");
        s.append(initials);
        s.append("# The following is the best solution found:\n");
        s.append("# of objectives = "+nobj+"# of constraints = "+ncon+", constr_violation, rank, crowding_distance, # of real_var = "+nreal+", # of bits of bin_var = "+bitlength+"\n");
        s.append("#=======================================================#\n");
        s.append(bests);
        s.append("#=======================================================#\n");
        return s.toString();
    }



    public int [] search(ASEvaluation ASEval, Instances data) throws Exception{
        Random r = new Random();
        seed = r.nextDouble();
        if (!(ASEval instanceof SubsetEvaluator)) {
            throw  new Exception(ASEval.getClass().getName()
                                 + " is not a "
                                 + "Subset evaluator!");
        }else{
            ASEvaluator = (SubsetEvaluator) ASEval;
        }
        m_lookupTable = new Hashtable(m_lookupTableSize);
        m_data = data;
        long startTime = System.currentTimeMillis();
        nbin = m_data.numAttributes()-1;
        if(m_minNBin < 1) m_minNBin = 1;
        if(m_minNBin > nbin) m_minNBin = nbin;
        if(m_maxNBin > nbin) m_maxNBin = nbin;
        if(m_maxNBin < 0) m_maxNBin = nbin;

        nbinmut = 0;
        nrealmut = 0;
        nbincross = 0;
        nrealcross = 0;
        if(m_multiClass == NONE){
            nobj = 2;
        }else if(m_multiClass == OVA1){
            nobj = m_data.numClasses()+1;
        }else if(m_multiClass == OVA){
            nobj = m_data.numClasses();
        }else if(m_multiClass == OVO1){
            nobj = m_data.numClasses()*(m_data.numClasses()-1)/2+1;
        }else{
            nobj = m_data.numClasses()*(m_data.numClasses()-1)/2;
        }
//        if(m_minNBin == m_maxNBin){
//            nobj--;
//        }
        Population parent_pop;
        Population child_pop;
        Population mixed_pop;
        Population localsearch_pop;
        Population tri_pop = new Population();
        parent_pop = new Population();
        child_pop = new Population();
        mixed_pop = new Population();
        allocate_memory_pop (parent_pop, popsize);
        allocate_memory_pop (child_pop, popsize);
        allocate_memory_pop (mixed_pop, 2*popsize);
        randomize();
        numCallingEvaluator = 0;
        if (m_localSearch==1){
            m_localSearchMethod.buildLocalSearch(data,m_minNBin,m_maxNBin,this,ASEvaluator);
        }else if(m_localSearch ==2){
            m_lss = buildLss(data);
        }

        initialize_pop (parent_pop);
        evaluate_pop (parent_pop);
        assign_rank_and_crowding_distance (parent_pop);
        initials = report_pop(parent_pop);
        System.out.println("\ndata: "+m_data.relationName()+"gen = 1");
        for (int i=2; i<=ngen && numCallingEvaluator<m_maxEvaluation; i++)
        {
            selection (parent_pop, child_pop);
            mutation_pop (child_pop);
            evaluate_pop(child_pop);
            merge (parent_pop, child_pop, mixed_pop);
            fill_nondominated_sort (mixed_pop, parent_pop);
            if(m_localSearch>0){
                //fill_nondominated_sort(mixed_pop,mixed_pop);
                localsearch_pop = localSearch(parent_pop);
                allocate_memory_pop (tri_pop, parent_pop.ind.length+localsearch_pop.ind.length);
                merge(localsearch_pop,parent_pop,tri_pop);
                fill_nondominated_sort (tri_pop, parent_pop);
            }
            System.out.println("\ndata: "+m_data.relationName()+" gen = "+i+"\tnumCallingEval = "+numCallingEvaluator);
        }

        bests = report_feasible(parent_pop); //necessary

        m_runningTime = System.currentTimeMillis()-startTime;

        //return bitSetToArray(outputSolution.m_chromosome,outputSolution.m_chromosome.cardinality());
        int noneSelected[] = {m_data.classIndex()};

        return noneSelected;
    }


    public static void main(String [] args) throws Exception{
        //NSGAII nsga2 = new NSGAII();
        //nsga2.run(args);
        double x[] = {0,0,0,0.022571429,0,0.021793103,0,0.045142857,0,0.01975,0,0.021066667,0,0.040774194,0,0.018588235,0.021066667,0.024307692,0,0.022571429,0,0,0,0.0395,0,0,0,0.021793103,0,0};
        double y[] = {0,0,0,0,0,0,0.021066667,0,0,0,0,0,0,0,0.021066667,0,0.020387097,0,0,0.022571429,0,0.023407407,0.018588235,0,0,0.021793103,0.03830303,0.01975,0,0.023407407};
        double p = Utils.randomPermutationTest(x,y,1,10000);
        System.out.println(p);
    }

    private int[] bitSetToArray(BitSet bs,int length){
        int [] bsa = new int[length];
        int j = 0;
        for (int i = 0; i < nbin; i++) {
            if(bs.get(i)){
                bsa[j++] = i;
            }
        }
        for(;j<length;j++){
            bsa[j] = -1;
        }
        return bsa;
    }

    private BitSet arrayToBitSet(int bsa []){

        BitSet bs = new BitSet();
        for (int i = 0; i < bsa.length; i++) {
            if(bsa[i] != -1){
                bs.set(bsa[i]);
            }
        }
        return bs;
    }


    public String[] getOptions(){
        String[] localHeuristicOptions = new String[0];
        if ((m_localSearchMethod != null) &&
            (m_localSearchMethod instanceof OptionHandler)) {
            localHeuristicOptions = ((OptionHandler)m_localSearchMethod).getOptions();
        }


        String[] options = new String[57];
        int current = 0;

        if (getLocalSearchMethod() != null) {
            options[current++] = "-L";
            options[current++] = getLocalSearchMethod().getClass().getName();
        }
        options[current++] = "-W";
        options[current++] = "" + getLocalSearchScope();
        options[current++] = "-P";
        options[current++] = "" + getPopSize();
        options[current++] = "-G";
        options[current++] = "" + getNGen();
        options[current++] = "-C";
        options[current++] = "" + getPCross();
        options[current++] = "-M";
        options[current++] = "" + getPMut();
        options[current++] = "-B";
        options[current++] = "" + getMaxNBin();
        options[current++] = "-A";
        options[current++] = "" + getMinNBin();
        options[current++] = "-J";
        options[current++] = "" + getMaxEvaluation();
        options[current++] = "-T";
        options[current++] = "" + m_multiClass;
        options[current++] = "-H";
        options[current++] = "" + m_localSearch;
        options[current++] = "-E";
        options[current++] = "" + m_ensembleStrategy;





        options[current++] = "--";
        System.arraycopy(localHeuristicOptions, 0, options, current,
                         localHeuristicOptions.length);
        current += localHeuristicOptions.length;

        while (current < options.length) {
            options[current++] = "";
        }
        return options;
    }

    public void setOptions(String[] options) throws Exception{
        String optionString;
        optionString = Utils.getOption('L', options);
        setLocalSearchMethod(GALocalSearch.forName(optionString,Utils.partitionOptions(options)));
        optionString = Utils.getOption('C', options);
        if (optionString.length() != 0) {
            setPCross(Double.parseDouble(optionString));
        }
        optionString = Utils.getOption('M', options);
        if (optionString.length() != 0) {
            setPMut(Double.parseDouble(optionString));
        }
        optionString = Utils.getOption('P', options);
        if (optionString.length() != 0) {
            int p = Integer.parseInt(optionString);
            if(p%4!=0){
                throw new Exception("Population size must be a multiple of 4!");
            }else{
                setPopSize(p);
            }
        }
        optionString = Utils.getOption('G', options);
        if (optionString.length() != 0) {
            setNGen(Integer.parseInt(optionString));
        }
        optionString = Utils.getOption('B', options);
        if (optionString.length() != 0) {
            setMaxNBin(Integer.parseInt(optionString));
        }
        optionString = Utils.getOption('A', options);
        if (optionString.length() != 0) {
            setMinNBin(Integer.parseInt(optionString));
        }


        optionString = Utils.getOption('H', options);
        if (optionString.length() != 0){
            setLocalSearch(
                new SelectedTag(Integer.parseInt(optionString), TAGS_LOCALSEARCH));
        }else{
            setLocalSearch(
                new SelectedTag(NONE, TAGS_LOCALSEARCH));
        }

        optionString = Utils.getOption('E', options);
        if (optionString.length() != 0){
            setEnsembleStrategy(
                new SelectedTag(Integer.parseInt(optionString), TAGS_ENSEMBLESTRATEGY));
        }

        optionString = Utils.getOption('T', options);
        if (optionString.length() != 0){
            setMultiClass(
                new SelectedTag(Integer.parseInt(optionString), TAGS_MULTI));
        }else{
            setMultiClass(
                new SelectedTag(NONE, TAGS_MULTI));
        }
        optionString = Utils.getOption('W', options);
        if (optionString.length() != 0) {
            setLocalSearchScope((new Integer(optionString)).intValue());
        }
        optionString = Utils.getOption('J', options);
        if (optionString.length() != 0) {
            setMaxEvaluation(Long.parseLong(optionString));
        }
        Utils.checkForRemainingOptions(options);
    }

    public Enumeration listOptions(){
        Vector newVector = new Vector(12);
        newVector.addElement(new Option("\tSpecify Population size.","P",1,"-P <number>"));
        newVector.addElement(new Option("\tSpecify number of generation.","G",1,"-G <number>"));
        newVector.addElement(new Option("\tSpecify possibility of crossover.","C",1,"-C <number>"));
        newVector.addElement(new Option("\tSpecify possibility of mutation.","M",1,"-M <number>"));
        newVector.addElement(new Option("\tSpecify Max number of bit.","B",1,"-B <number>"));
        newVector.addElement(new Option("\tSpecify Min number of bit.","A",1,"-A <number>"));
        newVector.addElement(new Option("\tSet Local Search Type.(default = false)", "H",1, "-H <num>"));
        newVector.addElement(new Option("\tSet Ensemble Strategy.(default = false)", "E",1, "-E <num>"));
        newVector.addElement(new Option("\tSet Multi Class.(default = false)", "T",1, "-T <num>"));
        newVector.addElement(new Option("\tSet the local search scope","W",0,"-W <number>"));
        newVector.addElement(new Option("\tSet the maximum evaluation.(default ="+Long.MAX_VALUE+" )", "J", 1, "-J <max evaluation>"));
        newVector.addElement(new Option("\tSet the local search method", "L", 1, "-L <instance evaluator>"));

        return newVector.elements();
    }

    public int getPopSize(){
        return popsize;
    }
    public void setPopSize(int p){
        popsize = p;
    }
    public int getNGen(){
        return ngen;
    }
    public void setNGen(int n){
        ngen = n;
    }
    public double getPCross(){
        return pcross_bin;
    }
    public void setPCross(double pc){
        pcross_bin = pc;
    }
    public double getPMut(){
        return pmut_bin;
    }
    public void setPMut(double pm){
        pmut_bin = pm;
    }
    public int getMaxNBin(){
        return m_maxNBin;
    }
    public void setMaxNBin(int m){
        m_maxNBin = m;
    }
    public int getMinNBin(){
        return m_minNBin;
    }
    public void setMinNBin(int m){
        m_minNBin = m;
    }
    public SelectedTag getLocalSearch(){
        return new SelectedTag(m_localSearch, TAGS_LOCALSEARCH);
    }
    public void setLocalSearch(SelectedTag value){
        if (value.getTags() == TAGS_LOCALSEARCH)
            m_localSearch = value.getSelectedTag().getID();
    }
    public SelectedTag getMultiClass(){
        return new SelectedTag(m_multiClass, TAGS_MULTI);
    }
    public void setMultiClass(SelectedTag value){
        if (value.getTags() == TAGS_MULTI)
            m_multiClass = value.getSelectedTag().getID();
    }

    public SelectedTag getEnsembleStrategy(){
        return new SelectedTag(m_ensembleStrategy, TAGS_ENSEMBLESTRATEGY);
    }
    public void setEnsembleStrategy(SelectedTag value){
        m_ensembleStrategy = value.getSelectedTag().getID();
    }

    public GALocalSearch getLocalSearchMethod(){
        return m_localSearchMethod;
    }
    public void setLocalSearchMethod(GALocalSearch a){
        m_localSearchMethod = a;
    }
    public int getLocalSearchScope() {

        return m_localSearchScope;
    }

    public void setLocalSearchScope(int scope) {
        m_localSearchScope = scope;
    }
    public long getMaxEvaluation(){
        return m_maxEvaluation;
    }
    public void setMaxEvaluation(long m){
        m_maxEvaluation = m;
    }
    public String globalInfo() {
        return "NSGAII :\nPerforms a search using Nondominanted Sorting multiobjective Genetic Algorithm II"
                +"in Deb (2002).\n";
    }


    public GALocalSearch[] buildLss(Instances insts) throws Exception {

        Instances newInsts;
        insts = new Instances(insts);
        insts.deleteWithMissingClass();
        int numClassifiers = insts.numClasses();
        GALocalSearch [] gals = null;
        if (numClassifiers <= 2) {
            gals = new GALocalSearch[1];
            gals[0] = GALocalSearch.makeCopy(m_localSearchMethod);
            gals[0].buildLocalSearch(insts,m_minNBin,m_maxNBin,this,ASEvaluator);
        } else if ( m_multiClass == OVO) {
            // generate fastvector of pairs
            FastVector pairs = new FastVector();
            for (int i=0; i<insts.numClasses(); i++) {
                for (int j=0; j<insts.numClasses(); j++) {
                    if (j<=i) continue;
                    int[] pair = new int[2];
                    pair[0] = i; pair[1] = j;
                    pairs.addElement(pair);
                }
            }
            numClassifiers = pairs.size();
            gals = GALocalSearch.makeCopies(m_localSearchMethod, numClassifiers);
            // generate the classifiers
            for (int i=0; i<numClassifiers; i++) {
                RemoveWithValues classFilter = new RemoveWithValues();
                classFilter.setAttributeIndex("" + (insts.classIndex() + 1));
                classFilter.setModifyHeader(true);
                classFilter.setInvertSelection(true);
                classFilter.setNominalIndicesArr((int[])pairs.elementAt(i));
                Instances tempInstances = new Instances(insts, 0);
                tempInstances.setClassIndex(-1);
                classFilter.setInputFormat(tempInstances);
                newInsts = Filter.useFilter(insts, classFilter);
                newInsts.setClassIndex(insts.classIndex());
                gals[i].buildLocalSearch(newInsts,m_minNBin,m_maxNBin,this,ASEvaluator);

            }
      } else { // use error correcting code style methods
          StandardCode code = new StandardCode(numClassifiers);
          gals = GALocalSearch.makeCopies(m_localSearchMethod,code.size());
          Filter [] m_ClassFilters;
          m_ClassFilters = new MakeIndicator[code.size()];
          for (int i = 0; i < gals.length; i++) {
              m_ClassFilters[i] = new MakeIndicator();
              MakeIndicator classFilter = (MakeIndicator) m_ClassFilters[i];
              classFilter.setAttributeIndex("" + (insts.classIndex() + 1));
              classFilter.setValueIndices(code.getIndices(i));
              classFilter.setNumeric(false);
              classFilter.setInputFormat(insts);
              newInsts = Filter.useFilter(insts, m_ClassFilters[i]);
              gals[i].buildLocalSearch(newInsts,m_minNBin,m_maxNBin,this,ASEvaluator);
          }
      }
      return gals;
  }

  public class StandardCode {
      protected boolean [][]m_Codebits;

      /** Returns the number of codes. */
      public int size() {
          return m_Codebits.length;
      }

      public String getIndices(int which) {
          StringBuffer sb = new StringBuffer();
          for (int i = 0; i < m_Codebits[which].length; i++) {
              if (m_Codebits[which][i]) {
                  if (sb.length() != 0) {
                      sb.append(',');
                  }
                  sb.append(i + 1);
              }
          }
          return sb.toString();
      }


      public StandardCode(int numClasses) {
          m_Codebits = new boolean[numClasses][numClasses];
          for (int i = 0; i < numClasses; i++) {
              m_Codebits[i][i] = true;
          }
          //System.err.println("Code:\n" + this);
      }
  }







}
