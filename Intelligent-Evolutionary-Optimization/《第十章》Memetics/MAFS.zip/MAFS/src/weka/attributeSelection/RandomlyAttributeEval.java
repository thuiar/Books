/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 *    GainRatioAttributeEval.java
 *    Copyright (C) 1999 Mark Hall
 *
 */

package  weka.attributeSelection;

import  java.io.*;
import  java.util.*;
import  weka.core.*;

public class RandomlyAttributeEval extends AttributeEvaluator
{
  /** The training instances */
  private Instances m_trainInstances;
  private Random r;
  public boolean sorted = false;

  public String globalInfo() {
    return "RandomlyAttributeEval :\n\nreturn random number as the fitness of the attribute\n";
  }

  /**
   * Constructor
   */
  public RandomlyAttributeEval () {
    resetOptions();
  }


  public void buildEvaluator (Instances data)
    throws Exception {
    m_trainInstances = data;
    r = new Random();
  }


  /**
   * reset options to default values
   */
  protected void resetOptions () {
   m_trainInstances = null;
  }

  public void setSorted(boolean b){
      sorted = b;
  }


  public double evaluateAttribute (int attribute)
          throws Exception {
      if(sorted){
          return m_trainInstances.numAttributes()-attribute;
      }else{
          return r.nextInt(m_trainInstances.numAttributes());
      }
  }


  /**
   * Return a description of the evaluator
   * @return description as a string
   */
  public String toString () {
    StringBuffer text = new StringBuffer();

    if (m_trainInstances == null) {
      text.append("\tRandom evaluator has not been built");
    }
    else {
      text.append("\tRandom feature evaluator");
    }

    text.append("\n");
    return  text.toString();
  }

  public static void main (String[] args) {

  }

}

