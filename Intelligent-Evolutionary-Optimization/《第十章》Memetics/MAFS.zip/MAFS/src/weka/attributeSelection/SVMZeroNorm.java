package weka.attributeSelection;

import weka.core.Instances;
import java.io.Serializable;
import weka.core.OptionHandler;
import weka.core.Option;
import java.util.Vector;
import weka.classifiers.functions.SMO;
import weka.core.Utils;
import java.util.Enumeration;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.Filter;
import weka.core.SelectedTag;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class SVMZeroNorm extends ASSearch implements OptionHandler,Serializable{
    protected int m_numToSelect = -1;
    protected double m_convergeThreshold = 1e-3;
    protected double m_removeThreshold = 1e3;
    protected int m_maxIteration = 20;
    protected SMO smo = null;
    protected Instances smodata = null;
    protected SMO.BinarySMO bsmo = null;

     public int getNumToSelect() {
         return m_numToSelect;
     }
     public void setNumToSelect(int m){
         m_numToSelect = m;
     }
     public double getConvergeThreshold(){
         return m_convergeThreshold;
     }
     public void setConvergeThreshold(double x){
         m_convergeThreshold = x;
     }
     public double getRemoveThreshold(){
         return m_removeThreshold;
     }
     public void setRemoveThreshold(double x){
         m_removeThreshold = x;
     }

     public int getMaxIteration(){
         return m_maxIteration;
     }
     public void setMaxIteration(int m){
         m_maxIteration = m;
     }

     public void setOptions(String[] options) throws Exception{
         String optionString;

         optionString = Utils.getOption('M', options);
         if (optionString.length() != 0) {
             setNumToSelect(Integer.parseInt(optionString));
         }
         optionString = Utils.getOption('X', options);
         if (optionString.length() != 0) {
             setConvergeThreshold(Double.parseDouble(optionString));
         }

         optionString = Utils.getOption('R', options);
         if (optionString.length() != 0) {
             setRemoveThreshold(Double.parseDouble(optionString));
         }

         optionString = Utils.getOption('I', options);
         if (optionString.length() != 0) {
             setMaxIteration(Integer.parseInt(optionString));
         }


         Utils.checkForRemainingOptions(options);
     }
     public String[] getOptions(){
         String[] options = new String[10];
         int current = 0;

         options[current++] = "-M";
         options[current++] = "" + getNumToSelect();
         options[current++] = "-X";
         options[current++] = "" + getConvergeThreshold();
         options[current++] = "-R";
         options[current++] = "" + getRemoveThreshold();
         options[current++] = "-I";
         options[current++] = "" + getMaxIteration();
         while (current < options.length) {
             options[current++] = "";
         }

         return options;


     }
     public Enumeration listOptions(){
         Vector newVector = new Vector(3);
         newVector.addElement(new Option("\tSpecify the number of attribute to be selected.","M",1,"-M <number>"));
         newVector.addElement(new Option("\tSpecify the number of Max Iteration.","I",1,"-I <number>"));
         newVector.addElement(new Option("\tSpecify the value of converge threshold.","X",1,"-X <number>"));
         newVector.addElement(new Option("\tSpecify the value of remove threshold.","R",1,"-R <number>"));
         return newVector.elements();
     }


//     public double norm(double [] vector){
//         double sum = 0;
//         for (int i = 0; i < vector.length; i++) {
//             sum += vector[i]*vector[i];
//         }
//         return Math.sqrt(sum);
//     }
    /**
     * Searches the attribute subset/ranking space.
     *
     * @param ASEvaluator the attribute evaluator to guide the search
     * @param data the training instances.
     * @return an array (not necessarily ordered) of selected attribute
     *   indexes
     * @throws Exception if the search can't be completed
     * @todo Implement this weka.attributeSelection.ASSearch method
     */
    public int[] search(ASEvaluation ASEvaluator, Instances data) throws
            Exception {
        int i=0, j=0, r=0, numAtt = data.numAttributes();
        int left[] = new int[numAtt-1];
        int rank[] = new int[numAtt-1];
        for (i = 0; i < left.length; i++) {
            left[i] = i;
        }
        smo = (SMO)((WrapperSubsetEval)ASEvaluator).getClassifier();
        smo.setFilterType(new SelectedTag(SMO.FILTER_NONE, SMO.TAGS_FILTER));
        smo.buildClassifier(data);
        bsmo = smo.m_classifiers[0][1];
        smodata = data;
        double scale [] = new double[numAtt-1];
        java.util.Arrays.fill(scale,1.0);
        int selected [] = m_numToSelect>0 ? new int[m_numToSelect]:new int[scale.length];
        Remove delTransform = new Remove();
        delTransform.setInvertSelection(true);
        int it = 0;
        while (it<m_maxIteration) {
            System.out.print("Iteration "+(it+1)+": ");
            int numleft = 0;
            for ( i = 0; i < left.length; i++) {
                if (left[i]!=-1) {
                    numleft++;
                }
            }
            int[] featArray = new int[numleft+1];
            double [][] scaleleft = new double[2][numleft];
            for (i = 0, j = 0; i < left.length; i++) {
                if (left[i]!=-1) {
                    featArray[j] = i;
                    scaleleft[0][j] = scale[left[i]];
                    scaleleft[1][j] = left[i];
                    j++;
                }
            }
            featArray[j] = numAtt-1;
            delTransform.setAttributeIndicesArray(featArray);
            delTransform.setInputFormat(data);
            smodata = Filter.useFilter(data, delTransform);
            smodata = smodata.scaleData(scaleleft[0]);
            bsmo.buildClassifier(smodata,0,1,smo.getBuildLogisticModels(),smo.getNumFolds(),smo.getRandomSeed());
            double [] newscale = new double[smodata.numAttributes()-1];
            for (j = 0; j < bsmo.m_sparseWeights.length; j++) {
                newscale[bsmo.m_sparseIndices[j]] = Math.abs(bsmo.m_sparseWeights[j]);
            }
            //Utils.printArray("weight",newscale);
            double sum_n0m1=0, sum_n0=0;
            for ( i = 0; i < newscale.length; i++) {
                if (newscale[i]!=0.0) {
                    sum_n0m1 += (newscale[i]-1)*(newscale[i]-1);
                    sum_n0 += newscale[i]*newscale[i];
                }
                scale[(int)scaleleft[1][i]] *= newscale[i];
                scaleleft[0][i] *= newscale[i];
            }
            double rmth = scale[Utils.maxIndex(scale)]/m_removeThreshold;
            for ( i = 0; i < scaleleft[1].length; i++) {
                if(scale[(int)scaleleft[1][i]]<=rmth){
                    scale[(int)scaleleft[1][i]] = 0;
                    left[(int)scaleleft[1][i]] = -1;
                    rank[rank.length-1-r] = (int)scaleleft[1][i];
                    r++;
                }
            }
            System.out.print(r+" weight set to 0.\n");
            System.out.println("kn0m1="+Math.sqrt(sum_n0m1)+"\t kn0="+Math.sqrt(sum_n0)*m_convergeThreshold);
            if ( Math.sqrt(sum_n0m1) < Math.sqrt(sum_n0)*m_convergeThreshold){
                System.out.println("Converged!");
                break;
            }

            it++;
        }
        int sorted[] = Utils.sort(scale);
        Utils.printArray("sorted",sorted);
        for ( i = 0; i < rank.length-r; i++) {
            rank[i] = sorted[sorted.length-1-i];
        }
        for ( i = 0; i < selected.length; i++) {
            selected[i] = rank[i];
        }
        return selected;
    }
}
