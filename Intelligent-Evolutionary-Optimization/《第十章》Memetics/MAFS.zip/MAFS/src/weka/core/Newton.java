package weka.core;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Newton {
    public static double EPSILON = 1e-2;

    static public interface NewtonFunction {
        abstract public double eval(double x);
        abstract public double deriv(double x);
        abstract public double deriv2(double x);
    };

    // Newton's method to find x* such that f(x*) = 0, starting at x
    public double root(NewtonFunction f, double x) {
        while (Math.abs(f.eval(x) / f.deriv(x)) > EPSILON) {
            x = x - f.eval(x) / f.deriv(x);
            System.out.println(x);
        }
        return x;
    }

    // Newton's method to find x* such that f'(x*) = 0, starting at x
    public double optimum(NewtonFunction f, double x) {
        while (Math.abs(f.deriv(x) / f.deriv2(x)) > EPSILON) {
            x = x - f.deriv(x) / f.deriv2(x);
        }
        return x;
    }

    public static void main(String [] args)throws Exception{

        Newton.NewtonFunction nf = new Newton.NewtonFunction(){
            public double eval(double x){
                return x*x-3*x+2;
            }
            public double deriv(double x){
                return 2*x-3;
            }
            public double deriv2(double x){
                return 2;
            }
        };
        Newton nt = new Newton();
        double root = nt.root(nf,200);

        System.out.println(root);

 }


}
