package weka.datagenerators;

import weka.core.*;
import java.io.FileReader;
import weka.filters.unsupervised.attribute.Standardize;
import weka.filters.Filter;
import weka.attributeSelection.*;
import java.io.FileWriter;
import java.io.Writer;
import java.io.BufferedWriter;
import weka.filters.unsupervised.attribute.Remove;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class MicroarrayPreprocess {
    public MicroarrayPreprocess() {
    }

    public static void main(String[] args) throws Exception {
        int numberToSelect = 100;
        String inputname;
        if(args.length>0){
            inputname = args[0];
        }else{
            inputname = "breast";
        }
        int nFloor=100,nCeiling=10000, fMinusFilter=5;
        double fRatioFilter=500;
        boolean numberThreshold = false;
        boolean statisticsThreshold = false;
        boolean standardize = false;
        Instances original;
        if(args.length>1){
            original = new Instances(new FileReader(args[1]));
        }else{
            original = new Instances(new FileReader(".\\Data\\Microarray\\"+inputname+"_full.arff"));
        }
        original.setClassIndex(original.numAttributes()-1);
        double pThreshold = 1.0/original.numInstances(), sdThreshold=0.05;
        Remove delTransform = new Remove();
        delTransform.setInvertSelection(true);
        int [] featArray;
        int [] tmp = new int[original.numAttributes()+1];
        int t = 0;
        if(numberThreshold){
            for (int i = 0; i < original.numAttributes();i++) {
                if(i!=original.classIndex()){
                    double vmin = Double.MAX_VALUE,vmax = -Double.MAX_VALUE;
                    for (int j = 0; j < original.numInstances(); j++) {

                        if(original.instance(j).value(i)>nCeiling){
                            original.instance(j).setValue(i,nCeiling);
                        }
                        if(original.instance(j).value(i)<nFloor){
                            original.instance(j).setValue(i,nFloor);
                        }
                        vmin = original.instance(j).value(i)<vmin ? original.instance(j).value(i) : vmin;
                        vmax = original.instance(j).value(i)>vmax ? original.instance(j).value(i) : vmax;
                    }
                    if( vmax/vmin < fRatioFilter || vmax - vmin < fMinusFilter){
                        tmp[t++] = i;
                    }
                }
            }
            featArray = new int[t+1];
            System.arraycopy(tmp,0,featArray,0,t);
            featArray[t] = original.classIndex();
            delTransform.setAttributeIndicesArray(featArray);
            delTransform.setInputFormat(original);
            original = Filter.useFilter(original, delTransform);
        }
        if(statisticsThreshold){
            double asd [] = new double[original.numAttributes()];
            for (int i = 0; i < original.numAttributes(); i++) {
                if(i==original.classIndex()){
                    continue;
                }
                AttributeStats as = original.attributeStats(i);
                double mean = as.numericStats.mean;
                double sd = as.numericStats.stdDev;
                boolean flag = false;
                for (int j = 0; j < original.numInstances(); j++) {
                    double z = (original.instance(j).value(i)-mean)/sd;
                    double mx = mean+2*sd, mi = mean-2*sd;
                    if(Statistics.normalProbability(z)<pThreshold){
                        if(z>0){
                            original.instance(j).setValue(i,mx);
                        }else{
                            original.instance(j).setValue(i,mi);
                        }
                        flag = true;
                    }
                }
              if(flag) as = original.attributeStats(i);
              asd[i] = as.numericStats.stdDev;
            }
            double asdm = Utils.mean(asd),asdsd = Math.sqrt(Utils.variance(asd));
            for (int i = 0; i < asd.length; i++) {
                if(asd[i]<asdm-2*asdsd){
                    tmp[t++] = i;
                }
            }
            featArray = new int[t+1];
            System.arraycopy(tmp,0,featArray,0,t);
            featArray[t] = original.classIndex();
            delTransform.setAttributeIndicesArray(featArray);
            delTransform.setInputFormat(original);
            original = Filter.useFilter(original, delTransform);
        }

        if(standardize){
            Standardize stdr = new Standardize();
            stdr.setInputFormat(original);
            original = Filter.useFilter(original,stdr);
        }

        AttributeEvaluator ae[] = {new FisherDiscriminantEval(),new ChiSquaredAttributeEval(),new ReliefFAttributeEval(),new InfoGainAttributeEval(),
                                  new GainRatioAttributeEval(),new SymmetricalUncertAttributeEval()};
        String []aes = {"FisherDiscriminant","ChiSquared","ReliefF","InformationGain","GainRatio","SymmetricalUncertainty"};
        RankGeneMeasures rgm[] = new RankGeneMeasures[7];
        for (int i = 0; i < rgm.length; i++) {
            rgm[i] = new RankGeneMeasures(i+2);
        }
        Ranker r = new Ranker();
        r.setNumToSelect(numberToSelect);
        Instances copy;
        int [] selected;
        Writer w;

        for (int i = 0; i < ae.length; i++) {
            copy = new Instances(original);
            ae[i].buildEvaluator(copy);
            selected = r.search(ae[i],copy);
            featArray = new int[selected.length+1];
            System.arraycopy(selected,0,featArray,0,selected.length);
            featArray[selected.length] = copy.classIndex();
            delTransform.setAttributeIndicesArray(featArray);
            delTransform.setInputFormat(copy);
            copy = Filter.useFilter(copy, delTransform);
            copy.setRelationName(inputname);
            if(args.length>2){
                w = new BufferedWriter(new FileWriter(args[2]+inputname+"_"+aes[i]+"_"+numberToSelect+".arff"));
            }else{
                w = new BufferedWriter(new FileWriter(".\\data\\wc\\"+inputname+"_"+aes[i]+"_"+numberToSelect+".arff"));
            }
            w.write(copy.toString());
            w.write("\n");
            w.close();
        }
        for (int i = 0; i < rgm.length; i++) {
            copy = new Instances(original);
            rgm[i].buildEvaluator(copy);
            selected = r.search(rgm[i],copy);
            featArray = new int[selected.length+1];
            System.arraycopy(selected,0,featArray,0,selected.length);
            featArray[selected.length] = copy.classIndex();
            delTransform.setAttributeIndicesArray(featArray);
            delTransform.setInputFormat(copy);
            copy = Filter.useFilter(copy, delTransform);
            copy.setRelationName(inputname);
            if(args.length>2){
                w = new BufferedWriter(new FileWriter(args[2]+inputname+"_"+rgm[i].getMeasureType().getSelectedTag().getReadable()+"_"+numberToSelect+".arff"));
            }else{
                w = new BufferedWriter(new FileWriter(".\\data\\wc\\"+inputname+"_"+rgm[i].getMeasureType().getSelectedTag().getReadable()+"_"+numberToSelect+".arff"));
            }
            w.write(copy.toString());
            w.write("\n");
            w.close();

        }






    }
}
