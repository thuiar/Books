package weka.datagenerators;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.Writer;
import java.io.BufferedWriter;
import weka.core.Instances;
import weka.core.Attribute;
import weka.core.FastVector;
import java.util.Random;

//import weka.core.*;
/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class SyntheticData {

    public SyntheticData() {
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    static boolean contain(int [] array,int length ,int a){
       for (int i = 0; i < length; i++) {
         if(array[i] == a){
            return true;
         }
       }
       return false;
   }
    public static void main(String[] args) throws Exception{
        Instances original = new Instances(new FileReader(".\\Data\\UCI\\corral128.arff"));
        int irrelevant = 14, redundant = 28, uniform = 30;
        int num_instance = original.numInstances(), num_attributes = original.numAttributes();
        original.setClassIndex(num_attributes-1);
        int percent_of_diff = num_instance/16;
        int [] rel_A = {0,1,2,3};
        Attribute [] irrA = new Attribute[irrelevant];
        FastVector labels = new FastVector(2);
        labels.addElement("0");
        labels.addElement("1");
        Random r = new Random();


        //add relevent R with 10% different from the class label
        for (double t = 0.20; t > 0.09; t-=0.05) {
            Attribute RT = new Attribute("R"+(100-t*100)+"%",labels);
            original.insertAttributeAt(RT,original.numAttributes()-1);
            int classindex = original.classIndex();
            for (int i = 0; i < num_instance; i++) {
                double v = original.instance(i).value(classindex);
                original.instance(i).setValue(original.numAttributes()-2,v);
            }
            int diffList[] = new int[(int)(num_instance*t)];
            for (int i = 0; i < diffList.length; i++) {
                int k = r.nextInt(num_instance);
                while(contain(diffList,i,k)){
                    k = r.nextInt(num_instance);
                }
                diffList[i] = k;
                double v = original.instance(k).value(classindex);
                original.instance(k).setValue(original.numAttributes()-2,Math.abs(v-1));
            }
        }


        //generate uniform random irrelevant
//        for (int i = 0; i < uniform; i++) {
//            irrA[i] = new Attribute("ir"+i,labels);
//            original.insertAttributeAt(irrA[i],original.numAttributes()-1);
//            int set1 [] = new int[num_instance/2];
//            for (int j = 0; j < set1.length; j++) {
//                set1[i] = -1;
//            }
//            for (int j = 0; j < set1.length; j++) {
//                int k = r.nextInt(num_instance);
//                while(contain(set1,j,k)){
//                    k = r.nextInt(num_instance);
//                }
//                set1[j] = k;
//            }
//            for (int j = 0; j < num_instance; j++) {
//                 if(!contain(set1,set1.length,j)){
//                     original.instance(j).setValue(original.numAttributes()-2,"0");
//                 }else{
//                     original.instance(j).setValue(original.numAttributes()-2,"1");
//                 }
//             }
//        }
//        //duplicate uniform random irrelevant
//        for (int i = uniform; i < irrelevant; i++) {
//            int k = r.nextInt(uniform);
//            irrA[i] = new Attribute("ir"+i,labels);
//            original.insertAttributeAt(irrA[i],original.numAttributes()-1);
//            for (int j = 0; j < num_instance; j++) {
//                double v = original.instance(j).value(6+k);
//                 original.instance(j).setValue(original.numAttributes()-2,v);
//             }
//        }
        //duplicate I
        for (int i = 1; i < irrelevant; i++) {
            irrA[i] = new Attribute("I"+i,labels);
            original.insertAttributeAt(irrA[i],original.numAttributes()-1);
            for (int j = 0; j < num_instance; j++) {
                double v = original.instance(j).value(4);
                 original.instance(j).setValue(original.numAttributes()-2,v);
             }
        }

        //generate relevant duplicate
        int interval = redundant/(rel_A.length);
        for (int i = 0; i < redundant; i++) {
            Attribute oriA = original.attribute(i/interval);
            Attribute at = new Attribute(oriA.name()+"rd"+(i%interval),labels);
            original.insertAttributeAt(at,original.numAttributes()-1);
            int diff [] = new int[(i%interval)*percent_of_diff];
            for (int a = 0; a < diff.length; a++) {
                diff[a] = -1;
            }
            for (int a = 0; a < diff.length; a++) {
                int k = r.nextInt(num_instance);
                while(contain(diff,a,k)){
                    k = r.nextInt(num_instance);
                }
                diff[a] = k;
            }
            for (int a = 0; a < num_instance; a++) {
                double v = original.instance(a).value(i/interval);

                if(contain(diff,diff.length,a)){
                    original.instance(a).setValue(original.numAttributes()-2,Math.abs(v-1));
                }else{
                    original.instance(a).setValue(original.numAttributes()-2,v);
                }

            }
        }
        Writer w = new BufferedWriter(new FileWriter(".\\data\\UCI\\corral128_50_1.arff"));
        w.write(original.toString());
        w.write("\n");
        w.close();
    }

    private void jbInit() throws Exception {
    }
}
