[![](https://badgen.net/badge/license/GPL-3.0/green)](#License) [![](https://badgen.net/badge/contact/THUIAR/purple)](https://thuiar.github.io/)
# TCM-CAS: Traditional Chinese Medicine Constitution Assessment System

### Paper

[An End-to-End Traditional Chinese Medicine Constitution Assessment System Based on Multimodal Clinical Feature Representation and Fusion]() (AAAI-22 Demonstration)

### Contents

- [TCM-CAS Backend]() 
- [TCM-CAS Frontend]()
- [Demonstration Video]()

### License

TCM-CAS is published under the GNU GPL 3 license.
